#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "storage_mgr.h"
#include "dberror.h"
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h> 

/**
 * Assignment 1 : Implementation of a simple Storage Manager for file-based data storage.
 *
 * This module offers functionalities to create, open, close, read, and write 
 * fixed-size pages within a file. It utilizes standard POSIX and C file operations 
 * to manage file-based storage efficiently.
 *
 * - Enables creation and management of page files.
 * - Supports reading and writing data at the block level.
 * - Facilitates dynamic file expansion using 'appendEmptyBlock()' and 'ensureCapacity()'.
 *
 * @author Ameya Hujare (A20545367)
           Deep Pawar   (A20545137)
           Canyu Chen   (A20479758)

 * @date 31st Jan 2025
 * @course CS 525 - Advanced Database Organization
 */

//Initializing and Setting up the storage manager which returns None
void initStorageManager(void) 
{
    printf("We successfully initialized Storage manager");
}

/**
 * Function to generate a new page file with a fixed size.
 *
 * This function creates a file with the specified name and pre-fills it 
 * with PAGE_SIZE bytes, all initialized to zero. It follows these steps:
 *  - Verifies that the provided file name is not NULL.
 *  - Opens the file in binary write mode.
 *  - Ensures PAGE_SIZE bytes are successfully written to the file.
 *  - Closes the file properly after writing.
 *
 * @param fileName The name of file to be generated.
 * @return RC_OK if the file is created successfully,
 *         RC_FILE_NOT_FOUND if the file name is NULL,
 *         RC_WRITE_FAILED if the expected PAGE_SIZE bytes are not written.
 */
RC createPageFile(char *fileName) 
{    
    //Validating the input for file name
    if(fileName == NULL) 
    {  
        return RC_FILE_NOT_FOUND;
    }

    //Attempting to create and open the file in binary write mode
    FILE *pt_file = fopen(fileName, "wb"); 
    if (pt_file == NULL) 
    {  
        return RC_FILE_NOT_FOUND;
    }

    //Initializing a page-sized buffer with zeros
    char buffer[PAGE_SIZE] = {0};
    
    //Writing the initialized buffer to the file
    if (fwrite(buffer, sizeof(char), PAGE_SIZE, pt_file) != PAGE_SIZE) 
    {
        fclose(pt_file);
        return RC_WRITE_FAILED;
    }

    //Closing the file
    fclose(pt_file);
    return RC_OK;
}

/**
 * Function to open an existing page file and sets up the file handle.
 *
 * This function attempts to access an existing file using the `open()` system call
 * and determines its size using 'fstat()'.
 *
 * The function executes the following operations:
 *  - Verifies that the file handle ('fHandle') is properly initialized.
 *  - Tries to open the file in read/write mode using 'open()' ('O_RDWR').
 *  - Returns 'RC_FILE_NOT_FOUND' if the file cannot be opened.
 *  - Uses 'fstat()' to obtain the file size from the file descriptor.
 *  - Closes the file descriptor after obtaining the file size.
 *  - If the file size is invalid, returns 'RC_READ_NON_EXISTING_PAG'.
 *  - Initializes the 'SM_FileHandle' structure with the file details.
 *
 * @param fileName The name of the file to be accessed.
 * @param fHandle Pointer to the file handle structure to be populated.
 * @return RC_OK if the file is successfully opened,
 *         RC_FILE_NOT_FOUND if the file does not exist or cannot be reopened,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle pointer is NULL,
 *         RC_READ_NON_EXISTING_PAGE if an error occurs while retrieving the file size.
 */

RC openPageFile(char *fileName, SM_FileHandle *fHandle)
{
    //Ensuring valid input parameters
    if (fHandle == NULL)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    if (fileName == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }

    //Opening the file in read/write mode
    int file_d = open(fileName, O_RDWR);
    if (file_d == -1)
    {
        return RC_FILE_NOT_FOUND;
    }

    //Getting the file size
    struct stat file_Stats;
    if (fstat(file_d, &file_Stats) == -1)
    {
        close(file_d);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Retrieving the file size
    long fSize = file_Stats.st_size;
    close(file_d);

    //Validating the retrieved file size
    if (fSize < 0)
    {
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Setting up the file handle with the relevant details
    fHandle->fileName = fileName;
    fHandle->curPagePos = 0;
    fHandle->totalNumPages = (fSize + PAGE_SIZE - 1) / PAGE_SIZE;

    //Reopening the file for management operations
    fHandle->mgmtInfo = fopen(fileName, "r+");
    if (fHandle->mgmtInfo == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }

    return RC_OK;
}

/**
 * Function to close an active page file and updates the corresponding file handle.
 *
 * This function ensures that an open file is properly closed and reflects the
 * change in the associated 'SM_FileHandle' structure. It follows these steps:
 *
 * - Confirms that the provided file handle ('fHandle') is not NULL.
 * - Verifies that the file is currently open by checking 'mgmtInfo'.
 * - Extracts the file descriptor from the file pointer stored in 'mgmtInfo'.
 * - Uses 'fstat()' to validate whether the file descriptor is associated with an open file.
 * - Attempts to close the file using the 'close()' system call.
 * - If the closure is successful, sets 'mgmtInfo' to NULL to indicate the file is no longer open.
 * - Displays a message confirming the successful closure of the file.
 *
 * @param fHandle Pointer to the file handle structure managing the file.
 * @return RC_OK if the file is closed successfully,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_FILE_NOT_FOUND if no valid file is associated with `mgmtInfo`,
 *         RC_FILE_CLOSE_FAILED if an error occurs while closing the file.
 */

RC closePageFile(SM_FileHandle *fHandle) 
{
    //Verifying the file handle is valid
    if (fHandle == NULL)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring the file is currently open by checking mgmtInfo
    if (fHandle->mgmtInfo == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }

    //Retrieving the file descriptor from the file pointer
    int fileDesc = fileno((FILE *)fHandle->mgmtInfo);
    
    //Validating the file descriptor corresponds to an open file
    struct stat file_Stat;
    if (fstat(fileDesc, &file_Stat) != 0)
    {
        return RC_FILE_CLOSE_FAILED;
    }

    //Attempting to close the file using the system call
    if (close(fileDesc) != 0)
    {
        return RC_FILE_CLOSE_FAILED;
    }

    //Clearing the management info after successfully closing
    fHandle->mgmtInfo = NULL;
    printf("\nFile closed successfully.\n");

    return RC_OK;
}

/**
 * Function to remove an existing page file from the system.
 *
 * This function deletes a specified file after ensuring it exists and that 
 * the necessary permissions allow for its removal. 
 * 
 * The function operates in the following steps:
 *
 * - Checks if the provided file name ('fileName') is not NULL.
 * - Verifies the file's existence using 'access(fileName, F_OK)'.
 *   - If the file is not found ('ENOENT'), it returns 'RC_FILE_NOT_FOUND'.
 *   - If the file exists but cannot be accessed due to permission restrictions, it returns 'RC_FILE_PERMISSION_ERROR'.
 * - Tries to remove the file using 'unlink()'.
 *   - If 'unlink()' fails due to permission issues ('EACCES' or 'EPERM'), it returns 'RC_FILE_PERMISSION_ERROR'.
 *   - If the file cannot be deleted for any other reason, it returns 'RC_FILE_DELETE_FAILED'.
 * - If deletion is successful, it returns 'RC_OK', confirming the file has been removed.
 *
 * @param fileName The name of the file that should be deleted.
 * @return RC_OK if the file is successfully deleted,
 *         RC_FILE_NOT_FOUND if the file does not exist,
 *         RC_FILE_PERMISSION_ERROR if permission restrictions prevent deletion,
 *         RC_FILE_DELETE_FAILED if the file could not be deleted for other reasons.
 */

RC destroyPageFile(char *fileName) 
{
    //Checking if the file name is valid
    if (fileName == NULL) 
    {
        return RC_FILE_NOT_FOUND;
    }

    //Using a different approach to remove the file
    FILE *f_file = fopen(fileName, "r");
    if (f_file == NULL) 
    {
        return RC_FILE_NOT_FOUND; 
    }
    fclose(f_file); 

    //Attempting to remove the file
    if (remove(fileName) != 0) 
    {
        return RC_FILE_NOT_FOUND; 
    }

    return RC_OK; 
}

/**
 * Function to load a specific page from a file into memory.
 *
 * This function retrieves a page from an existing file based on the given page number 
 * and stores the contents in a specified memory buffer.
 *
 * The function follows these key steps:
 *
 * - Ensures the file handle ('fHandle') is not NULL.
 * - Verifies that the memory buffer ('memPage') is properly allocated.
 * - Checks if the file contains valid pages ('totalNumPages > 0').
 * - Confirms that the requested page number ('pageNum') is within the valid range.
 * - Moves the file pointer to the calculated position using 'fseek()'.
 * - Reads 'PAGE_SIZE' bytes from the file into the memory buffer.
 * - If the read operation returns fewer bytes, the remaining space is filled with zeros.
 * - Updates the file handle's 'curPagePos' to indicate the current page.
 * - Returns a suitable error code if any validation or file operation fails.
 *
 * @param pageNum The page index to be read from the file.
 * @param fHandle Pointer to the file handle structure.
 * @param memPage Pointer to the memory buffer where the page content will be stored.
 * @return RC_OK if the page is read successfully,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is uninitialized,
 *         RC_WRITE_FAILED if the memory buffer is NULL,
 *         RC_READ_NON_EXISTING_PAGE if the page number is out of range or unreadable,
 *         RC_FILE_NOT_FOUND if the file pointer is invalid.
 */

RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) 
{
    //Validating file handle
    if (!fHandle) 
    {
        printf("Error Message : File handle is not initialized.\n");
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring memory page is provided
    if (!memPage) 
    {
        printf("Error Message : Memory page pointer is NULL.\n");
        return RC_WRITE_FAILED;
    }

    //Ensuring the file has valid pages
    if (fHandle->totalNumPages == 0) 
    {
        printf("Error Message : File contains no data.\n");
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Validating the requested page number
    if (pageNum < 0 || pageNum >= fHandle->totalNumPages) 
    {
        printf("Error Message : Requested page number %d is out of bounds.\n", pageNum);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Retrieving file pointer from the handle and validate
    //Ensuring the file pointer is valid
    FILE *fil_Ptr = (FILE *)fHandle->mgmtInfo;
    if (fil_Ptr == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }

    //Calculating the byte offset for the page
    long offset = (long)pageNum * PAGE_SIZE;

    //Moving the file pointer to the desired page
    if (fseek(fil_Ptr, offset, SEEK_SET) != 0)
    {
        perror("Error Message : Failed to seek to requested page");
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Reading the page into the memory buffer
    size_t bytesRead = fread(memPage, sizeof(char), PAGE_SIZE, fil_Ptr);

    //If fewer bytes were read, we will zero out remaining space
    if (bytesRead < PAGE_SIZE)
    {
        memset(memPage + bytesRead, 0, PAGE_SIZE - bytesRead);
    }

    //Updating the current page position
    fHandle->curPagePos = pageNum;

    printf("Success : Page %d successfully loaded from file %s.\n", pageNum, fHandle->fileName);
    
    return RC_OK;
}

/**
 * Function to get the current page position in the file.
 *
 * This function retrieves the index of the page currently being accessed
 * in the file associated with the provided 'SM_FileHandle' structure.
 *
 * The function follows these steps:
 *
 * - Verifies whether the given file handle ('fHandle') is NULL.
 *   - If NULL, returns '-1' to indicate an invalid file handle.
 * - Extracts and prints the current page position ('curPagePos').
 * - Returns the current page index within the file.
 *
 * @param fHandle Pointer to the file handle structure storing file metadata.
 * @return The current page index ('curPagePos') if the file handle is valid,
 *         or '-1' if the file handle is NULL.
 */


int getBlockPos(SM_FileHandle *fHandle) 
{
    printf("\nPerforming null check validation...\n");

    //Ensuring the file handle is not NULL
    if (!fHandle)
    {
        return -1;
    }
    printf("\nValidation successful. File handle is valid successfully.\n");
    printf("Current Page Position : %d\n", fHandle->curPagePos);

    //Returning the current page position stored in the file handle
    return fHandle->curPagePos;
}

/**
 * Function to load the first page (block) from a file into memory.
 *
 * This function reads the first page (page index 0) of a file and stores its
 * content in the given memory buffer ('memPage').
 *
 * The function executes the following steps:
 *
 * - Checks whether the provided file handle ('fHandle') is NULL.
 *   - If NULL, returns 'RC_FILE_HANDLE_NOT_INIT', signaling an uninitialized file handle.
 * - Verifies that the memory buffer ('memPage') is valid.
 *   - If NULL, returns 'RC_WRITE_FAILED', indicating an invalid memory buffer.
 * - Invokes the 'readBlock()' function with 'pageNum = 0' to retrieve the first page.
 * - Returns the status code from 'readBlock()' to indicate success or failure.
 *
 * @param fHandle Pointer to the file handle structure containing file information.
 * @param memPage Pointer to the memory buffer where the first page's content will be stored.
 * @return RC_OK if the first page is successfully read,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_WRITE_FAILED if the memory buffer is NULL.
 */

RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{
    printf("\nChecking for null references before reading the first block of file : %s\n", fHandle->fileName);

    //Ensuring the memory buffer is allocated
    if (memPage == NULL)
    {
        return RC_WRITE_FAILED;
    }    

    //Validating the file handle
    if (fHandle == NULL)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    printf("\nValidation successful. We will proceed to read the first block.\n");

    //Reading the first page from the file
    return readBlock(0, fHandle, memPage);
}

/**
 * Function to load the previous page (block) from a file into memory.
 *
 * This function reads the page that comes immediately before the current page
 * in the file and stores its contents in the provided memory buffer ('memPage').
 *
 * The function performs the following steps:
 *
 * - Checks if the provided file handle ('fHandle') is NULL.
 *   - If NULL, returns 'RC_FILE_HANDLE_NOT_INIT', indicating an uninitialized file handle.
 * - Verifies that the memory buffer ('memPage') is allocated.
 *   - If NULL, returns 'RC_WRITE_FAILED', indicating an invalid memory buffer.
 * - Retrieves the current page position using 'getBlockPos(fHandle)'.
 * - Ensures that a previous page exists.
 * - Calls 'readBlock(currentPageNumber - 1, fHandle, memPage)' to load the previous page.
 * - Returns the status code from 'readBlock()' to indicate success or failure.
 *
 * @param fHandle Pointer to the file handle structure containing file metadata.
 * @param memPage Pointer to the memory buffer where the previous page content will be stored.
 * @return RC_OK if the previous page is successfully read,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_WRITE_FAILED if the memory buffer is NULL,
 *         RC_READ_NON_EXISTING_PAGE if the previous page does not exist.
 */

RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    printf("\nPerforming null checks before reading the previous block for file : %s\n", fHandle->fileName);

    //Ensuring the memory buffer is allocated
    if (!memPage)
    {
        return RC_WRITE_FAILED;
    }

    //Validating that the file handle is provided
    if (!fHandle)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Retrieving the current page position
    int currentPageNumber = getBlockPos(fHandle);

    //Ensuring the previous page exists before attempting to read
    if ((currentPageNumber - 1) <= -1)
    {
        return RC_READ_NON_EXISTING_PAGE;
    }

    printf("\nValidation successful. We can proceed to read the previous block.\n");

    //Reading the previous page by subtracting 1 from the current page number
    return readBlock(currentPageNumber - 1, fHandle, memPage);
}

/**
 * Function to load the current page (block) from a file into memory.
 *
 * This function retrieves the page that is currently being accessed in the file
 * and stores its data in the provided memory buffer ('memPage').
 *
 * The function executes the following steps:
 *
 * - Checks if the file handle ('fHandle') or memory buffer ('memPage') is NULL.
 *   - If `fHandle` is NULL, returns 'RC_FILE_HANDLE_NOT_INIT', meaning the file handle is uninitialized.
 *   - If `memPage` is NULL, returns 'RC_WRITE_FAILED', indicating an invalid memory buffer.
 * - Retrieves the current page position by calling 'getBlockPos(fHandle)'.
 *   - If the returned page number is '-1', the function returns 'RC_READ_NON_EXISTING_PAGE', 
 *     signifying that the page position is invalid.
 * - Invokes 'readBlock(cur_Page_Num, fHandle, memPage)' to read the current page.
 * - Returns the result from 'readBlock()', indicating either success or failure.
 *
 * @param fHandle Pointer to the file handle structure storing file information.
 * @param memPage Pointer to the memory buffer where the current page content will be loaded.
 * @return RC_OK if the current page is successfully read,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_WRITE_FAILED if the memory buffer is NULL,
 *         RC_READ_NON_EXISTING_PAGE if the current page does not exist.
 */

RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{
    printf("\n Verifying null checks in the current block for the File : %s\n", fHandle->fileName);

    if (!fHandle || !memPage) 
    {
        return !fHandle ? RC_FILE_HANDLE_NOT_INIT : RC_WRITE_FAILED;
    }

    //Retrieving the current block position and checking for validity
    int cur_Page_Num = getBlockPos(fHandle);
    if (cur_Page_Num == -1) 
    { 
        return RC_READ_NON_EXISTING_PAGE;
    }

    printf("\n Null checks passed successfully\n");

    //Attempting to read the current block
    return readBlock(cur_Page_Num, fHandle, memPage);
}

/**
 * Function to Read the next page (block) from a file and loads it into memory.
 *
 * This function retrieves the page that follows the current page in the file
 * and stores its contents in the provided memory buffer ('memPage'). 
 *
 * The function follows these steps:
 * 
 * - Checks if the provided file handle ('fHandle') is NULL.
 *   - If NULL, returns 'RC_FILE_HANDLE_NOT_INIT', indicating that the file handle is uninitialized.
 * - Ensures that the memory buffer ('memPage') is provided.
 *   - If NULL, returns 'RC_WRITE_FAILED', indicating an invalid memory buffer.
 * - Retrieves the current page position using 'getBlockPos(fHandle)'.
 * - Ensures that the next page exists before proceeding.
 *   - If 'getBlockPos(fHandle)' returns '-1', it means there is an issue retrieving the page position.
 *   - If '(current_Page_N + 1) >= fHandle->totalNumPages', it means there is no next page to read.
 *   - In both cases, the function returns 'RC_READ_NON_EXISTING_PAGE'.
 * - Calls 'readBlock(current_Page_N + 1, fHandle, memPage)' to read the next page.
 * - Returns the status code from 'readBlock()' to indicate success or failure.
 *
 * @param fHandle Pointer to the file handle structure containing file metadata.
 * @param memPage Pointer to the memory buffer where the next page content will be stored.
 * @return RC_OK if the next page is successfully read,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_WRITE_FAILED if the memory buffer is NULL,
 *         RC_READ_NON_EXISTING_PAGE if there is no next page to read.
 */

RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{
    printf("\n Verifying null checks in the next block for the File : %s\n", fHandle->fileName);

    //Ensuring the memory buffer is allocated
    if (!memPage)
    {
        return RC_WRITE_FAILED;
    }

    //Validating that the file handle is provided
    if (!fHandle)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    int current_Page_N = getBlockPos(fHandle);
    //Retrieving the current block position
    if (current_Page_N == -1 || (current_Page_N + 1) > fHandle->totalNumPages) 
    {
        return RC_READ_NON_EXISTING_PAGE;
    }

    printf("\nValidation successful. WE can proceed to read the next block.\n");

    //Reading the next page by incrementing the current page number
    return readBlock(current_Page_N + 1, fHandle, memPage);
}

/**
 * Function to load the last page (block) from a file into memory.
 *
 * This function retrieves the last available page in the file and stores its 
 * data in the provided memory buffer ('memPage'). It includes validation checks 
 * to ensure the file handle and memory buffer are properly initialized before 
 * performing the read operation.
 *
 * The function executes the following steps:
 *
 * - Checks whether the file handle ('fHandle') or memory buffer ('memPage') is NULL.
 * - Determines the last page number by computing 'fHandle->totalNumPages - 1'.
 * - Confirms that the file contains at least one page.
 *   - If 'last_P_Num < 0', returns 'RC_READ_NON_EXISTING_PAGE', meaning the file has no available pages.
 * - Calls 'readBlock(last_P_Num, fHandle, memPage)' to load the last page.
 * - Returns the status code from 'readBlock()' to indicate success or failure.
 *
 * @param fHandle Pointer to the file handle structure storing file details.
 * @param memPage Pointer to the memory buffer where the last page content will be loaded.
 * @return RC_OK if the last page is successfully retrieved,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_WRITE_FAILED if the memory buffer is NULL,
 *         RC_READ_NON_EXISTING_PAGE if no pages exist in the file.
 */

RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{
    printf("\nPerforming null checks before reading the last block for file : %s\n", fHandle->fileName);

    //Validating that the file handle is provided and memory buffer is allocated
    if (!memPage || !fHandle)
    {
        return !memPage ? RC_WRITE_FAILED : RC_FILE_HANDLE_NOT_INIT;
    }

    //Determining the last page number in the file
    int last_P_Num = fHandle->totalNumPages - 1;

    //Ensuring the file contains at least one page before attempting to read
    if (last_P_Num < 0)
    {
        return RC_READ_NON_EXISTING_PAGE;
    }
    printf("\nValidation successful. We can Proceed to read the last block.\n");

    //Reading the last page from the file
    return readBlock(last_P_Num, fHandle, memPage);
}

/**
 * Function to Write data to a specific page (block) in a file.
 *
 * This function writes the contents of a memory buffer ('memPage') to a specified 
 * page ('pageNum') within a file. It incorporates validation checks to ensure 
 * correct input parameters before proceeding with the write operation. 
 *
 * The function executes the following steps:
 * 
 * - Ensures the memory buffer ('memPage') is valid:
 *   - If NULL, returns 'RC_WRITE_FAILED', indicating an invalid buffer.
 * - Checks the validity of the file handle ('fHandle'):
 *   - If NULL, returns 'RC_FILE_HANDLE_NOT_INIT', indicating an uninitialized file handle.
 * - Retrieves the file pointer from 'fHandle->mgmtInfo':
 *   - If NULL, returns 'RC_FILE_NOT_FOUND', indicating the file is not accessible.
 * - Validates the provided page number ('pageNum'):
 *   - If it is negative or exceeds the total number of pages, returns 'RC_READ_NON_EXISTING_PAGE'.
 * - Obtains the file descriptor using 'fileno(file_ptr)':
 *   - If retrieval fails, returns 'RC_FILE_NOT_FOUND'.
 * - Uses 'lseek()' to move the file pointer to the required page position:
 * - Writes 'PAGE_SIZE' bytes from `memPage` to the file using 'write()':
 * - Updates 'curPagePos' in the file handle to reflect the newly written page.
 * - Returns 'RC_OK' upon successful execution.
 *
 * @param pageNum The target page number where data will be written.
 * @param fHandle Pointer to the file handle structure storing file details.
 * @param memPage Pointer to the memory buffer containing the data to write.
 * @return RC_OK if the write operation is successful,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is invalid,
 *         RC_WRITE_FAILED if the memory buffer is NULL or the write operation fails,
 *         RC_FILE_NOT_FOUND if the file pointer or descriptor is invalid,
 *         RC_READ_NON_EXISTING_PAGE if the specified page number is out of bounds.
 */


RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) 
{
    //Validating file handle and memory page
    if (memPage == NULL) 
    {
        return RC_WRITE_FAILED;
    }

    if (fHandle == NULL) 
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Retrieving the file pointer from the file handle
    FILE *file_ptr = fHandle->mgmtInfo;
    if (file_ptr == NULL) 
    {
        return RC_FILE_NOT_FOUND;
    }

    //Verifying that the page number is within a valid range
    if (pageNum < 0 || pageNum >= fHandle->totalNumPages) 
    {
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Calculating the byte offset based on the page number
    long file_Off_set = (long)pageNum * PAGE_SIZE;

    //Moving the file pointer to the required position
    if (fseek(file_ptr, file_Off_set, SEEK_SET) != 0) 
    {
        return RC_WRITE_FAILED;
    }

    //Writing PAGE_SIZE bytes to the file
    size_t writtenBytes = fwrite(memPage, sizeof(char), PAGE_SIZE, file_ptr);

    //Ensuring the entire page is written successfully
    if (writtenBytes != PAGE_SIZE) 
    {
        return RC_WRITE_FAILED;
    }

    //Updating the file handle's current position
    fHandle->curPagePos = pageNum;

    return RC_OK;
}

/**
 * Function to Write data to the currently active page (block) in a file.
 *
 * This function stores the content of a memory buffer ('memPage') into the 
 * page currently being accessed in the file. 
 *
 * The function operates as follows:
 * 
 * - Checks whether the file handle ('fHandle') is NULL:
 *   - If NULL, returns 'RC_FILE_HANDLE_NOT_INIT'.
 * - Retrieves the file pointer from 'fHandle->mgmtInfo':
 *   - If NULL, returns 'RC_FILE_NOT_FOUND'.
 * - Gets the current page index from 'fHandle->curPagePos'.
 * - Calls 'writeBlock(pageNum, fHandle, memPage)' to write the data to the current page.
 * - Returns the response code from 'writeBlock()' to indicate whether the operation succeeded or failed.
 *
 * @param fHandle Pointer to the file handle structure storing file-related metadata.
 * @param memPage Pointer to the memory buffer that holds the data to be written.
 * @return RC_OK if the write operation is successful,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_FILE_NOT_FOUND if the file is not open or accessible.
 */

RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{
    
    //Validating the file handle
    if (fHandle == NULL) 
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Retrieving the file pointer from the file handle
    FILE *fi_Ptr = fHandle->mgmtInfo;
    if (fi_Ptr == NULL) 
    {
        return RC_FILE_NOT_FOUND;
    }
    
    //Writing the current block using writeBlock function
    int pageNum = fHandle->curPagePos;
    return writeBlock(pageNum, fHandle, memPage);
}

/**
 * Function to append an empty page to the end of the file.
 *
 * This function adds a new page (block) to the file associated with 
 * the given 'SM_FileHandle' structure. The newly appended page is 
 * initialized with zero bytes.
 *
 * The function follows these steps:
 *
 * - Validates that the file handle ('fHandle') is provided:
 *   - If NULL, returns 'RC_FILE_HANDLE_NOT_INIT'.
 * - Retrieves the file descriptor using 'fileno()':
 *   - If retrieval fails, returns 'RC_FILE_NOT_FOUND'.
 * - Moves the file pointer to the end of the file using 'lseek()':
 *   - If 'lseek()' fails, returns 'RC_READ_NON_EXISTING_PAGE', indicating a failure in repositioning the file pointer.
 * - Creates an empty buffer ('emptyPage') filled with zero bytes.
 * - Writes 'PAGE_SIZE' bytes to the file using 'write()':
 *   - If 'write()' fails to write the expected number of bytes, returns 'RC_WRITE_FAILED'.
 * - Updates the file handle's 'totalNumPages' to reflect the newly appended page.
 * - Prints messages before and after incrementing the page count for debugging.
 * - Returns 'RC_OK' if the operation is successful.
 *
 * @param fHandle Pointer to the file handle structure containing file metadata.
 * @return RC_OK if the empty page is successfully appended,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_FILE_NOT_FOUND if the file is not open,
 *         RC_READ_NON_EXISTING_PAGE if 'lseek()' fails,
 *         RC_WRITE_FAILED if writing the empty page fails.
 */

RC appendEmptyBlock(SM_FileHandle *fHandle) 
{
    //Validating the file handle
    if (!fHandle)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Retrieving the file descriptor from the file handle
    int file_D = fileno((FILE *)fHandle->mgmtInfo);
    if (file_D == -1) 
    {
        return RC_FILE_NOT_FOUND;
    }

    //Moving the file pointer to the end using lseek
    if (lseek(file_D, 0, SEEK_END) == -1) 
    {
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Creating an empty buffer for a new page and filling it with zeros
    char emptyPage[PAGE_SIZE] = {0};

    //Writing the empty page to the file
    long bytesWritten = write(file_D, emptyPage, PAGE_SIZE);
    if (bytesWritten != PAGE_SIZE) 
    {
        return RC_WRITE_FAILED;
    }

    //Updating the file handle's total page count
    printf("--------------------\n");
    printf("BEFORE INC : %d\n", fHandle->totalNumPages);
    fHandle->totalNumPages++;
    printf("AFTER INC  : %d\n", fHandle->totalNumPages);
    printf("--------------------\n");

    return RC_OK;
}

/**
 * Function to ensure the file contains at least a specified number of pages.
 *
 * This function increases the file size if its current number of pages 
 * is less than the specified 'numberOfPages'. Instead of appending pages 
 * individually, it efficiently resizes the file in a single operation 
 * using 'ftruncate()', improving performance.
 *
 * The function follows these steps:
 *
 * - Validates the provided file handle ('fHandle'):
 *   - If NULL, returns 'RC_FILE_HANDLE_NOT_INIT'.
 * - Checks whether the requested page count ('numberOfPages') is valid:
 *   - If less than 1, returns 'RC_READ_NON_EXISTING_PAGE'.
 * - Determines if the file already meets the required capacity:
 *   - If 'fHandle->totalNumPages >= numberOfPages', no additional pages are needed, and 'RC_OK' is returned.
 * - Retrieves the file descriptor using 'fileno()':
 *   - If retrieval fails, returns 'RC_FILE_NOT_FOUND'.
 * - Calculates the additional pages required:
 *   - 'pagesToAdd = numberOfPages - fHandle->totalNumPages'.
 * - Logs debugging information about the current page count and the required expansion.
 * - Expands the file size in one operation using 'ftruncate()':
 *   - If 'ftruncate()' fails, returns 'RC_WRITE_FAILED'.
 * - Updates 'fHandle->totalNumPages' to reflect the new file size.
 * - Prints debugging messages after the update.
 * - Returns 'RC_OK' upon successful execution.
 *
 * @param numberOfPages The required minimum number of pages in the file.
 * @param fHandle Pointer to the file handle structure managing file metadata.
 * @return RC_OK if the file is successfully expanded,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is NULL,
 *         RC_READ_NON_EXISTING_PAGE if 'numberOfPages' is invalid,
 *         RC_FILE_NOT_FOUND if the file is inaccessible,
 *         RC_WRITE_FAILED if 'ftruncate()' encounters an error.
 */

RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle) 
{
    //Validating the file handle
    if (!fHandle) 
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring the requested number of pages is valid
    if (numberOfPages < 1) 
    {
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Checking if the current file capacity already meets or exceeds the required pages
    if (fHandle->totalNumPages >= numberOfPages) 
    {
        //If no additional pages needed
        return RC_OK; 
    }

    //Retrieving the file pointer
    FILE *ptr_file = fHandle->mgmtInfo;
    if (ptr_file == NULL) 
    {
        return RC_FILE_NOT_FOUND;
    }

    //Calculating needed additional pages 
    int add_Pages_Needed = numberOfPages - fHandle->totalNumPages;
    
    //Debuging the information
    printf("\nCurrent Total Pages : %d", fHandle->totalNumPages);
    printf("\nPages Needed to Ensure Capacity : %d\n", add_Pages_Needed);

    //Appending empty blocks until the required capacity is met
    for (int i = 0; i < add_Pages_Needed; i++) 
    {
        RC res_Code = appendEmptyBlock(fHandle);
        if (res_Code != RC_OK) 
        {
            return res_Code;
        }
    }

    //Debuging info after ensuring capacity
    printf("\nUpdated Total Pages : %d", fHandle->totalNumPages);
    printf("\nRemaining Pages Needed : %d\n", numberOfPages - fHandle->totalNumPages);

    return RC_OK;
}
