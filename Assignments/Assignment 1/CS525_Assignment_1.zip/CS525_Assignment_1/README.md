# CS 525 Assignment 1 : Storage Manager

## Introduction

This assignment implements a **Storage Manager** that manages file-based storage using **fixed-size pages**. It allows reading and writing blocks from disk into memory, as well as operations such as **creating, opening, closing, and deleting files**. The system is designed for efficient storage management and error handling.

## Features

- **File Management** : Create, open, close, and delete files.
- **Page Management** : Read and write pages within files.
- **Metadata Tracking** : Maintain information such as **total number of pages** and **current page position**.
- **Error Handling** : Return codes ensure efficient debugging.
- **Scalability** : Support dynamic file expansion using 'appendEmptyBlock()' and 'ensureCapacity()'.

## Code Structure

### **Directory Layout**

```
assign1/
├── README.txt         # Documentation file
├── dberror.c          # Error handling functions
├── dberror.h          # Header defining error codes
├── storage_mgr.c      # Implementation of storage manager
├── storage_mgr.h      # Header defining storage manager interface
├── test_assign1_1.c   # Test cases for storage manager
├── test_helper.h      # Helper functions for tests
├── Makefile           # Build script
```

### **Header Files**

- **storage_mgr.h** : Defines 'SM_FileHandle' and 'SM_PageHandle' structures and key functions.
- **dberror.h** : Defines error codes and debugging functions.
- **test_helper.h** : Provides macros and utilities for testing.

## Implementation Details

### **Data Structures**

- **SM_PageHandle** : It is a Pointer to a memory block representing a page

- **SM_FileHandle** : It represents an open page file.
  Fields contains:
  - 'fileName': Name of the file.
  - 'totalNumPages': Total number of pages in the file.
  - 'curPagePos': Current page position for read/write operations.
  - 'mgmtInfo': Pointer to additional metadata (e.g., file descriptor).

### **File Operations**

| Function                                               | Description                                      |
| ------------------------------------------------------ | ------------------------------------------------ |
| 'createPageFile(char *fileName)'                       | Creates a new file with an initial empty page.   |
| 'openPageFile(char *fileName, SM_FileHandle *fHandle)' | Opens an existing file and initializes metadata. |
| 'closePageFile(SM_FileHandle *fHandle)'                | Closes an open file.                             |
| 'destroyPageFile(char *fileName)'                      | Deletes a file from the system.                  |

### **Page Operations**

| Function                                                                 | Description                                                  |
| ------------------------------------------------------------------------ | ------------------------------------------------------------ |
| 'readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)'  | Reads a specific page into memory.                           |
| 'readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)'          | Reads the first page of the file.                            |
| 'readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)'        | Reads the current page.                                      |
| 'writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)' | Writes data to a specific page.                              |
| 'writeCurrentBlock(SM_FileHandle fHandle, SM_PageHandle memPage)'        | Writes to the current page.                                  |
| 'appendEmptyBlock(SM_FileHandle *fHandle)'                               | Adds a new empty page to the file.                           |
| 'ensureCapacity(int numberOfPages, SM_FileHandle *fHandle)'              | Ensures the file has at least the specified number of pages. |

### **Error Handling**

All functions return an `RC` (return code) value for error detection.

Common error codes:

- 'RC_OK' : Operation successful.
- 'RC_FILE_NOT_FOUND' : File not found.
- 'RC_READ_NON_EXISTING_PAGE' : Attempt to read a non-existing page.

Error messages can be printed using 'printError()'.

## Build & Test Instructions

1. To Compile the code and build the project.

 ```bash
   make
   ```
2. The executable `test_assign1` will be generated.

3. To execute test cases from 'test_assign1_1.c'.

 ```bash
./test_assign1 (or just test_assign1 based on API version)
```
## Design Considerations

### **File Metadata**

- Metadata such as 'totalNumPages' is stored at the **beginning of each file**.
- 'mgmtInfo' maintains file pointers for efficient access.

### **Memory Management**

- Memory for 'SM_PageHandle' is allocated and freed appropriately to prevent leaks.

### **Scalability**

- Uses 'appendEmptyBlock()' and 'ensureCapacity()' to **dynamically expand file size**.

## Conclusion

This project successfully implements a **modular and efficient Storage Manager**, supporting essential file operations, structured metadata handling, and robust error handling. The **modular design** ensures **maintainability and flexibility** for future enhancements.

---
## Documentation Link : https://drive.google.com/file/d/1sZN3WJ038hYlowEgpXhLZgLVUdhCzuk7/view?usp=sharing
## Screenshots of output : 1. https://drive.google.com/file/d/1byzKpDQFgrFmQoLshRmFUq2nUMSScKYA/view?usp=sharing  
##                         2. https://drive.google.com/file/d/1OEKj03OtR6sfL1iixgj-GjI06XTBkT5_/view?usp=sharing
---

**Authors**: Ameya Hujare & Deep Pawar & Canyu Chen\
**Course**: CS 525 - Advanced Database Organization\
**Instructor**: Prof. Gerald Balekaki\
**Institution**: Illinois Institute of Technology