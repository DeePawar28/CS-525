#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include "storage_mgr.h"

/**
 * Macro definition for read operation at the beginning of a file.
 */
#define RC_READ_AT_BEGINNING 0

/**
 * Global file pointer for the storage manager.
 *
 * This file pointer is used for managing file operations within the storage manager.
 * It is initialized to NULL during storage manager initialization.
 */
FILE *fgrp21;

/**
 * Function initStorageManager: Initializes the storage manager.
 *
 * This function sets up the storage manager by initializing relevant pointers
 * and displaying a confirmation message. It ensures that the file pointer is set
 * to NULL before usage.
 */
extern void initStorageManager(void)
{
    printf("=====================================================\n");
    printf("The storage manager has initiated successfully!\n");
    printf("=====================================================\n");
    
    //Ensuring file pointer is set to NULL
    fgrp21 = NULL; 
    
    //Placeholder 
    printf(""); 
}

/**
 * Function createPageFile: Creates a new page file and initializes it with zero bytes.
 *
 * @param fileName Pointer to the name of the file to be created.
 *
 * This function attempts to create a new file, allocates memory for a page buffer,
 * and initializes the file with zero bytes. If any step fails, it ensures proper cleanup.
 *
 * @return RC_OK on success, or an appropriate error code if file creation or writing fails.
 */
extern RC createPageFile(char *fileName)
{
    //Attempting to create a new file with read/write access
    fgrp21 = fopen(fileName, "w+");

    //Placeholder for logging
    printf(""); 
    
    //Checking if file creation was successful
    if (fgrp21 == NULL) 
    {
        //Return error if file creation fails
        return RC_FILE_NOT_FOUND; 
    }

    //Allocating memory for a page buffer and initialize with zeroes
    printf("");
    SM_PageHandle pageBuffer = (SM_PageHandle)calloc(PAGE_SIZE, sizeof(char));
    if (pageBuffer == NULL)
    {
        //Closing file if memory allocation fails
        fclose(fgrp21); 
        return RC_WRITE_FAILED;
    }

    //Writing zero bytes to the file to initialize it
    printf("");
    if (fwrite(pageBuffer, sizeof(char), PAGE_SIZE, fgrp21) != PAGE_SIZE)
    {
        //Placeholder for logging
        printf(""); 

        //Freeing allocated memory on failure
        free(pageBuffer); 

        //Closing the file if writing fails
        fclose(fgrp21); 
        return RC_WRITE_FAILED;
    }

    //Placeholder for logging
    printf(""); 

    //Closing the file after successful initialization
    fclose(fgrp21); 

    //Freeing allocated memory
    free(pageBuffer); 
    printf("");

    //Returning success
    return RC_OK; 
}

/**
 * Function openPageFile: Opens an existing page file and configures the file handle.
 *
 * @param fileName Pointer to the name of the file to be opened.
 * @param fHandle  Pointer to the file handle structure to be initialized.
 *
 * This function attempts to open a specified file in read mode, sets up the file handle,
 * retrieves file size details, and calculates the total number of pages. If the file is not found,
 * it returns an appropriate error code.
 *
 * @return RC_OK on success, RC_FILE_NOT_FOUND if the file does not exist, or RC_ERROR for other failures.
 */
extern RC openPageFile(char *fileName, SM_FileHandle *fHandle)
{
    //Opening the file in read mode
    FILE *filePointer = fopen(fileName, "r");
    printf("");
    
    //Validating file opening
    if (filePointer == NULL) 
    {
        //Returning error if the file does not exist
        return RC_FILE_NOT_FOUND; 
    }
    printf("");
    
    //Assigning the file name to the file handle
    fHandle->fileName = fileName;
    
    //Setting the current page position to the start of the file
    fHandle->curPagePos = 0;
    
    //Defining a structure to hold file metadata
    struct stat fileDetails;
    
    //Obtaining file statistics to determine its size
    printf("");
    if (fstat(fileno(filePointer), &fileDetails) < 0) 
    {
        //Closing file in case of an error
        fclose(filePointer); 
        return RC_ERROR;
    }
    
    //Computing the total number of pages, rounding up for any partial pages
    fHandle->totalNumPages = (fileDetails.st_size + PAGE_SIZE - 1) / PAGE_SIZE;
    printf("");
    
    //Closing the file after retrieving necessary details
    fclose(filePointer);
    
    //Indicating successful execution
    return RC_OK; 
}

/**
 * Function isFilePointerInitialized: Checks if a file pointer is initialized.
 *
 * @param filePtr Pointer to the file.
 *
 * This function verifies whether the given file pointer is initialized (not NULL).
 *
 * @return 1 if the file pointer is initialized, otherwise 0.
 */
int isFilePointerInitialized(FILE *filePtr)
{
    return (filePtr != NULL) ? 1 : 0;
}

/**
 * Function closeFilePointer: Closes a file pointer if it is initialized.
 *
 * @param filePtr Double pointer to the file.
 *
 * This function ensures that the file pointer is properly closed and reset to NULL,
 * preventing any potential dangling references.
 */
void closeFilePointer(FILE **filePtr)
{
    if (*filePtr != NULL)
    {
        //Closing the file
        fclose(*filePtr); 

        //Reseting pointer to NULL
        *filePtr = NULL; 
    }
}

/**
 * Function closePageFile: Closes the currently open page file.
 *
 * @param fHandle Pointer to the file handle structure.
 *
 * This function checks whether the global file pointer is initialized before closing it.
 * It ensures that the file pointer associated with the storage manager is properly closed.
 *
 * @return RC_OK upon successful closure of the file.
 */
extern RC closePageFile(SM_FileHandle *fHandle)
{
    //Ensuring the global file pointer is initialized before closing
    if (fgrp21 != NULL) 
    {
        //Closing and reseting the file pointer
        closeFilePointer(&fgrp21); 
    }
    return RC_OK;
}

/**
 * Function destroyPageFile: Deletes a specified page file from the system.
 *
 * @param fileName Pointer to the name of the file to be deleted.
 *
 * This function first attempts to open the file to verify its existence.
 * If the file is found, it proceeds to delete it. If the deletion fails,
 * an appropriate error code is returned.
 *
 * @return RC_OK if successful, RC_FILE_NOT_FOUND if the file does not exist, or RC_ERROR if deletion fails.
 */
extern RC destroyPageFile(char *fileName)
{
    //Checking if the specified file exists before attempting deletion
    FILE *fileToDelete = fopen(fileName, "r");
    if (fileToDelete == NULL) 
    {
        //File does not exist, then return error
        return RC_FILE_NOT_FOUND; 
    }
    
    //Closing the file after confirming its existence
    fclose(fileToDelete); 

    //Trying to delete the file and check for errors
    if (remove(fileName) != 0) 
    {
        //Returning an error if deletion fails
        return RC_ERROR; 
    }

    //Placeholder here for potential logging
    printf(""); 
    return RC_OK; 
}

/**
 * Function readBlock: Reads a specific page from a file into memory.
 *
 * @param pageNum  The page number to read.
 * @param fHandle  Pointer to the file handle structure.
 * @param memPage  Pointer to the memory location where the page content will be stored.
 *
 * This function reads a specified page from a file and stores its content in the provided
 * memory location. It ensures file validity, verifies page existence, and performs
 * error handling for various failure scenarios.
 *
 * @return RC_OK if the page is read successfully, or an appropriate error code otherwise.
 */
extern RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Validating input parameters
    if (!memPage)
    {
        return RC_WRITE_FAILED;
    }
    
    if (!fHandle)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    if (pageNum < 0 || pageNum >= fHandle->totalNumPages)
    {
        return RC_READ_NON_EXISTING_PAGE;
    }
    
    //Opening the file in read mode
    FILE *filePtr = fopen(fHandle->fileName, "r");
    if (filePtr == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }

    //Calculating the byte offset for the requested page
    int offset = pageNum * PAGE_SIZE;

    //Moving the file pointer to the requested page position
    fseek(filePtr, offset, SEEK_SET);

    //Reading the page data into memory
    if (fread(memPage, sizeof(char), PAGE_SIZE, filePtr) != PAGE_SIZE)
    {
        fclose(filePtr);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Updating the current page position in the file handle
    fHandle->curPagePos = ftell(filePtr);
    
    //Closing the file after reading
    fclose(filePtr);

    return RC_OK;
}

/**
 * Function getBlockPos: Retrieves the current page position in the file handle.
 *
 * @param fHandle Pointer to the file handle structure.
 *
 * This function verifies if the file handle is valid before returning the
 * current page position.
 *
 * @return The current page position if valid, otherwise -1 if the file handle is NULL.
 */
int getBlockPos(SM_FileHandle *fHandle) 
{    
    printf("\nVerifying the file handle validity...\n");
    
    //Checking if file handle is valid
    if (!fHandle)
    {
        return -1;
    }

    printf("\nFile handle validation successful\n");

    printf("Current Block Position : %d\n", fHandle->curPagePos);

    return fHandle->curPagePos;
}

/**
 * Function readFirstBlock: Reads the first block of a file into memory.
 *
 * @param fHandle Pointer to the file handle structure.
 * @param memPage Pointer to the memory buffer where the first block's content will be stored.
 *
 * This function verifies the validity of the file handle and memory buffer before
 * attempting to read the first block (page 0) of the file. If successful, it reads
 * the block into the provided memory buffer.
 *
 * @return RC_OK on success, or an appropriate error code if validation fails.
 */
RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{    
    printf("\nVerifying the null checks for first block in the file : %s\n", fHandle->fileName);

    //Validating input parameters
    if (memPage == NULL)
    {
        return RC_WRITE_FAILED;
    }

    if (fHandle == NULL)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    printf("\nNull checks passed successfully\n");

    //Reading the first block (page 0) from the file
    return readBlock(0, fHandle, memPage);
}

/**
 * Function readPreviousBlock: Reads the previous block relative to the current position.
 *
 * @param fHandle Pointer to the file handle structure.
 * @param memPage Pointer to the memory buffer where the previous block's content will be stored.
 *
 * This function verifies the validity of the file handle and memory buffer before
 * attempting to read the block preceding the current position. If the current
 * position is already at the first block, an error is returned.
 *
 * @return RC_OK on success, or an appropriate error code if validation fails.
 */
RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{    
    printf("\nVerifying the null checks for previous block in the file : %s\n", fHandle->fileName);

    //Validating the input parameters
    if (!memPage)
    {    
        return RC_WRITE_FAILED;
    }

    if (!fHandle)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Getting the current page position
    int currentPageNumber = getBlockPos(fHandle);
    
    //Ensuring there is a previous block available
    if (currentPageNumber - 1 < 0)
    {
        return RC_READ_NON_EXISTING_PAGE;
    }
    printf("\nNull checks passed successfully\n");

    //Reading the previous block (currentPageNumber - 1)
    return readBlock(currentPageNumber - 1, fHandle, memPage);
}

/**
 * Function readCurrentBlock: Reads the block at the current file position.
 *
 * @param fHandle Pointer to the file handle structure.
 * @param memPage Pointer to the memory buffer where the current block's data will be stored.
 *
 * This function ensures that the file handle and memory buffer are valid before
 * attempting to read the block at the current position. If the current position
 * is invalid, an error code is returned.
 *
 * @return RC_OK if successful, or an appropriate error code if validation fails.
 */
RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
    
    printf("\nChecking the validity of the file handle and memory buffer for reading current block : %s\n", fHandle->fileName);

    //Validating that the file handle is not null
    if (fHandle == NULL)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring that the memory buffer is allocated
    if (memPage == NULL)
    {
        return RC_WRITE_FAILED;
    }

    //Retrieving the current page number from the file handle
    int currentPage = getBlockPos(fHandle);
    
    //Verifying that the current page position is valid
    if (currentPage < 0)
    {
        return RC_READ_NON_EXISTING_PAGE;
    }
    printf("\nValidation is successful. Proceeding to read the current block.....\n");

    //Reading the block at the current page position
    return readBlock(currentPage, fHandle, memPage);
}

/**
 * Function readNextBlock: Reads the block following the current position in the file.
 *
 * @param fHandle Pointer to the file handle structure.
 * @param memPage Pointer to the memory buffer where the next block's content will be stored.
 *
 * This function verifies the validity of the file handle and memory buffer before attempting
 * to read the next block. If the current block is the last one in the file, an error is returned.
 *
 * @return RC_OK if successful, or an appropriate error code if validation fails.
 */
RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{   
    printf("\nChecking the file handle and memory buffer before reading next block : %s\n", fHandle->fileName);

    //Ensuring file handle and memory buffer are valid
    if (memPage == NULL)
    {
        return RC_WRITE_FAILED;
    }
    
    if (fHandle == NULL)
    {    
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Retrieving the current page position
    int currentPage = getBlockPos(fHandle);
    
    //Validating that the next block exists within file boundaries
    if (currentPage < 0 || (currentPage + 1) >= fHandle->totalNumPages)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    printf("\nValidation is successful. Proceeding to read the next block.....\n");

    //Reading the next block from the file
    return readBlock(currentPage + 1, fHandle, memPage);
}

/**
 * Function readLastBlock: Reads the last block from the file.
 *
 * @param fHandle Pointer to the file handle structure.
 * @param memPage Pointer to the memory buffer where the last block's content will be stored.
 *
 * This function verifies the validity of the file handle and memory buffer before attempting
 * to read the last block. If the file contains no pages, an error is returned.
 *
 * @return RC_OK if successful, or an appropriate error code if validation fails.
 */
RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{    
    printf("\nChecking the file handle and memory buffer before reading last block : %s\n", fHandle->fileName);

    //Ensuring file handle and memory buffer are valid
    if (fHandle == NULL)
    {
        return RC_FILE_HANDLE_NOT_INIT;
    }
    
    if (memPage == NULL)
    {    
        return RC_WRITE_FAILED;
    }
    
    //Determining the last page number
    int lastPageNumber = fHandle->totalNumPages - 1;
    
    //Ensuring the file contains at least one page
    if (lastPageNumber < 0)
    {
        return RC_READ_NON_EXISTING_PAGE;   
    }

    printf("\nValidation is successful. Proceeding to read the last block......\n");

    //Reading the last block from the file
    return readBlock(lastPageNumber, fHandle, memPage);
}

/**
 * Function writeBlock: Writes data to a specified page in the file.
 *
 * @param pageNum  The target page number for writing data.
 * @param fHandle  Pointer to the file handle structure.
 * @param memPage  Pointer to the memory buffer containing the data to be written.
 *
 * This function writes a block of data to the given page number in the file.
 * It ensures the page number is valid and properly manages writes for both
 * the first page and subsequent pages. If the file reaches the end, an
 * empty block is appended before writing.
 *
 * @return RC_OK if the write operation succeeds, or an appropriate error code otherwise.
 */
extern RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) 
{    
    //Validating page number before proceeding
    printf("");
    if (pageNum < 0 || pageNum > fHandle->totalNumPages)
    {
        return RC_WRITE_FAILED;
    }
    
    //Attempting to open the file in read/write mode
    FILE *filePtr = fopen(fHandle->fileName, "r+");
    
    //Returning an error if the file cannot be opened
    if (filePtr == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }

    //Determining the file offset for writing
    int offset = pageNum * PAGE_SIZE;

    //Handling the write operation for the first page
    if (pageNum == 0) 
    {
        //Moving file pointer to the required position
        fseek(filePtr, offset, SEEK_SET); 

        //Writing PAGE_SIZE bytes from memory buffer to the file
        for (int i = 0; i < PAGE_SIZE; i++) 
        {
            if (feof(filePtr)) 
            {
                //Appending an empty block if EOF is encountered
                appendEmptyBlock(fHandle); 
            }
            fputc(memPage[i], filePtr);
        }

        //Updating file handle to reflect the new position and close the file
        fHandle->curPagePos = ftell(filePtr);
        fclose(filePtr);
    } 
    else 
    {
        //For non-first pages, setting current position and delegate writing
        fHandle->curPagePos = offset;
        fclose(filePtr);

        //Performing write operation for the specified page
        writeCurrentBlock(fHandle, memPage);
    }
    return RC_OK;
}

/**
 * Function writeCurrentBlock: Writes data to the current block in the file.
 *
 * @param fHandle Pointer to the file handle structure.
 * @param memPage Pointer to the memory buffer containing the data to be written.
 *
 * This function writes data to the block at the current position in the file.
 * It ensures the file is opened successfully before proceeding. If necessary,
 * an empty block is appended before writing. The function then moves the file
 * pointer to the appropriate position and writes the provided data.
 *
 * @return RC_OK if the write operation succeeds, or an appropriate error code otherwise.
 */
extern RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) 
{    
    //Attempting to open the file in read/write mode
    FILE *filePtr = fopen(fHandle->fileName, "r+");
    printf("");

    //Validating the file opening
    if (filePtr == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }
    
    //Ensuring sufficient space by appending an empty block if necessary
    appendEmptyBlock(fHandle);

    //Moving the file pointer to the correct position
    fseek(filePtr, fHandle->curPagePos, SEEK_SET);
    printf("");

    //Writing the memory buffer content to the file 
    fwrite(memPage, sizeof(char), PAGE_SIZE, filePtr);
    
    //Updating the file handle to reflect the new position
    fHandle->curPagePos = ftell(filePtr);
    
    //Closing the file after writing
    fclose(filePtr);    
    return RC_OK;
}

/**
 * Function appendEmptyBlock: Appends an empty block to the end of the file.
 *
 * @param fHandle Pointer to the file handle structure.
 *
 * This function creates an empty block initialized with zeros and writes it
 * to the end of the file. If successful, it updates the total number of pages.
 * Proper memory handling and error checks ensure robustness.
 *
 * @return RC_OK if the block is appended successfully, or an appropriate error code otherwise.
 */
extern RC appendEmptyBlock(SM_FileHandle *fHandle) 
{    
    //Allocating memory for an empty block and initialize it with zeros
    SM_PageHandle emptyBlock = (SM_PageHandle)calloc(PAGE_SIZE, sizeof(char));
    
    //Checking if memory allocation was successful
    if (emptyBlock == NULL)
    {
        return RC_MEMORY_ALLOCATION_ERROR;
    }
    
    //Opening the file in read/write mode
    FILE *filePtr = fopen(fHandle->fileName, "r+");
    
    if (filePtr == NULL)
    {
        return RC_FILE_NOT_FOUND;
    }

    //Moving the file pointer to the end of the file
    if (fseek(filePtr, 0, SEEK_END) == 0) 
    {
        //Writing the empty block to extend the file size
        fwrite(emptyBlock, sizeof(char), PAGE_SIZE, filePtr);
        
        //Incrementing the total number of pages 
        fHandle->totalNumPages++;
    } 
    else 
    {
        //Cleaning up in the case of failure
        free(emptyBlock);
        fclose(filePtr);

        return RC_WRITE_FAILED;
    }
    
    //Freeing the allocated memory and closing the file
    free(emptyBlock);
    fclose(filePtr);
    
    return RC_OK;
}

/**
 * Function ensureCapacity: Expands the file to meet the required number of pages.
 *
 * @param numberOfPages The minimum required number of pages.
 * @param fHandle       Pointer to the file handle structure.
 *
 * This function ensures that the file contains at least the specified number of pages.
 * If the file has fewer pages than required, empty blocks are appended until the
 * required capacity is met.
 *
 * @return RC_OK if successful, or RC_FILE_NOT_FOUND if the file cannot be opened.
 */
extern RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle) 
{    
    //Attempting to open file in append mode
    FILE *filePtr = fopen(fHandle->fileName, "a");
    if (filePtr == NULL) 
    {
        return RC_FILE_NOT_FOUND;
    }
    
    //Appending empty blocks until file reaches the required number of pages
    while (fHandle->totalNumPages < numberOfPages) 
    {
        appendEmptyBlock(fHandle);
    }
    
    //Closing the file after capacity adjustment
    fclose(filePtr);
    
    return RC_OK;
}