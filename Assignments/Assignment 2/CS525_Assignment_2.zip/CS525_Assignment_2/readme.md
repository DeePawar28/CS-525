# CS 525 Assignment 2 : Buffer Manager

## Introduction
This assignment involves designing and implementing a **Buffer Manager** that controls memory pages efficiently. The buffer manager interacts with a **storage manager** (developed in Assignment 1) to handle a fixed number of memory pages, optimizing access through different **page replacement strategies**.

---

## Buffer Manager Overview

The **Buffer Manager** serves as an intermediary between the client and disk storage. It manages pages within a **buffer pool**, ensuring optimal page retrieval, replacement, and consistency through tracking pinned and modified pages.

### Functionalities & Concepts

#### **Buffer Pool Management**
- The **buffer pool** consists of fixed-size page frames that store disk pages.
- Clients can **pin** and **unpin** pages as needed.
- Pages are fetched from memory if available; otherwise, they are loaded from disk.
- When unpinned and the fix count reaches zero, pages become eligible for eviction.

#### **Page Replacement Strategies**
- **FIFO (First-In-First-Out)**
- **LRU (Least Recently Used)**
- **Additional Strategies (Extra Credit):**
  - **CLOCK**
  - **LFU (Least Frequently Used)**
  - **LRU-k**

---

## Interface & Implementation

### **Data Structures**
- `BM_BufferPool` - Represents a buffer pool with attributes:
  - `pageFile`: The associated page file.
  - `numPages`: Number of page frames.
  - `strategy`: Page replacement strategy.
  - `mgmtData`: Bookkeeping data for buffer pool management.
- `BM_PageHandle` - Represents a page in memory with:
  - `pageNum`: The page number.
  - `data`: Pointer to the page content in memory.

### **Buffer Pool Functions**

| Function                     | Description                                      |
|------------------------------|--------------------------------------------------|
| `initBufferPool()`            | Initializes a buffer pool.                       |
| `shutdownBufferPool()`        | Cleans up resources and writes dirty pages.     |
| `forceFlushPool()`            | Writes all dirty pages (fix count = 0) to disk. |

### **Page Management Functions**

| Function                     | Description                                      |
|------------------------------|--------------------------------------------------|
| `pinPage()`                   | Loads and pins a page from disk.                |
| `unpinPage()`                 | Decreases the fix count of a page.              |
| `markDirty()`                 | Marks a page as modified.                       |
| `forcePage()`                 | Writes a modified page to disk.                 |

### **Statistics Functions**

| Function                     | Description                                      |
|------------------------------|--------------------------------------------------|
| `getFrameContents()`          | Retrieves pages currently in the buffer pool.   |
| `getDirtyFlags()`             | Indicates dirty pages.                          |
| `getFixCounts()`              | Returns fix counts of pages.                    |
| `getNumReadIO()`              | Tracks total disk reads.                        |
| `getNumWriteIO()`             | Tracks total disk writes.                       |


## Error Handling & Debugging
- **Error Handling:** Implemented in `dberror.h` with error codes and logging.
- **Debugging Tools:**
  - `printPageContent()`: Displays a memory page’s contents.
  - `printPoolContent()`: Summarizes the buffer pool state.

---

## Code Structure

### Directory Layout
```
assign2/
│── README.md
│── Makefile
│── buffer_mgr.h
│── buffer_mgr.c
│── buffer_mgr_stat.c
│── buffer_mgr_stat.h
│── dberror.c
│── dberror.h
│── dt.h
│── storage_mgr.c
│── storage_mgr.h
│── test_assign2_1.c
│── test_assign2_2.c
│── test_helper.h
```

---

## Testing & Validation
- The provided test cases `test_assign2_1.c` validate **FIFO** and **LRU** replacement strategies, and `test_assign2_2.c` validate **CLOCK** and **LFU** replacement strategies.
- Additional test cases using CLOCK and LFU added to check correctness under **concurrent operations**.

---

## Optional Extensions
- **Thread Safety:** Implementing thread safety for multiple concurrent accesses.
- **Advanced Page Replacement Strategies:** CLOCK, LFU, and LRU-k for improved performance.

---

## Build & Test Instructions

1. To Compile the code and build the project.

 ```bash
   make
   ```
2. The executable `test1 and test2` will be generated.

3. To execute test cases from test1 which uses FIFO and LRU page replacement strategies:

 ```bash
./test1 
```
4. To execute test cases from test2 which uses CLOCK and LFU page replacement strategies (For Extra Credit):

 ```bash
./test2 
```

---

## Conclusion
This project focuses on designing a **Buffer Manager** that optimizes memory page handling using various replacement strategies. Proper management of **page pinning, unpinning, and eviction** enhances database efficiency. Advanced improvements like **thread safety** and **additional replacement strategies** further align this system with real-world database implementations.

---
## Documentation Link: https://drive.google.com/file/d/1CYvR5bmsnt4KWttZEwPQlWdvSgP39rSV/view?usp=sharing

## Screenshots of output:

### Using FIFO and LRU page replacement strategies

## 1. https://drive.google.com/file/d/1E2tRBkZNRONFnPg5G10Plvn7Ng_tiLan/view?usp=sharing
## 2. https://drive.google.com/file/d/1Q4ElGy_ea-0AfJjw_ekxsyHj1_eLO9OW/view?usp=sharing
## 3. https://drive.google.com/file/d/1msH0mjZ4WBE0fTAkU0iHwr6DjX6ObD1o/view?usp=sharing

### Using CLOCK and LFU page replacement strategies (For Extra Credit)

## 1. https://drive.google.com/file/d/1XDaHaCwHTBLkowAEwJ7qGj5ExJuFCxW4/view?usp=sharing
## 2. https://drive.google.com/file/d/1XYurWkSj01swDc97g6ii3Wiujz5Gb5pl/view?usp=sharing
## 3. https://drive.google.com/file/d/1IbGjkLixEbouH5mH3NlFWp6omOQCVn3p/view?usp=sharing

---

**Authors**: Ameya Hujare & Deep Pawar & Canyu Chen\
**Course**: CS 525 - Advanced Database Organization\
**Instructor**: Prof. Gerald Balekaki\
**Institution**: Illinois Institute of Technology

