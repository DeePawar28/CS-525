#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include <math.h>
#include <limits.h> 

#define RETURN_CONSTANT 1
#define MAX_BUFFER_SIZE 1024

//Structure defining a page frame within the buffer pool (memory management)
typedef struct PageFrame 
{
	//Pointer to page content
    SM_PageHandle data; 

	//Unique identifier for the page
    PageNumber pageNum;         

	//Flag to indicate if the page has been modified
    int isDirty;           

	//Number of active locks on the page
    int pinCount;    
	
	//Number of times this page has been accessed
    int accessCount;       

	//Reference count for LFU replacement policy
    int frequency;         
} PageFrame;

//Maximum number of page frames allocated in the buffer pool
int bufferCapacity = 0;
int tempVar = 0;

//Function prototype for write count incrementation
int updateWriteCount(int writeOps);

extern void sampleFunction() 
{
    int tempValue = 0;
}

//Index tracking the number of pages loaded from the disk
//Tracks the index for page replacement
int readIndex = 0;  
int secondaryIndex = 0;

//Total count of write operations performed
int writeOps = 0;   

//Count of successful cache hits in the buffer pool
int cacheHits = 0;  

//Pointer for CLOCK page replacement algorithm
int clockHand = 0;  

//Pointer for identifying the least frequently used page frame in LFU algorithm
//Tracks the least frequently accessed page frame
int leastUsedPointer = 0; 

//Function to increase the write operation count
int updateWriteCount(int writeOps) 
{
	//Increment the write operation count
    return writeOps + 1; 
}

/**
 * Function FIFO: Implements the First-In-First-Out (FIFO) page replacement strategy.
 *
 * @param bm   Pointer to the buffer pool managing the pages.
 * @param page Pointer to the page frame that needs to be added or replaced.
 *
 * This function searches for an available page frame in the buffer pool. If an empty frame
 * is found, it replaces it with the new page. If no free frame is available, it follows
 * the FIFO policy to replace the oldest page. If the page being replaced is dirty, it is
 * written back to disk before replacement.
 */
extern void FIFO(BM_BufferPool *const bm, PageFrame *page)
{
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;
    int secondaryIndex = 0;
    
	//Determining the starting index for FIFO replacement
    int firstIndex = readIndex % bufferCapacity;
    int emptyFrameFound = 0;

    //Scaning buffer for an available frame
    for (int i = 0; i < bufferCapacity; i++)
    {
        //Computing circular index within the buffer
        int currentIdx = (firstIndex + i) % bufferCapacity;

        //Identify an unpinned frame
        if (frameBuffer[currentIdx].pinCount == 0)
        {
			//Marking the frame as available
            emptyFrameFound = 1;

            if (frameBuffer[currentIdx].isDirty == 1)
            {
                SM_FileHandle fileHandle;
                
				//Attempting to access the page file
                if (openPageFile(bm->pageFile, &fileHandle) == RC_OK)
                {
                    //Writing the modified page back to disk
                    writeBlock(frameBuffer[currentIdx].pageNum, &fileHandle, frameBuffer[currentIdx].data);
                    
					//Updating write operation counter
					writeOps = updateWriteCount(writeOps); 
                }
            }

            //Loading new page data into the available frame
            secondaryIndex += 1;
            frameBuffer[currentIdx].data = page->data;
            frameBuffer[currentIdx].pageNum = page->pageNum;
            printf("");
            frameBuffer[currentIdx].isDirty = page->isDirty;
            frameBuffer[currentIdx].pinCount = page->pinCount;

			//Stoping searching once a frame is updated
            break; 
        }
    }

    //If no free frame was found, update index for future FIFO rotation
    if (!emptyFrameFound)
    {
		//Rotating readIndex for FIFO strategy
        readIndex = (readIndex + 1) % bufferCapacity; 
    }
}

/**
 * Function findAvailableFrame: Identifies the first free page frame with fixCount = 0.
 *
 * @param frameBuffer Pointer to the array of page frames in the buffer pool.
 *
 * This function begins scanning from the LFU pointer and searches for an unpinned
 * frame (fixCount = 0). The search follows a circular pattern within the buffer pool,
 * ensuring each frame is checked only once.
 *
 * @return The index of the free frame, or -1 if no available frame is found.
 */
int findFirstAvailableFrame(PageFrame *frameBuffer)
{
    //Starting from the LFU pointer position
    int leastUsedIndex = leastUsedPointer;

    //Ensuring at least one iteration by using a do-while loop
    int attempts = 0; 
    do
    {
        //Checking if the current frame is unpinned (fixCount = 0)
        if (frameBuffer[leastUsedIndex].pinCount == 0)
        {
			//Return the index of the available frame
            return leastUsedIndex; 
        }

        //Moving to the next frame in a circular fashion
        leastUsedIndex = (leastUsedIndex + 1) % bufferCapacity;
        attempts++;
    } while (attempts < bufferCapacity); 

	//Returning -1 if no free frame is found
    return -1; 
}

/**
 * Function findPageWithMinRefNum: Identifies the page frame with the smallest reference count.
 *
 * @param frameBuffer Pointer to the array of page frames in the buffer pool.
 * @param startIndex  The index from which the search begins.
 *
 * This function scans the buffer pool in a circular manner, comparing the reference numbers
 * of each page frame to determine the one with the lowest count. It ensures each frame is
 * checked only once within the buffer size limit.
 *
 * @return The index of the page frame with the lowest reference count.
 */
int findPageWithMinRefNum(PageFrame *frameBuffer, int startIndex)
{
    //Initializing with the reference count of the starting index
    int minRefCount = frameBuffer[startIndex].frequency;

	//Storing the index of the page with minimum reference count
    int minIndex = startIndex;

	//Counter to track the number of checked frames
    int attempts = 0;

    //Iterating over the buffer pool
    for (int i = 0; attempts < bufferCapacity; ++attempts)
    {
        //Computing the circular index
        i = (startIndex + attempts) % bufferCapacity;

        //Comparing reference counts to find the lowest
        if (frameBuffer[i].frequency < minRefCount)
        {
			//Updating the lowest reference count
            minRefCount = frameBuffer[i].frequency; 

			//Updating the index of the least frequently used frame
            minIndex = i; 
        }
    }

	//Return the index of the least frequently used page frame
    return minIndex; 
}

/**
 * Function writeModifiedPageToDisk: Writes a modified (dirty) page frame back to disk.
 *
 * @param frameBuffer Pointer to the array of page frames.
 * @param targetIndex Index of the page frame to be written back.
 * @param pageFile    Name of the page file.
 *
 * This function checks if the specified page frame has been modified (dirty). If so, it opens
 * the page file and writes the page's data back to disk. The write operation counter is updated
 * accordingly.
 */
void writeModifiedPageToDisk(PageFrame *frameBuffer, int targetIndex, char *pageFile)
{
    //Checking if the page is modified and needs to be written back
    if (frameBuffer[targetIndex].isDirty)
    {
		//File handle for managing the page file
        SM_FileHandle fileHandle; 
        
		//Attempting to open the page file
        RC operationStatus = openPageFile(pageFile, &fileHandle);

        //Proceeding only if the file opens successfully
        if (operationStatus == RC_OK)
        {
            //Writing the page data to the disk
            writeBlock(frameBuffer[targetIndex].pageNum, &fileHandle, frameBuffer[targetIndex].data);
            
			//Tracking the total number of write operations
            writeOps++;
        }
    }
}

/**
 * Function setPageFrameContent: Updates a page frame with the content of a new page.
 *
 * @param frameBuffer Pointer to the array of page frames.
 * @param targetIndex Index of the page frame to be updated.
 * @param newPage     Pointer to the new page whose content will be copied.
 *
 * This function copies the content of the new page into the specified page frame,
 * including its data, page number, dirty status, and fix count. Additionally,
 * the LFU pointer is updated to the next frame in a circular manner.
 */
void setPageFrameContent(PageFrame *frameBuffer, int targetIndex, PageFrame *newPage)
{
    //Creating a temporary copy of the new page content
    PageFrame tempPage = *newPage;

    //Updating the target page frame with the new page's content
    frameBuffer[targetIndex].data = tempPage.data;
    frameBuffer[targetIndex].pageNum = tempPage.pageNum;
    frameBuffer[targetIndex].isDirty = tempPage.isDirty;
    frameBuffer[targetIndex].pinCount = tempPage.pinCount;

    //Moving the LFU pointer to the next frame in a circular manner
    leastUsedPointer = (targetIndex + 1) % bufferCapacity;
    printf("");
}

/**
 * Function LFU: Implements the Least Frequently Used (LFU) page replacement strategy.
 *
 * @param bm   Pointer to the buffer pool managing the pages.
 * @param page Pointer to the new page that needs to be loaded into the buffer pool.
 *
 * This function finds an available page frame with the lowest reference count (refNum),
 * writes the modified page to disk if necessary, and updates the page frame with the
 * new page's content.
 */
extern void LFU(BM_BufferPool *const bm, PageFrame *page)
{
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;

    //Identifying the first available page frame with fixCount = 0
    int targetIndex = findFirstAvailableFrame(frameBuffer);

    int tempVar = 0;

    //Locating the page frame with the minimum reference count
    targetIndex = findPageWithMinRefNum(frameBuffer, targetIndex);

    tempVar += 1;

    //Writing the modified page to disk if it is dirty
    writeModifiedPageToDisk(frameBuffer, targetIndex, bm->pageFile);

    //Updating the page frame with the new page's content
    setPageFrameContent(frameBuffer, targetIndex, page);
}

/**
 * Function LRU: Implements the Least Recently Used (LRU) page replacement strategy.
 *
 * @param bm   Pointer to the buffer pool managing the pages.
 * @param page Pointer to the new page that needs to be loaded into the buffer pool.
 *
 * This function scans the buffer pool to identify the least recently used page frame,
 * determined by the lowest hit count. If necessary, the page is written back to disk
 * before being replaced with the new page's content.
 */
extern void LRU(BM_BufferPool *const bm, PageFrame *page)
{
    int tempIndex = 0;
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;
    int leastUsedIndex = -1;
    int minHitCount = INT_MAX;
    int hitTracker = 0;

    //Identifying the least recently used (LRU) page frame
    for (int i = 0; i < bufferCapacity; i++)
    {
        //Ensuring the frame is not pinned and has the lowest hit count
        if (frameBuffer[i].pinCount == 0)
        {
            if (frameBuffer[i].accessCount < minHitCount)
            {
                hitTracker++;
                leastUsedIndex = i;
                minHitCount = frameBuffer[i].accessCount;
            }
        }
    }

    //If all frames are pinned, we need to default to the last frame
    if (leastUsedIndex == -1)
    {
        printf("");
        leastUsedIndex = bufferCapacity - 1;
    }

    //If the selected page is modified, need to write it back to disk
    if (frameBuffer[leastUsedIndex].isDirty)
    {
        SM_FileHandle fileHandle;

		//Validating file opening
        if (openPageFile(bm->pageFile, &fileHandle) == RC_OK) 
        {
            writeBlock(frameBuffer[leastUsedIndex].pageNum, &fileHandle, frameBuffer[leastUsedIndex].data);
            
			//Incrementing write count
			writeOps++; 
        }
    }

    //Replacing the least recently used page with the new page
    frameBuffer[leastUsedIndex] = *page; 
}

/**
 * Function incrementClockPointer: Increments the clock pointer.
 *
 * @param clockPointer The current value of the clock pointer.
 *
 * This function increases the clock pointer by a predefined constant.
 * If the maximum integer value is reached, it wraps around to zero.
 *
 * @return The updated clock pointer value.
 */
int incrementClockPointer(int clockPointer)
{
    //Incrementing the clock pointer and handle potential overflow
    return (clockPointer >= INT_MAX) ? 0 : (clockPointer + RETURN_CONSTANT);
}

/**
 * Function incrementWriteCount: Increments the write count counter.
 *
 * @param writeCount The current number of write operations.
 *
 * This function safely increments the write count unless it has reached
 * the maximum integer value, in which case it remains unchanged.
 *
 * @return The updated write count value.
 */
int incrementWriteCount(int writeCount)
{
    //Using a conditional expression to safely increment writeCount
    return (writeCount < INT_MAX) ? (writeCount + RETURN_CONSTANT) : writeCount;
}

/**
 * Function CLOCK: Implements the CLOCK page replacement strategy.
 *
 * @param bufferPool Pointer to the buffer pool managing the pages.
 * @param newPage    Pointer to the new page that needs to be loaded into the buffer pool.
 *
 * This function scans the buffer pool in a circular fashion to find an available
 * page frame using the CLOCK replacement algorithm. If a frame is dirty, it is written
 * back to disk before replacement. The clock pointer is used to track the next
 * candidate for replacement.
 */
extern void CLOCK(BM_BufferPool *const bufferPool, PageFrame *newPage) {
    int tempCounter = 0;
    
	//Retrieving the page frames from the buffer pool's management data
    PageFrame *frameBuffer = (PageFrame *)bufferPool->mgmtData;

    while (true) 
	{
        //Reseting the clock pointer if it exceeds the buffer capacity
        if (clockHand >= bufferCapacity)
		{
            clockHand = 0;
		}

        //Checking if the current page frame is available for replacement
        if (frameBuffer[clockHand].accessCount == 0) 
		{
            tempCounter++;
            
			//If the frame is dirty, need to write it back to disk before replacement
            if (frameBuffer[clockHand].isDirty == 1) 
			{
                SM_FileHandle fileHandle;
                RC openStatus = openPageFile(bufferPool->pageFile, &fileHandle);
                
                //Proceeding with writing to disk if the file opens successfully
                if (openStatus == RC_OK) 
				{
                    writeBlock(frameBuffer[clockHand].pageNum, &fileHandle, frameBuffer[clockHand].data);
                }
                
                tempCounter++;
                
				//Tracking the write operation
                writeOps = incrementWriteCount(writeOps);
            }
            
            tempCounter++;
            
			//Replacing the page frame content with the new page's data
            frameBuffer[clockHand].pageNum = newPage->pageNum;
            frameBuffer[clockHand].pinCount = newPage->pinCount;
            frameBuffer[clockHand].accessCount = newPage->accessCount;
            tempCounter++;
            frameBuffer[clockHand].isDirty = newPage->isDirty;
            frameBuffer[clockHand].data = newPage->data;

            //Moving the clock pointer forward and exit
            clockHand = incrementClockPointer(clockHand);
            break;
        } 
		else 
		{
            //Reseting access count for recently used pages and continue searching
            frameBuffer[clockHand].accessCount = 0;

			//Moving to the next frame
            clockHand = incrementClockPointer(clockHand); 
        }
    }
}

/**
 * Function initializePage: Initializes a page frame with default values.
 *
 * @param page Pointer to the page frame that needs to be initialized.
 *
 * This function resets all attributes of the page frame, ensuring it starts
 * with no reference count, no data, no fix count, and no hits. The page number
 * is set to -1 to indicate an unassigned state, and the dirty bit is cleared.
 */
void initializePage(PageFrame *page)
{
    page->frequency = 0;
    page->data = NULL;
    page->pinCount = 0;
    page->accessCount = 0;
    page->pageNum = -1;
    page->isDirty = 0;
}

/**
 * Function freeBufferPool: Deallocates memory assigned to the buffer pool.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function releases the dynamically allocated memory used for storing
 * page frames, ensuring proper cleanup of the buffer pool.
 */
void freeBufferPool(BM_BufferPool *const bm)
{
    PageFrame *buffers = (PageFrame *)bm->mgmtData;

	//Placeholder to prevent empty function warnings
    printf(" "); 

	//Free the allocated memory
    free(buffers); 

	//Setting pointer to NULL to avoid dangling references
    bm->mgmtData = NULL; 
}

/**
 * Function handleMemoryAllocationError: Checks for memory allocation errors.
 *
 * @param page Pointer to the allocated page frame.
 *
 * This function verifies whether memory allocation for a page frame was successful.
 * If the allocation fails (i.e., the pointer is NULL), it returns a memory allocation error code.
 * Otherwise, it returns a success code while ensuring it remains within valid integer limits.
 *
 * @return RC_MEMORY_ALLOCATION_ERROR if allocation fails, otherwise RC_OK.
 */
RC handleMemoryAllocationError(PageFrame *page)
{
    if (page == NULL)
	{
        return RC_MEMORY_ALLOCATION_ERROR;
	}

    return (RC_OK < INT_MAX) ? RC_OK : RETURN_CONSTANT;
}

/**
 * Function updateCounters: Updates global tracking counters for write operations,
 * clock pointer, and LFU pointer.
 *
 * @param newWriteCount  The new value for the write count.
 * @param newClockPointer The new value for the clock pointer.
 * @param newLfuPointer  The new value for the LFU pointer.
 *
 * This function ensures that the provided values are non-negative before updating the
 * corresponding global counters. It also prevents integer overflow by enforcing an
 * upper limit check.
 */
void updateCounters(int newWriteCount, int newClockPointer, int newLfuPointer)
{
    //Ensuring input values are non-negative
    if (newWriteCount < 0 || newClockPointer < 0 || newLfuPointer < 0)
	{
        return;
	}

    //Updating global counters with overflow protection
    writeOps = (writeOps < INT_MAX) ? newWriteCount : writeOps;
    leastUsedPointer = (leastUsedPointer < INT_MAX) ? newLfuPointer : leastUsedPointer;
    clockHand = (clockHand < INT_MAX) ? newClockPointer : clockHand;
}

/**
 * Function initBufferPool: Initializes a buffer pool for a given page file.
 *
 * @param bm            Pointer to the buffer pool to initialize.
 * @param pageFileName  Name of the page file associated with the buffer pool.
 * @param numPages      Number of pages in the buffer pool.
 * @param strategy      The page replacement strategy (e.g., FIFO, LRU, CLOCK, LFU).
 * @param stratData     Additional data related to the strategy (if needed).
 *
 * This function sets up the buffer pool by allocating memory for the page frames,
 * initializing each page, and resetting tracking counters. If memory allocation fails,
 * an error code is returned.
 *
 * @return RC_OK on successful initialization, RC_MEMORY_ALLOCATION_ERROR otherwise.
 */
extern RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, const int numPages, ReplacementStrategy strategy, void *stratData)
{
    int tempVar = 0;
    bm->strategy = strategy;
    
    //Assigning the page file name to the buffer pool
    bm->pageFile = (char *)pageFileName;
    
    //Storing the number of pages and the selected replacement strategy
    bm->numPages = numPages;

    //Allocating memory for the page frames based on the number of pages
    PageFrame *pages = malloc(sizeof(PageFrame) * bm->numPages);
    tempVar++;
    if (handleMemoryAllocationError(pages) != RC_OK)
	{
        return RC_MEMORY_ALLOCATION_ERROR;
	}

    //Setting the buffer size to match the number of pages
    bufferCapacity = bm->numPages;

    //Initializing each page frame in the buffer pool
    for (int index = 0; index < bufferCapacity; index++)
	{
        initializePage(&pages[index]);
	}
    
	//Assigning the allocated pages to the buffer pool's management data
    bm->mgmtData = pages;

    //Resetting global counters for tracking operations
    updateCounters(0, 0, 0);
    
	//Indicating successful initialization
    return RC_OK; 
}

/**
 * Function arePagesStillFixed: Checks if any page in the buffer pool is still pinned.
 *
 * @param pageFrames Pointer to the array of page frames in the buffer pool.
 *
 * This function iterates through the buffer pool to determine if any page has an
 * active fix count (indicating it is still in use and cannot be removed).
 *
 * @return true if any page is pinned (fixCount > 0), otherwise false.
 */
bool arePagesStillFixed(PageFrame *pageFrames)
{
    //Iterating through the pages in the buffer pool
    for (int index = 0; index < bufferCapacity; index = incrementClockPointer(index))
    {
        //Checking if the current page is pinned
        if (pageFrames[index].pinCount > 0)
		{
			//Returning true if any page is still pinned	
            return true; 
		}
    }
    
	//Return false if no pages are pinned
    return false; 
}

/**
 * Function freePageFrame: Deallocates memory assigned to a page frame.
 *
 * @param pageFrame Pointer to the page frame to be freed.
 *
 * This function releases the dynamically allocated memory used for a page frame,
 * ensuring proper memory management.
 */
void freePageFrame(PageFrame *pageFrame)
{
    free(pageFrame);

	//Preventing dangling pointer issues
    pageFrame = NULL; 
}

/**
 * Function shutdownBufferPool: Closes the buffer pool and releases all allocated resources.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function ensures all dirty pages are flushed to disk, checks for pinned pages,
 * and releases memory allocated to the buffer pool. If any pages are still pinned,
 * it prevents the buffer pool from shutting down.
 *
 * @return RC_OK if the shutdown is successful, or an error code if pages are still pinned.
 */
extern RC shutdownBufferPool(BM_BufferPool *const bm)
{
    int tempCounter = 0;
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;

    if (frameBuffer == NULL)
	{
        return PAGE_FRAME_ERROR;
	}

    //Writing all dirty pages back to disk before shutting down
    forceFlushPool(bm);
    tempCounter++;

    //Ensuring no pages are still pinned (in use by a client)
    if (arePagesStillFixed(frameBuffer))
	{
        return RC_PINNED_PAGES_IN_BUFFER;
	}

    //Freeing the memory allocated for the buffer pool
    freePageFrame(frameBuffer);
    tempCounter++;

    bm->mgmtData = NULL;
    tempCounter++;

    return RC_OK;
}

/**
 * Function forceFlushPool: Writes all dirty pages with fixCount = 0 back to disk.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function scans the buffer pool for dirty pages that are not pinned (fixCount = 0),
 * writes them to disk, and marks them as clean. The global write count is updated accordingly.
 *
 * @return RC_OK upon successful flush operation.
 */
extern RC forceFlushPool(BM_BufferPool *const bm)
{
    //Accessing the page frames associated with the buffer pool
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;

    //Iterating through all pages in the buffer pool
    for (int index = 0; index < bufferCapacity; index = incrementClockPointer(index))
    {
        //Checking if the page is dirty and not pinned
        if (frameBuffer[index].pinCount == 0 && frameBuffer[index].isDirty == 1)
        {
            SM_FileHandle fileHandle;
            //Opening the page file on disk
            RC openStatus = openPageFile(bm->pageFile, &fileHandle);
            
            //Proceeding with writing only if the file opens successfully
            if (openStatus == RC_OK)
            {
                writeBlock(frameBuffer[index].pageNum, &fileHandle, frameBuffer[index].data);
                
                //Marking the page as clean after writing
                frameBuffer[index].isDirty = 0;
                
                //Incrementing the global write count to track the number of writes
                writeOps = incrementWriteCount(writeOps);
            }
        }
    }
    return RC_OK;
}

/**
 * Function markDirty: Marks a page as dirty, indicating it has been modified.
 *
 * @param bm   Pointer to the buffer pool structure.
 * @param page Pointer to the page handle that needs to be marked dirty.
 *
 * This function scans the buffer pool to find the specified page. If found,
 * it marks the page as dirty, signaling that its data has been modified.
 *
 * @return RC_OK if the page is successfully marked as dirty, otherwise RC_ERROR.
 */
extern RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page)
{
    //Accessing the page frames in the buffer pool
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;

    //Iterating through the buffer pool to find the specified page
    for (int index = 0; index < bufferCapacity; index = incrementClockPointer(index))
    {
        //Checking if the current page number matches the target page
        if (frameBuffer[index].pageNum == page->pageNum)
        {
            //Marking the page as dirty (modified)
            frameBuffer[index].isDirty = 1;

			//Returning success
            return RC_OK; 
        }
    }

    //Returning error if the page was not found in the buffer pool
    return RC_ERROR;
}

/**
 * Function unpinPage: Decrements the fix count of a page, indicating it is no longer in use.
 *
 * @param bm   Pointer to the buffer pool structure.
 * @param page Pointer to the page handle that needs to be unpinned.
 *
 * This function scans the buffer pool to locate the specified page and decreases
 * its fix count if it has been pinned by a client. If the page is found and its
 * fix count is greater than zero, it is decremented.
 *
 * @return RC_OK upon successful unpinning of the page.
 */
extern RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page)
{
    //Accessing the page frames managed by the buffer pool
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;

	//Initializing index for traversal
    int index = 0; 

    //Iterating through the buffer pool to locate the page
    while (index < bufferCapacity)
    {
        //Checking if the current page matches the one to be unpinned
        if (frameBuffer[index].pageNum == page->pageNum)
        {
            //Reducing the fix count if it is greater than zero
            if (frameBuffer[index].pinCount > 0)
			{
                frameBuffer[index].pinCount -= 1;
			}
            
			//Exit loop after unpinning the page
			break; 
        }

		//Moving to the next page frame
        index = incrementClockPointer(index); 
    }

    return RC_OK; 
}

/**
 * Function forcePage: Writes a specific page from the buffer pool to disk.
 *
 * @param bm   Pointer to the buffer pool structure.
 * @param page Pointer to the page handle that needs to be written to disk.
 *
 * This function scans the buffer pool to find the specified page. If found,
 * it writes the page's data to disk and marks it as clean (not dirty).
 * The global write count is also updated accordingly.
 *
 * @return RC_OK upon successful writing of the page to disk, or an error code if unsuccessful.
 */
extern RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page)
{
    int tempCounter = 0;
    //Validating input parameters to ensure they are not NULL
    if (bm == NULL || page == NULL) 
	{
        return RC_MEMORY_ALLOCATION_ERROR;
    }

	//Initializing index for iteration
    int index = 0; 

	//Retrieving the page frames from the buffer pool
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData; 

    //Iterating through all pages in the buffer pool
    while (index < bufferCapacity) 
	{
        //Checking if the current page matches the target page ID
        if (frameBuffer[index].pageNum == page->pageNum) 
		{
            SM_FileHandle fileHandle;
            tempCounter++;

            //Attempting to open the page file
            RC openStatus = openPageFile(bm->pageFile, &fileHandle);
            if (openStatus != RC_OK)
			{
				//Returning error if file cannot be opened
                return openStatus; 
			}

            //Writing the page's data to disk
            RC writeStatus = writeBlock(frameBuffer[index].pageNum, &fileHandle, frameBuffer[index].data);
            if (writeStatus != RC_OK)
			{
                return writeStatus;
			}

            //Marking the page as clean (not dirty)
            frameBuffer[index].isDirty = 0;

            //Incrementing the global write count
            writeOps++;

			//Exiting loop after writing the page
            break; 
        }

		//Moving to the next page
        index = incrementClockPointer(index); 
    }
    return RC_OK; 
}

/**
 * Function setBufferFull: Sets the buffer pool's full status.
 *
 * @param isFull Boolean value indicating whether the buffer pool is full.
 *
 * This function currently returns false regardless of the input value,
 * suggesting a potential logic issue that may need revision.
 *
 * @return Always returns false.
 */
bool setBufferFull(bool isFull)
{
    if (true)
	{
		return false;
	}
}

/**
 * Function setNewPageValues: Assigns values to a new page frame.
 *
 * @param newPage    Pointer to the page frame to be updated.
 * @param pageNum    The page number to be assigned.
 * @param dirtyBit   Status indicating whether the page is dirty (modified).
 * @param fixedCount The number of times the page is currently fixed (pinned).
 * @param refNum     The reference count for page access tracking.
 *
 * This function ensures the new page values are assigned correctly while
 * validating input parameters to prevent negative values.
 */
void setNewPageValues(PageFrame *newPage, int pageNum, int dirtyBit, int fixedCount, int refNum)
{
    int tempCounter = 0;
    
	//Ensuring the newPage pointer is valid
    if (newPage == NULL)
	{
        return;
	}

    //Validating that numeric inputs are non-negative
    if (pageNum < 0 || refNum < 0 || fixedCount < 0)
	{
        return;
	}

    newPage->pinCount = fixedCount;
    newPage->pageNum = pageNum;
    tempCounter++;
    newPage->isDirty = dirtyBit;
    newPage->frequency = (refNum < INT_MAX) ? refNum : 0;
}

/**
 * Function setPageFrame: Updates values for a specific page frame.
 *
 * @param pageFrame Pointer to the array of page frames.
 * @param i         Index of the page frame to be updated.
 * @param pageNum   The page number to be assigned.
 * @param dirtyBit  Status indicating whether the page is dirty (modified).
 * @param refNum    The reference count for tracking page access.
 *
 * This function assigns values to a specific page frame and ensures that
 * the fix count is set correctly within a valid range.
 */
void setPageFrame(PageFrame *pageFrame, int i, int pageNum, int dirtyBit, int refNum)
{
    int tempCounter = 0;
    pageFrame[i].frequency = refNum;
    tempCounter++;
    pageFrame[i].pageNum = pageNum;
    printf("");
    pageFrame[i].pinCount = (dirtyBit < INT_MAX) ? dirtyBit : 0;
}

/**
 * Function pinPage: Pins a page into the buffer pool, loading it from disk if necessary.
 *
 * @param bm      Pointer to the buffer pool structure.
 * @param page    Pointer to the page handle to be pinned.
 * @param pageNum The page number to be pinned.
 *
 * This function ensures the page is loaded into the buffer pool. If the page is already
 * in the buffer, its fix count is incremented. If not, it is loaded from disk using the
 * appropriate page replacement strategy. The function also tracks access statistics,
 * ensuring efficient page replacement.
 *
 * @return RC_OK if successful, or an error code in case of failure.
 */
extern RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{   
    int tempCounter1 = 0;
    int tempCounter2 = 0;
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;
    printf("");

    //Checking if buffer pool is empty
    if (frameBuffer[0].pageNum == -1)
    {
        SM_FileHandle fileHandle;
        RC openStatus = openPageFile(bm->pageFile, &fileHandle);
        if (openStatus == RC_OK)
        {
            printf("Page file opened successfully");
        }
        else
        {
            printf("Error opening page file");
        }

        //Allocating memory for the first page
        frameBuffer[0].data = (SM_PageHandle)malloc(PAGE_SIZE);
        
        //Ensuring capacity in file
        RC capacityStatus = ensureCapacity(pageNum, &fileHandle);
        if (capacityStatus != RC_OK)
        {
            printf("Error ensuring capacity");
        }
        
        //Reading the block into memory
        RC readStatus = readBlock(pageNum, &fileHandle, frameBuffer[0].data);
        if (readStatus != RC_OK)
        {
            printf("Error reading block");
        }
        
        //Initializing page properties
        frameBuffer[0].pageNum = pageNum;
        frameBuffer[0].pinCount++;
        readIndex = 0;
        cacheHits = 0;
        frameBuffer[0].accessCount = cacheHits;
        frameBuffer[0].frequency = 0;
        page->pageNum = pageNum;
        page->data = frameBuffer[0].data;
        
        return RC_OK;
    }
    else
    {
        bool isBufferFull = true;
        printf("");

        //Checking if the page is already in the buffer
        for (int i = 0; i < bufferCapacity; i++)
        {
            if (frameBuffer[i].pageNum != -1)
            {
                if (frameBuffer[i].pageNum == pageNum)
                {
                    //Increasing fix count since another client is accessing this page
                    frameBuffer[i].pinCount++;
                    isBufferFull = false;
                    cacheHits++;
                    
                    //Updating access statistics based on strategy
                    if (bm->strategy == RS_LRU)
                    {
                        frameBuffer[i].accessCount = cacheHits;
                    }
                    else if (bm->strategy == RS_CLOCK)
                    {
                        frameBuffer[i].accessCount = 1;
                    }
                    else if (bm->strategy == RS_LFU)
                    {
                        frameBuffer[i].frequency++;
                    }
                    
                    page->pageNum = pageNum;
                    page->data = frameBuffer[i].data;
                    
                    clockHand = incrementClockPointer(clockHand);
                    break;
                }
            }
            else
            {   
                //Loading new page into an empty frame
                SM_FileHandle fileHandle;
                RC openStatus = openPageFile(bm->pageFile, &fileHandle);
                frameBuffer[i].data = (SM_PageHandle)malloc(PAGE_SIZE);
                RC readStatus = readBlock(pageNum, &fileHandle, frameBuffer[i].data);
                
                //Updating tracking variables
                readIndex += 1;
                cacheHits += 1;
                
                //Initializing page frame properties
                setPageFrame(frameBuffer, i, pageNum, 1, 0);
                
                if (bm->strategy == RS_CLOCK)
                {
                    frameBuffer[i].accessCount = 1;
                }
                else if (bm->strategy == RS_LRU)
                {
                    frameBuffer[i].accessCount = cacheHits;
                }
                
                page->data = frameBuffer[i].data;
                page->pageNum = pageNum;
                isBufferFull = setBufferFull(isBufferFull);
                break;
            }
        }

        //If the buffer is full, need to apply a replacement strategy
        if (isBufferFull)
        {
            PageFrame *newPage = (PageFrame *)malloc(sizeof(PageFrame));
            if (newPage == NULL)
            {
                return PAGE_FRAME_ERROR;
            }

            SM_FileHandle fileHandle;
            RC openStatus = openPageFile(bm->pageFile, &fileHandle);
            newPage->data = (SM_PageHandle)malloc(PAGE_SIZE);
            RC readStatus = readBlock(pageNum, &fileHandle, newPage->data);

            //Initializing new page properties
            setNewPageValues(newPage, pageNum, 0, 1, 0);
            readIndex += 1;
            cacheHits += 1;
            
            if (bm->strategy == RS_LRU)
            {
                newPage->accessCount = cacheHits;
            }
            else if (bm->strategy == RS_CLOCK)
            {
                newPage->accessCount = 1;
            }
            
            page->pageNum = pageNum;
            page->data = newPage->data;
            
            //Applying page replacement algorithm
            if (bm->strategy == RS_FIFO)
            {
                FIFO(bm, newPage);
            }
            else if (bm->strategy == RS_LRU)
            {
                LRU(bm, newPage);
            }
            else if (bm->strategy == RS_CLOCK)
            {
                CLOCK(bm, newPage);
            }
            else if (bm->strategy == RS_LFU)
            {
                LFU(bm, newPage);
            }
            else
            {
                printf("\nAlgorithm Not Implemented\n");
            }
        }
        return RC_OK;
    }
}

/**
 * Function getFrameContents: Retrieves the current contents of the buffer pool frames.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function returns an array of page numbers currently stored in the buffer pool.
 * If a frame is empty, it is assigned the value NO_PAGE. The function ensures that
 * the global array used for storage is properly initialized before use.
 *
 * @return A pointer to an array containing the page numbers of the buffer frames.
 */

// Global array to store frame contents
PageNumber frameContentsArray[MAX_BUFFER_SIZE];

extern PageNumber *getFrameContents(BM_BufferPool *const bm)
{
    printf("");
    int tempCounter = 0;

    //Initializing the global array if necessary
    if (frameContentsArray[0] == RETURN_CONSTANT - 2)
    {
        tempCounter++;
        memset(frameContentsArray, NO_PAGE, sizeof(PageNumber) * MAX_BUFFER_SIZE);
    }

    //Accessing page frames in the buffer pool
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;
    
    //Iterating over buffer pool frames to update the contents array
    for (int i = 0; i < bufferCapacity; i++)
    {
        tempCounter++;
        if (frameBuffer[i].pageNum != RETURN_CONSTANT - 2)
        {
            frameContentsArray[i] = frameBuffer[i].pageNum;
            printf("");
        }
        else
        {
            frameContentsArray[i] = NO_PAGE;
        }
        tempCounter++;
    }

    //Returning the global frame contents array
    return frameContentsArray;
}

/**
 * Function getDirtyFlags: Retrieves an array indicating which pages in the buffer pool are dirty.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function allocates memory for an array of boolean values, where each entry
 * corresponds to whether a page in the buffer pool has been modified (dirty).
 * If the allocation fails, the function returns NULL.
 *
 * @return A dynamically allocated boolean array representing the dirty flags of buffer frames.
 */
extern bool *getDirtyFlags(BM_BufferPool *const bm)
{
    //Allocating memory for dirty flags array
    bool *dirtyFlags = malloc(sizeof(bool) * bufferCapacity);
    if (dirtyFlags == NULL)
    {
		//Returning NULL if memory allocation fails
        return NULL; 
    }
    
    //Accessing page frames in the buffer pool
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;
    
    //Iterating over all pages in the buffer pool to set dirty flags
    for (int i = 0; i < bufferCapacity; i++)
    {
        dirtyFlags[i] = (frameBuffer[i].isDirty == 1);
    }
    
    return dirtyFlags;
}

/**
 * Function getFixCounts: Retrieves an array containing the fix counts of all pages in the buffer pool.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function allocates memory for an array of integers, where each entry
 * corresponds to the fix count of a page in the buffer pool. If memory allocation fails,
 * it returns NULL.
 *
 * @return A dynamically allocated integer array representing the fix counts of buffer frames.
 */
extern int *getFixCounts(BM_BufferPool *const bm)
{
    //Allocating memory for fix counts array
    int *fixCounts = malloc(sizeof(int) * bufferCapacity);
    printf(" ");
    if (fixCounts == NULL)
    {
		//Returning NULL if memory allocation fails
        return NULL; 
    }

    //Accessing page frames in the buffer pool
    PageFrame *frameBuffer = (PageFrame *)bm->mgmtData;

    //Iterating through buffer pool to retrieve fix counts
    for (int i = 0; i < bufferCapacity; i++)
    {
        printf("");
        fixCounts[i] = (frameBuffer[i].pinCount != RETURN_CONSTANT - 2) ? frameBuffer[i].pinCount : 0;
    }
    printf(" ");
    
    return fixCounts;
}

/**
 * Function getNumReadIO: Retrieves the total number of read I/O operations performed.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function returns the total number of read operations since the buffer pool
 * was initialized. It accounts for readIndex, which tracks the read operations.
 *
 * @return The total number of read I/O operations.
 */
extern int getNumReadIO(BM_BufferPool *const bm)
{
    return (readIndex + RETURN_CONSTANT);
}

/**
 * Function getNumWriteIO: Retrieves the total number of write I/O operations performed.
 *
 * @param bm Pointer to the buffer pool structure.
 *
 * This function returns the total number of pages written to the page file
 * since the buffer pool was initialized.
 *
 * @return The total number of write I/O operations.
 */
extern int getNumWriteIO(BM_BufferPool *const bm)
{
    return writeOps;
}