//Include the required libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "record_mgr.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"

/**
 * Constant MAX_NUMBER_OF_PAGES: Defines the maximum number of pages that can be managed.
 * The value is set to 100, which can be used to limit the number of pages in the buffer pool or record manager.
 */
const int MAX_NUMBER_OF_PAGES = 100;

/**
 * Constant ATTRIBUTE_SIZE: Defines the maximum size of an attribute in a record.
 * This is set to 15, which is useful for limiting the attribute size when handling records.
 */
const int ATTRIBUTE_SIZE = 15;

/**
 * Global pointer to the RecordManager, which handles the management of records in the system.
 * This will be initialized elsewhere in the program to manage record operations.
 */
RecordManager *recordManager;

/**
 * Function record_checks: Verifies that the provided record pointer is not NULL.
 *
 * @param record A pointer to the Record that needs to be checked.
 *
 * This function checks if the provided record pointer is valid (i.e., not NULL). 
 * If it is NULL, the function returns an error code. If it is not NULL, it returns RC_OK to indicate success.
 *
 * @return RC_OK if the record is valid, RC_RECORD_NULL_ERROR if the record is NULL.
 */
RC record_checks(Record *record)
{
    //Checking if the record pointer is NULL
    if(record == NULL)
    {
        //Returning error code if the record pointer is NULL
        return RC_RECORD_NULL_ERROR;
    }
    else
    {
        //Returning success code if the record pointer is valid
        return RC_OK;
    }
}

/**
 * Function schema_checks: Verifies that the provided schema pointer is not NULL.
 *
 * @param schema A pointer to the Schema that needs to be checked.
 *
 * This function checks if the provided schema pointer is valid (i.e., not NULL).
 * If it is NULL, the function returns an error code. If it is not NULL, it returns RC_OK to indicate success.
 *
 * @return RC_OK if the schema is valid, RC_SCHEMA_NULL_ERROR if the schema is NULL.
 */
RC schema_checks(Schema *schema)
{
    //Checking if the schema pointer is NULL
    if(schema == NULL)
    {
        //Returning error code if the schema pointer is NULL
        return RC_SCHEMA_NULL_ERROR;
    }
    else
    {
        //Returning success code if the schema pointer is valid
        return RC_OK;
    }
}

/**
 * Function value_checks: Verifies that the provided Value pointer is not NULL.
 *
 * @param value A pointer to the Value that needs to be checked.
 *
 * This function checks if the provided value pointer is valid (i.e., not NULL).
 * If it is NULL, the function returns an error code. If it is not NULL, it returns RC_OK to indicate success.
 *
 * @return RC_OK if the value is valid, RC_VALUE_NULL_ERROR if the value is NULL.
 */
RC value_checks(Value *value)
{
    //Checking if the value pointer is NULL
    if(value == NULL)
    {
        //Returning error code if the value pointer is NULL
        return RC_VALUE_NULL_ERROR;
    }
    else
    {
        //Returning success code if the value pointer is valid
        return RC_OK;
    }
}

/**
 * Function scan_checks: Verifies that the provided RM_ScanHandle pointer is not NULL.
 *
 * @param scan A pointer to the RM_ScanHandle that needs to be checked.
 *
 * This function checks if the provided scan pointer is valid (i.e., not NULL).
 * If it is NULL, the function returns an error code. If it is not NULL, it returns RC_OK to indicate success.
 *
 * @return RC_OK if the scan is valid, RC_VALUE_NULL_ERROR if the scan is NULL.
 */
RC scan_checks(RM_ScanHandle *scan)
{
    //Checking if the scan pointer is NULL
    if(scan == NULL)
    {
        //Returning error code if the scan pointer is NULL
        return RC_VALUE_NULL_ERROR;
    }
    else
    {
        //Returning success code if the scan pointer is valid
        return RC_OK;
    }
}

/**
 * Function global_checks: Performs different types of validation checks based on the checkType parameter.
 *
 * @param record A pointer to the Record structure to be checked.
 * @param schema A pointer to the Schema structure to be checked.
 * @param value A pointer to the Value structure to be checked.
 * @param scan A pointer to the RM_ScanHandle structure to be checked.
 * @param checkType An integer determining the type of check to perform:
 *                  0 - Record check
 *                  1 - Schema check
 *                  2 - Value check
 *                  3 - Both Record and Schema check
 *                  4 - Scan check
 *
 * This function performs different checks based on the value of checkType.
 * The function returns an appropriate result code based on the check performed.
 *
 * @return Appropriate result code (e.g., RC_OK for success or error code for failure).
 */
RC global_checks(Record *record, Schema *schema, Value *value, RM_ScanHandle *scan, int checkType)
{
    //If checkType is 0, perform a record check.
    if(checkType == 0)
    {
		//Checking if the record pointer is valid.
        return record_checks(record);  
    }
    
	//If checkType is 1, perform a schema check.
    else if(checkType == 1)
    {
		//Checking if the schema pointer is valid.
        return schema_checks(schema);  
    }
    
	//If checkType is 2, perform a value check.
    else if(checkType == 2)
    {
		//Checking if the value pointer is valid.
        return value_checks(value);  
    }
    
	//If checkType is 3, perform both record and schema checks.
    else if(checkType == 3)
    {
        //First, check if the record is valid.
        if(record_checks(record) == RC_OK)
        {
			//If the record is valid, check the schema.
            return schema_checks(schema);  
        }
        else
        {
			//If the record check fails, return that error.
            return record_checks(record);  
        }
    }

    //If checkType is 4, perform a scan check.
    else if (checkType == 4)
    {
		//Checking if the scan pointer is valid.
        return scan_checks(scan);
    }
    
	//If no valid checkType is provided, return success.
    return RC_OK;
}

/**
 * Function dataTypeAssigner: Assigns or retrieves a value from a given memory location (`dp`) 
 * based on the data type of an attribute from the provided schema.
 * It supports handling multiple data types and performs operations based on the function type (getter/setter).
 *
 * @param schema The schema to which the attribute belongs.
 * @param typeChoser Determines whether the system-defined or custom-defined storage type is used.
 *                   0 for system-defined and 1 for custom-defined.
 * @param attrNum The index of the attribute within the schema to be processed.
 * @param value The value to be assigned (in setter mode).
 * @param dp The memory location where the value is stored or retrieved from.
 * @param funType Determines whether the function acts as a getter or setter. 
 *                0 for setter and non-zero for getter.
 * @param doubleValue A pointer to store the result in the case of a getter.
 *
 * @return RC_OK if the operation is successful; otherwise, an appropriate error code is returned.
 */
RC dataTypeAssigner(Schema *schema, int typeChoser, int attrNum, Value *value, char *dp, int funType, Value **doubleValue)
{
	//Handling String data type
	if((*schema).dataTypes[attrNum] == DT_STRING)
	{
		//If using a system-defined storage type
		if(typeChoser != 0)
		{
			//Placeholder for future work involving custom-defined storage
			return RC_OK;
		}
		else
		{
			//If it's a getter (funType != 0), retrieve the string from memory
			if(funType != 0)
			{
				//Allocate memory for a new Value struct to hold the string value
				Value *attr = (Value *)malloc(sizeof(Value));

				//Setting the data type as string
				(*attr).dt = DT_STRING;  

				//Allocating memory for the string
				(*attr).v.stringV = (char *)malloc((*schema).typeLength[attrNum] + 1);  
				
				//Copying the string from dp (data pointer) into the new Value struct
				strncpy((*attr).v.stringV, dp, (*schema).typeLength[attrNum]);
				
				//Ensuring null termination of the string
				(*attr).v.stringV[(*schema).typeLength[attrNum]] = '\0';

				//Returning the string wrapped in a Value struct
				*doubleValue = attr;  
				return RC_OK;
			}
			else
			{
				//Setter: Copy the string value from the Value struct to dp
				strncpy(dp, (*value).v.stringV, (*schema).typeLength[attrNum]);

				//Moving dp pointer after the copied string
				dp += (*schema).typeLength[attrNum];  
				return RC_OK;
			}
		}
	}
	//Handling Integer data type
	else if((*schema).dataTypes[attrNum] == DT_INT)
	{
		//If using a system-defined storage type
		if(typeChoser == 0)
		{
			//If it's a getter (funType != 0), retrieve the integer from memory
			if(funType != 0)
			{
				//Allocating memory for a new Value struct to hold the integer value
				int val = 0;
				Value *attr = (Value *)malloc(sizeof(Value));

				//Copying the integer from dp into the val variable
				memcpy(&val, dp, sizeof(int));

				//Assigning the integer value to the Value struct
				(*attr).v.intV = val;

				//Setting the data type as integer
				(*attr).dt = DT_INT;  

				//Returning the integer wrapped in a Value struct
				*doubleValue = attr;  
				return RC_OK;
			}
			else
			{
				//Setter: Copy the integer value from the Value struct to dp
				*(int *)dp = (*value).v.intV;

				//Moving dp pointer after the copied integer
				dp += sizeof(int);  
				return RC_OK;
			}
		}
		else
		{
			//Placeholder for custom-defined storage type (future work)
			return RC_OK;
		}
	}
	//Handling Float data type
	else if((*schema).dataTypes[attrNum] == DT_FLOAT)
	{
		//If using a system-defined storage type
		if(typeChoser == 0)
		{
			//If it's a getter (funType != 0), retrieve the float from memory
			if(funType != 0)
			{
				//Allocating memory for a new Value struct to hold the float value
				float val;
				Value *attr = (Value *)malloc(sizeof(Value));

				//Setting the data type as float
				(*attr).dt = DT_FLOAT;  
				
				//Copying the float from dp into the val variable
				memcpy(&val, dp, sizeof(float));
				
				//Assigning the float value to the Value struct
				(*attr).v.floatV = val;

				//Returning the float wrapped in a Value struct
				*doubleValue = attr;  
				return RC_OK;
			}
			else
			{ 
				//Setter : Copy the float value from the Value struct to dp
				*(float *)dp = (*value).v.floatV;

				//Moving dp pointer after the copied float
				dp += sizeof(float);  
				return RC_OK;
			}
		}
		else
		{
			//Placeholder for custom-defined storage type (future work)
			return RC_OK;
		}
	}
	//Handling Boolean data type
	else if((*schema).dataTypes[attrNum] == DT_BOOL)
	{
		//If using a system-defined storage type
		if(typeChoser == 0)
		{
			//If it's a getter (funType != 0), retrieve the boolean from memory
			if(funType != 0)
			{
				//Allocating memory for a new Value struct to hold the boolean value
				Value *attr = (Value *)malloc(sizeof(Value));
				bool val;
				
				//Copying the boolean from dp into the val variable
				memcpy(&val, dp, sizeof(bool));
				
				//Assigning the boolean value to the Value struct
				(*attr).v.boolV = val;

				//Setting the data type as boolean
				(*attr).dt = DT_BOOL;  

				//Returning the boolean wrapped in a Value struct
				*doubleValue = attr;  
				return RC_OK;
			}
			else
			{
				//Setter : Copy the boolean value from the Value struct to dp
				*(bool *)dp = (*value).v.boolV;

				//Moving dp pointer after the copied boolean
				dp += sizeof(bool);  
				return RC_OK;
			}
		}
		else
		{
			//Placeholder for custom-defined storage type (future work)
			return RC_OK;
		}
	}
	else
	{
		//Invalid data type in schema: return an error
		return RC_SCHEMA_DATA_TYPE_ERROR;
	}
}

/**
 * Function getFreeSlot : Finds the index of the first available (free) slot in the data page.
 * A slot is considered free if its starting character is not '+'.
 *
 * @param data Pointer to the page data.
 * @param recordSize The size of each record in bytes.
 * @return Index of the first free slot, or -1 if all slots are occupied.
 */
int getFreeSlot(char *data, int recordSize)
{
	//Current slot index being checked
	int slotIndex = 0;                           
	
	//Total number of slots in the page
	int totalSlots = PAGE_SIZE / recordSize;     

	//Index of the free slot (default -1 for not found)
	int freeSlotIndex = -1;                      

	//Looping through all slots in the page
	while(slotIndex < totalSlots)
	{
		//Checking if the slot is free (not marked with '+')
		if ('+' != data[recordSize * slotIndex])
		{
			//Found a free slot
			freeSlotIndex = slotIndex;          
			break;
		}
		//Moving to the next slot
		slotIndex++;                             
	}
	//Returning the index of the free slot (or -1)
	return freeSlotIndex;                         
}

/**
 * Function initRecordManager : Initializes the Record Manager by initializing the Storage Manager.
 *
 * @param mgmtData Pointer to the management data (currently unused).
 * @return RC_OK if initialization is successful.
 */
extern RC initRecordManager(void *mgmtData)
{
	//Initializing the underlying Storage Manager
	initStorageManager(); 
	return RC_OK;
}

/**
 * Function shutdownRecordManager : Shuts down the Record Manager and releases allocated memory.
 *
 * @return RC_OK if shutdown is successful.
 */
extern RC shutdownRecordManager()
{
	//Freeing memory used by the record manager, if allocated
	if (recordManager != NULL)
	{
		free(recordManager);
		recordManager = NULL;
	}

	return RC_OK;
}

/**
 * Function setPageHandle: Writes schema metadata into a memory page buffer.
 *
 * @param pageHandle Pointer to the memory buffer where schema metadata will be stored.
 * @param schema Pointer to the Schema structure containing attribute names, data types,
 *               and type lengths.
 *
 * This function serializes the schema information into a flat memory format suitable for
 * storing in a page buffer. It writes each attribute's name (fixed size), data type,
 * and type length sequentially into the buffer. Before performing the operation, the function
 * validates the schema pointer using global_checks.
 *
 * The resulting buffer layout can later be deserialized to reconstruct the schema structure.
 * This is typically used when storing or managing metadata in a record-based storage system.
 *
 */
extern void setPageHandle(char *pageHandle, Schema *schema)
{
    //RC is a return code type defined in dberror.h
    RC return_code;

    //Validating schema using global_checks with checkType 1
    return_code = global_checks(NULL, schema, NULL, NULL, 1);
    if (return_code != RC_OK)
    {
        //If schema validation fails, silently exit (consider logging or returning error in future)
        return;
    }
    else
    {
        //Schema is valid, proceed with writing metadata into the page handle
        int i = 0;

        //Looping over all attributes in the schema
        while(i < (*schema).numAttr)
        {
            //Writing attribute name (fixed size) into the page handle
            strncpy(pageHandle, (*schema).attrNames[i], ATTRIBUTE_SIZE);
            pageHandle += ATTRIBUTE_SIZE;

            //Writing data type of the attribute
            *(int *)pageHandle = (int)(*schema).dataTypes[i];
            pageHandle += sizeof(int);

            //Writing type length of the attribute (used for strings)
            *(int *)pageHandle = (int)(*schema).typeLength[i];
            pageHandle += sizeof(int);

			//Moving to the next attribute
            i++; 
        }
    }
}

/**
 * Function increment_Page_Handle : Advances a page handle pointer by a specified number of bytes.
 *
 * @param pageHandle Double pointer to the current position in the page buffer (char **).
 *                   This allows modification of the original pointer's value.
 * @param number Integer value specifying how much to increment the pointer.
 *               If the value is 1, the pointer is incremented by the size of an integer (i.e., sizeof(int)).
 *               Otherwise, it is incremented by the given number of bytes.
 *
 * This utility function is used to manipulate a page buffer cursor while reading or writing 
 * serialized data such as integers, floats, strings, etc., especially in the context of 
 * database page structures.
 *
 * The function enables compact and consistent traversal of memory layouts where types of 
 * varying size are stored sequentially (e.g., schema attributes, records).
 */
extern void increment_Page_Handle(char **pageHandle, int number)
{
	if(number == 1)
	{
		//Moving the pointer forward by the size of an integer
		*pageHandle = *pageHandle + sizeof(int);
	}
	else
	{
		//Moving the pointer forward by the specified number of bytes
		*pageHandle = *pageHandle + number;
	}
}

/**
 * Function createTable : Initializes and creates a new table with the given name and schema.
 *
 * @param name The name of the table to be created.
 * @param schema Pointer to the schema describing the table structure (attributes, types, etc.).
 *
 * This function performs validation on inputs, initializes the record manager and buffer pool,
 * and serializes schema metadata into the first page of the table file. It creates the physical file,
 * writes the metadata, and ensures everything is properly initialized and stored.
 *
 * @return RC_OK if table creation is successful, otherwise an appropriate error code.
 */
extern RC createTable(char *name, Schema *schema)
{
    RC resultCode;

    //Checking if the schema is valid
    resultCode = global_checks(NULL, schema, NULL, NULL, 1);
    if(resultCode != RC_OK)
	{
        return resultCode;
	}

    //Checking if table name is provided
    if(name == NULL)
    {
        RC_message = "The Table name cannot be null";
        return RC_NULL_IP_PARAM;
    }

    //Allocating and initialize the record manager
    recordManager = (RecordManager *)malloc(sizeof(RecordManager));
    initBufferPool(&recordManager->buffPool, name, MAX_NUMBER_OF_PAGES, RS_LRU, NULL);

    //Preparing to write metadata to the first page
    SM_FileHandle file_Handle;

	//First page block
    char pageBuffer[PAGE_SIZE];        

	//Pointer to write data into page
    char *pagePointer = pageBuffer;    

    //Writing metadata: starting with record count = 0
    *(int *)pagePointer = 0;
    increment_Page_Handle(&pagePointer, 1);

    //Page ID or dummy flag
    *(int *)pagePointer = 1;
    increment_Page_Handle(&pagePointer, 1);

    //Writing number of attributes
    *(int *)pagePointer = schema->numAttr;
    increment_Page_Handle(&pagePointer, 1);

    //Writing size of the key
    *(int *)pagePointer = schema->keySize;
    increment_Page_Handle(&pagePointer, 1);

    //Serializing the schema into the remaining part of the first page
    setPageHandle(pagePointer, schema);

    //Creating the table file
    resultCode = createPageFile(name);
    if(resultCode != RC_OK)
	{
        return resultCode;
	}

    //Opening the file for writing metadata
    resultCode = openPageFile(name, &file_Handle);
    if(resultCode != RC_OK)
	{
        return resultCode;
	}

    //Writing the prepared metadata block into the first page
    resultCode = writeBlock(0, &file_Handle, pageBuffer);
    if(resultCode != RC_OK)
	{
        return resultCode;
	}

    //Closing the file after writing
    resultCode = closePageFile(&file_Handle);
    if(resultCode != RC_OK)
	{
        return resultCode;
	}

    return RC_OK;
}

/**
 * Function Set_Schema : Initializes and sets up the schema with the given attribute count.
 *
 * @param schema Pointer to the schema to be initialized.
 * @param attributeCount The number of attributes in the schema.
 *
 * This function performs validation on the input, allocates memory for the schema's attribute names,
 * data types, and type lengths based on the given attribute count. It ensures the schema structure
 * is properly set up for the table.
 *
 * @return RC_OK if schema setup is successful, otherwise an appropriate error code.
 */
extern void Set_Schema(Schema *schema, int attributeCount)
{
    RC resultCode;

    //Performing validation checks
    resultCode = global_checks(NULL, schema, NULL, NULL, 1);
    if (resultCode != RC_OK)
    {
		//Exit if validation fails
        return; 
    }

    //Initializing schema attributes
    schema->numAttr = attributeCount;
    schema->attrNames = (char **)malloc(sizeof(char *) * attributeCount);
    schema->typeLength = (int *)malloc(sizeof(int) * attributeCount);
    schema->dataTypes = (DataType *)malloc(sizeof(DataType) * attributeCount);

    //Allocating memory for each attribute name
    int index = 0;
    while (index < attributeCount)
    {
        schema->attrNames[index] = (char *)malloc(ATTRIBUTE_SIZE);
        index++;
    }
}

/**
 * Function Set_Schema_AttributeNames : Sets the attribute names, data types, and type lengths in the schema.
 *
 * @param schema Pointer to the schema that will be populated.
 * @param pageHandle Pointer to the page handle that contains attribute data.
 * @param attributeSize The size of each attribute name.
 *
 * This function reads the attribute names, data types, and type lengths from the given page handle and
 * updates the schema with this information. It ensures the schema is populated correctly with all attribute details.
 *
 * @return RC_OK if successful, otherwise an appropriate error code.
 */
extern void Set_Schema_AttributeNames(Schema *schema, char *pageHandle, int attributeSize)
{
    RC resultCode;

    //Performing validation checks
    resultCode = global_checks(NULL, schema, NULL, NULL, 1);
    if(resultCode != RC_OK)
    {
		//Exit if validation fails
        return; 
    }

    //Everything is okay, populate the schema attributes
    int index = 0;
    while(index < schema->numAttr)
    {
        //Setting the attribute name
        strncpy(schema->attrNames[index], pageHandle, attributeSize);
        increment_Page_Handle(&pageHandle, attributeSize);

        //Setting the data type for the attribute
        schema->dataTypes[index] = *(int *)pageHandle;
        increment_Page_Handle(&pageHandle, 1);

        //Setting the type length for the attribute
        schema->typeLength[index] = *(int *)pageHandle;
        increment_Page_Handle(&pageHandle, 1);

        index++;
    }
}

/**
 * Function openTable: Opens a table and loads its schema and metadata from disk.
 *
 * @param rel Pointer to the RM_TableData structure that will store table information.
 * @param name The name of the table to be opened.
 *
 * This function loads the schema and metadata of a table by reading the first page of the table file.
 * It validates the input parameters, pins the page, reads the required information, and initializes
 * the schema. If successful, it unpins and forces the page back to disk.
 *
 * @return RC_OK if successful, otherwise an appropriate error code.
 */
extern RC openTable(RM_TableData *rel, char *name)
{
    //Checking if the relation pointer is NULL
    if(rel == NULL)
    {
		//Returning an error if the relation is NULL
        return RC_RELATION_NULL_ERROR;  
    }
    else
    {
        //Checking if the table name is NULL
        if(name == ((char *)0))
        {
            RC_message = "The Table name can not be null ";
			
			//Returning an error if the table name is NULL
            return RC_NULL_IP_PARAM;  
        }
        else
        {
			//Variable to store the number of attributes in the schema
            int attrCount;               

			//Variable to store the page handle for the table
            SM_PageHandle pageHandle;    

			//Pointer to hold the schema of the table
            Schema *tableSchema;         

			//Assigning the global record manager to the relation
            rel->mgmtData = recordManager;  

			//Setting the table name
            rel->name = name;              

            //Pinning the first page of the table to read its metadata
            if(pinPage(&recordManager->buffPool, &recordManager->pageHndl, 0) != RC_OK)
            {
				//Print error if pinning the page fails
                printError(RC_PIN_PAGE_FAILED);  

				//Return error code if pinning fails
                return RC_PIN_PAGE_FAILED;      
            }

            //Retrieving the page handle and cast it to char* for reading
            pageHandle = (char *)recordManager->pageHndl.data;

            //Read the total number of tuples in the table from the page
            recordManager->totalTupleCnt = *(int *)pageHandle;

			//Moving the page pointer to the next section
            increment_Page_Handle(&pageHandle, 1);  

            //Read the first free page number from the page
            recordManager->firstFreePage = *(int *)pageHandle;

			//Moving the page pointer again
            increment_Page_Handle(&pageHandle, 1);  

            //Reading the attribute count (number of attributes in the schema) from the page
            attrCount = *(int *)pageHandle;

			//Moving the page pointer to the next section
            increment_Page_Handle(&pageHandle, 1);  

            //Initializing the schema structure for the table
            tableSchema = (Schema *)malloc(sizeof(Schema));

			//Setting up the schema with attribute count
            Set_Schema(tableSchema, attrCount);  

			//Setting the attribute names
            Set_Schema_AttributeNames(tableSchema, pageHandle, ATTRIBUTE_SIZE);  

            //Assigning the schema to the relation's schema field
            rel->schema = tableSchema;

            //Unpin the page after reading the required data
            if(unpinPage(&recordManager->buffPool, &recordManager->pageHndl) != RC_OK)
            {
				//Return error if unpinning the page fails
                return RC_UNPIN_PAGE_FAILED;  
            }

            //Force the page back to disk to ensure that all changes are saved
            if(forcePage(&recordManager->buffPool, &recordManager->pageHndl))
            {
				//Return error if forcing the page fails
                return RC_FORCE_PAGE_FAILED;  
            }

			//Return success if everything is successful
            return RC_OK;  
        }
    }
	//Return success if no issues encountered
    return RC_OK;  
}

/**
 * Function closeTable : Closes a table by shutting down the associated buffer pool and freeing resources.
 *
 * @param rel Pointer to the RM_TableData structure representing the table to be closed.
 *
 * This function shuts down the buffer pool associated with the table by calling `shutdownBufferPool`.
 * It also ensures that the resources are cleaned up properly before returning control back to the caller.
 * If any error occurs during the shutdown process, an appropriate error code is returned.
 *
 * @return RC_OK if successful, otherwise an appropriate error code.
 */
extern RC closeTable(RM_TableData *rel)
{
    //Checking if the rel pointer is NULL
    if(rel == NULL)
    {
		//Returning an error if the rel is NULL
        return RC_RELATION_NULL_ERROR;  
    }
    else
    {
        //Retrieving the record manager associated with the table
        RecordManager *recordMgr = (*rel).mgmtData;

        //Shut down the buffer pool and return the result
        if(shutdownBufferPool(&recordMgr->buffPool) == RC_OK)
        {
			//Returning result of shutting down the buffer pool
            return shutdownBufferPool(&recordMgr->buffPool);  
        }

		//Returning success if no errors during shutdown
        return RC_OK;  
    }
}

/**
 * Function deleteTable : Deletes a table by removing its associated file from storage.
 *
 * @param name The name of the table to be deleted.
 *
 * This function checks if the provided table name is NULL. If it is, an error is returned. 
 * If the table name is valid, the function proceeds to destroy the page file associated with the table.
 * It uses the `destroyPageFile` function to remove the physical file. If the destruction is successful, 
 * it returns RC_OK, otherwise, an error code is returned.
 *
 * @return RC_OK if the table was successfully deleted, otherwise an appropriate error code.
 */
extern RC deleteTable(char *name)
{
    //Checking if the table name is NULL
    if(name == ((char *)0))
    {
		//Setting error message
        RC_message = "The Table name can not be null ";  

		//Return error code for null table name
        return RC_NULL_IP_PARAM;  
    }

    //Trying to destroy the page file associated with the table
    if(destroyPageFile(name) != RC_OK)
    {
		//Return error if the file destruction fails
        return RC_FILE_DESTROY_FAILED;  
    }
    else
    {
		//Return success if the file is successfully destroyed
        return RC_OK;  
    }

	//This line is redundant since the function would already return in previous blocks
    return RC_OK;  
}

/**
 * Function getNumTuples : Retrieves the total number of tuples (records) in a table.
 *
 * @param rel The table whose tuple count is to be retrieved.
 *
 * This function checks if the provided table is NULL. If it is, it returns an error code.
 * Otherwise, it accesses the `RecordManager` associated with the table and retrieves
 * the `totalTupleCnt` field, which holds the total number of tuples (records) in the table.
 *
 * @return The total number of tuples if the table is valid, or an appropriate error code if not.
 */
extern int getNumTuples(RM_TableData *rel)
{
    //Checking if the table reference is NULL
    if(rel == NULL)
    {
		//Returning error if the table reference is NULL
        return RC_RELATION_NULL_ERROR;  
    }
    else
    {
        //Accessing the RecordManager associated with the table
        RecordManager *recordMgr = (*rel).mgmtData;
        
        //Returning the total number of tuples from the RecordManager
        return (*recordMgr).totalTupleCnt;
    }
}

/**
 * Function insertRecord : Inserts a new record into the specified table.
 *
 * @param rel The table where the record will be inserted.
 * @param record The record to be inserted into the table.
 *
 * This function performs the following steps:
 * - It checks the validity of the record using `global_checks`.
 * - It retrieves the first available free page from the table.
 * - It looks for an available slot on the page to insert the record.
 * - If there is no space on the current page, it moves to the next page.
 * - It updates the table with the inserted record and increases the total tuple count.
 *
 * @return RC_OK if the insertion is successful, or an appropriate error code if not.
 */
extern RC insertRecord(RM_TableData *rel, Record *record)
{
    //Variable to store the return code from functions
    RC rc;

    //Performing global checks on the record
    rc = global_checks(record, NULL, NULL, NULL, 0);
    
    //If the global checks failed, return the error code
    if(rc != RC_OK)
    {
		//Return the error code from global checks
        return rc;  
    }
    else
    {
        //Everything is OK, proceed with the insertion
        //Declaring necessary variables
        RecordManager *recordManager;
        RID *recordID;
        int recordSize;
        char *data, *slotPtr;

        //Accessing the record manager from the table's management data
        recordManager = (*rel).mgmtData;
        recordID = &record->id;

        //Assigning the first free page for the record
        (*recordID).page = (*recordManager).firstFreePage;

        //Pinning the page to load it into memory
        pinPage(&recordManager->buffPool, &recordManager->pageHndl, (*recordID).page);

        //Getting the size of the record based on the schema
        recordSize = getRecordSize((*rel).schema);
        data = (*recordManager).pageHndl.data;

        //Finding the first available slot for the record
        (*recordID).slot = getFreeSlot(data, recordSize);

        //If no free slot is found on the current page, check subsequent pages
        while((*recordID).slot == -1)
        {
            //Unpining the current page and move to the next page
            unpinPage(&recordManager->buffPool, &recordManager->pageHndl);
            (*recordID).page++;
            pinPage(&recordManager->buffPool, &recordManager->pageHndl, (*recordID).page);
            data = (*recordManager).pageHndl.data;

            //Finding the next available slot on the new page
            (*recordID).slot = getFreeSlot(data, recordSize);
        }

        //Pointer to where the record data will be inserted on the page
        slotPtr = data;

        //Marking the page as dirty (modified) after making changes
        markDirty(&recordManager->buffPool, &recordManager->pageHndl);

        //Calculating the position to insert the record
        slotPtr += (recordSize * (*recordID).slot);

        //Marking the slot as occupied with a '+'
        *slotPtr = '+';

        //Copying the record data (excluding the first byte, which holds metadata)
        memcpy(1 + slotPtr, (*record).data + 1, recordSize - 1);

        //Unpinning the page after inserting the record
        unpinPage(&recordManager->buffPool, &recordManager->pageHndl);

        //Updating the total tuple count in the table
        (*recordManager).totalTupleCnt += 1;

        //Re-pin the first page (often used for metadata updates)
        pinPage(&recordManager->buffPool, &recordManager->pageHndl, 0);
    }

	//Return OK if everything went successfully
    return RC_OK;  
}

/**
 * Function deleteRecord : Deletes a record from the specified table based on the given record ID.
 *
 * @param rel The table from which the record will be deleted.
 * @param id The ID of the record to be deleted, containing the page and slot information.
 *
 * This function performs the following steps:
 * - It checks if the provided table (`rel`) is not NULL.
 * - It locks the page where the record is stored, marks the record as deleted, and then unpins the page.
 * - It updates the first free page in the record manager.
 *
 * @return RC_OK if the deletion is successful, or an appropriate error code if not.
 */
extern RC deleteRecord(RM_TableData *rel, RID id)
{
    //Checking if the provided table pointer is not null
    if (rel == NULL)
    {
		//Return an error if the table pointer is NULL
        return RC_RELATION_NULL_ERROR;  
    }
    else
    {
        //Declaring variables to hold the record manager, record size, and data pointer
        RecordManager *recordManager;
        int recordSize;
        char *data;

        //Accessing the record manager associated with the table
        recordManager = (*rel).mgmtData;

        //Pinning the page containing the record to be deleted
        pinPage(&recordManager->buffPool, &recordManager->pageHndl, id.page);

        //Updating the first free page pointer in the record manager to the page of the deleted record
        (*recordManager).firstFreePage = id.page;

        //Getting the record size based on the schema of the table
        recordSize = getRecordSize((*rel).schema);

        //Accessing the page data where the record resides
        data = (*recordManager).pageHndl.data;

        //Calculating the position of the record within the page and mark it as deleted ('-')
        data += (recordSize * id.slot);
        *data = '-';

        //Marking the page as dirty since it was modified
        markDirty(&recordManager->buffPool, &recordManager->pageHndl);

        //Unpinning the page after making the modifications
        unpinPage(&recordManager->buffPool, &recordManager->pageHndl);
    }

    //Return success after successfully deleting the record
    return RC_OK;
}

/**
 * Function updateRecord : Updates an existing record in the specified table.
 *
 * @param rel The table in which the record will be updated.
 * @param record The record with the updated data.
 *
 * This function performs the following steps:
 * - It performs global checks to ensure the validity of the record.
 * - It pins the page where the record resides, marks the record as modified ('+'), and updates the record data.
 * - The page is then marked as dirty, and the page is unpinned.
 *
 * @return RC_OK if the update is successful, or an appropriate error code if not.
 */
extern RC updateRecord(RM_TableData *rel, Record *record)
{
    //Checking the validity of the provided record using global checks
    RC rc;
    rc = global_checks(record, NULL, NULL, NULL, 0);

    //If global checks failed, return the corresponding error code
    if (rc != RC_OK)
    {
        return rc;
    }
    else
    {
        //Everything is OK, proceed with updating the record
        RecordManager *recordManager;
        int recordSize;
        char *data;

        //Accessing the record manager associated with the table
        recordManager = (*rel).mgmtData;

        //Pinning the page containing the record to be updated
        pinPage(&recordManager->buffPool, &recordManager->pageHndl, (*record).id.page);

        //Getting the record size based on the schema of the table
        recordSize = getRecordSize((*rel).schema);

        //Access the page data where the record resides
        data = (*recordManager).pageHndl.data;

        //Calculating the position of the record within the page and mark it as updated ('+')
        data += (recordSize * (*record).id.slot);
        *data = '+';

        //Copying the updated data into the record's position in the page
        memcpy(1 + data, (*record).data + 1, recordSize - 1);

        //Marking the page as dirty since it was modified
        markDirty(&recordManager->buffPool, &recordManager->pageHndl);

        //Unpinning the page after making the modifications
        unpinPage(&recordManager->buffPool, &recordManager->pageHndl);

        //Return success after successfully updating the record
        rc = RC_OK;
    }

    return rc;
}

/**
 * Function getRecord : Retrieves a record from the specified table using the given record ID (RID).
 *
 * @param rel The table from which the record will be retrieved.
 * @param id The RID (Record ID) identifying the specific record.
 * @param record The record object where the retrieved data will be stored.
 *
 * This function performs the following steps:
 * - It performs global checks to ensure the validity of the record.
 * - It pins the page containing the record and checks if the record is marked as valid ('+').
 * - If the record is found, it copies the data into the provided record structure.
 * - The page is then unpinned after reading the record.
 *
 * @return RC_OK if the record is successfully retrieved, or an appropriate error code if not.
 */
extern RC getRecord(RM_TableData *rel, RID id, Record *record)
{
    //Performing global checks on the record and other parameters
    RC rc;
    rc = global_checks(record, NULL, NULL, NULL, 0);

    //If global checks failed, return the corresponding error code
    if(rc != RC_OK)
    {
        return rc;
    }
    else
    {
        //Everything is OK, proceed with retrieving the record
        RecordManager *recordManager;
        int recordSize;
        char *dataPointer;

        //Accessing the record manager associated with the table
        recordManager = (*rel).mgmtData;

        //Pinning the page containing the record to be retrieved
        pinPage(&recordManager->buffPool, &recordManager->pageHndl, id.page);

        //Getting the record size based on the schema of the table
        recordSize = getRecordSize((*rel).schema);

        //Accessing the page data where the record resides
        dataPointer = (*recordManager).pageHndl.data;

        //Calculating the position of the record within the page
        dataPointer += (recordSize * id.slot);

        //Checking if the record is marked as valid ('+')
        if('+' != *dataPointer)
        {
			//Record not found
            rc = RC_RM_NO_TUPLE_WITH_GIVEN_RID;  
        }
        else
        {
            //Copying the record data into the provided record structure
            char *recordData = (*record).data;
            (*record).id = id;
            memcpy(++recordData, dataPointer + 1, recordSize - 1);

			//Successfully retrieved the record
            rc = RC_OK;  
        }

        //Unpinning the page after reading the record
        unpinPage(&recordManager->buffPool, &recordManager->pageHndl);
    }

    return rc;
}

/**
 * Function startScan : Initiates a scan on a specified table based on the provided condition.
 *
 * @param rel The table to perform the scan on.
 * @param scan The scan handle that will store the scan data.
 * @param cond The condition for the scan (optional).
 *
 * This function performs the following steps:
 * - It performs global checks to ensure the validity of the scan parameters.
 * - If a condition is supplied, it initializes the scan by opening the table, setting up the scan manager, and associating the condition.
 * - If no condition is provided, it returns an error indicating that the condition was not found.
 *
 * @return RC_OK if the scan is successfully started, or an appropriate error code if not.
 */
extern RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond)
{
    //Performing global checks to ensure validity of the scan parameters
    RC rc;
    rc = global_checks(NULL, NULL, NULL, scan, 4);

    //If global checks failed, return the corresponding error code
    if(rc != RC_OK)
    {
        return rc;
    }
    else
    {
        //Condition is provided for the scan
        if(cond != NULL)
        {
            RecordManager *scanManager, *tableManager;

            //Opening the table to start scanning
            openTable(rel, "ScanTable");

            //Initializing the scan manager and associate it with the table's record manager
            scanManager = (RecordManager *)malloc(sizeof(RecordManager));
            tableManager = (*rel).mgmtData;

            //Setting the total tuple count (used as placeholder here)
            (*tableManager).totalTupleCnt = ATTRIBUTE_SIZE;

            //Initializing scan handle with relevant data
            (*scan).mgmtData = scanManager;
            (*scanManager).rID.page = 1;
            (*scanManager).rID.slot = 0;
            (*scanManager).totalScannedCount = 0;
            (*scanManager).condition = cond;
            (*scan).rel = rel;

            //Successfully started the scan
            rc = RC_OK;
        }
        else
        {
            //No condition was provided, return error indicating no condition for the scan
            rc = RC_SCAN_CONDITION_NOT_FOUND;
        }
    }

    return rc;
}

/**
 * Function next : Fetches the next record from the scan based on the specified condition.
 *
 * @param scan The scan handle that contains scan information.
 * @param record The record where the fetched data will be stored.
 *
 * This function performs the following steps:
 * - It performs global checks to ensure the validity of the scan and record parameters.
 * - If a condition is provided, it iterates over the records, evaluating the condition.
 * - If the condition is met, it returns the record, otherwise it continues searching for the next valid record.
 * - If no more records satisfy the condition or if the scan is finished, an appropriate error code is returned.
 *
 * @return RC_OK if a valid record is found and returned, or an error code if the scan finishes or the condition is not met.
 */
extern RC next(RM_ScanHandle *scan, Record *record)
{
    //Performing global checks to ensure record is valid
    RC rc;
    rc = global_checks(record, NULL, NULL, NULL, 0);
    
    //If global checks failed, return the corresponding error code
    if(rc != RC_OK)
    {
        return rc;
    }
    else
    {
        //Ensuring scan handle is valid
        if(scan == NULL)
        {
            return RC_SCAN_NOT_FOUND;
        }
        else
        {
            //Everything is OK, proceed with scanning
            RecordManager *scanManager;
            scanManager = (*scan).mgmtData;

            //Checking if a condition is provided for the scan
            if((*scanManager).condition != NULL)
            {
                RecordManager *tableManager;
                tableManager = (*scan).rel->mgmtData;

                //Getting schema and initialize necessary variables for scanning
                Schema *schema = (*scan).rel->schema;
                Value *result = (Value *)malloc(sizeof(Value));
                char *dataPtr, *recordPtr;
                int recordSize, totalSlots, scanCount, tupleCount;

                //Getting the record size and initialize counters
                recordSize = getRecordSize(schema);
                scanCount = (*scanManager).totalScannedCount;
                tupleCount = (*tableManager).totalTupleCnt;
                totalSlots = PAGE_SIZE / recordSize;

                //If there are tuples to scan, proceed
                if(tupleCount != 0)
                {
                    //Continue scanning while there are tuples left
                    while(scanCount < tupleCount - 1)
                    {
                        //Moving to the next record slot or page if needed
                        if(scanCount > 0)
                        {
                            (*scanManager).rID.slot++;
                            if(totalSlots <= (*scanManager).rID.slot)
                            {
                                (*scanManager).rID.page++;
                                (*scanManager).rID.slot = 0;
                            }
                        }
                        else
                        {
                            (*scanManager).rID.page = 1;
                            (*scanManager).rID.slot = 0;
                        }

                        //Pinning the page containing the record and fetch data
                        pinPage(&tableManager->buffPool, &scanManager->pageHndl, (*scanManager).rID.page);

                        //Storing the current record's page and slot in the record structure
                        (*record).id.page = (*scanManager).rID.page;
                        (*record).id.slot = (*scanManager).rID.slot;

                        //Getting the data pointer and extract the record data
                        dataPtr = (*scanManager).pageHndl.data;
                        dataPtr += ((*scanManager).rID.slot * recordSize);
                        recordPtr = (*record).data;
						//Marking as deleted
                        *recordPtr = '-';  

                        //Copying the data of the record
                        memcpy(++recordPtr, 1 + dataPtr, recordSize - 1);

                        //Increment scan count
                        (*scanManager).totalScannedCount++;
                        scanCount++;

                        //Evaluating the condition for the current record
                        evalExpr(record, schema, (*scanManager).condition, &result);

                        //If the condition is not met, skip this record and continue scanning
                        if((*result).v.boolV == FALSE)
                        {
                            rc = RC_CONDITION_NOT_MET;
                        }
                        else
                        {
                            //Condition met, return the current record
                            unpinPage(&tableManager->buffPool, &scanManager->pageHndl);
                            rc = RC_OK;
                            return RC_OK;
                        }
                    }

                    //No more records satisfying the condition, reset scanning counters and return no more tuples error
                    unpinPage(&tableManager->buffPool, &scanManager->pageHndl);
                    (*scanManager).totalScannedCount = 0;
                    (*scanManager).rID.page = 1;
                    (*scanManager).rID.slot = 0;
                    rc = RC_RM_NO_MORE_TUPLES;
                }
                else
                {
                    rc = RC_RM_NO_MORE_TUPLES;
                }
            }
            else
            {
                //No scan condition found, return error
                rc = RC_SCAN_CONDITION_NOT_FOUND;
            }
        }
    }

    return rc;
}

/**
 * Function closeScan : Closes the scan and releases any resources associated with it.
 *
 * @param scan The scan handle to be closed.
 * 
 * This function performs the following actions:
 * - Checks if the scan handle is valid.
 * - Verifies if the scan has been properly initialized.
 * - Releases the page handle and resets scan state.
 * - Frees the memory allocated for the scan management data and nullifies it.
 *
 * @return RC_OK if the scan is successfully closed, or an error code if there are issues with the scan.
 */
extern RC closeScan(RM_ScanHandle *scan)
{
    //Checking if the scan handle exists
    if(scan == NULL)
    {
        //No scan exists, return error
        return RC_SCAN_NOT_FOUND;
    }
    else
    {
        //Scan exists, proceed with closing it
        RecordManager *scanManager;
        scanManager = (*scan).mgmtData;
        RecordManager *tableManager;
        tableManager = (*scan).rel->mgmtData;

        //Checking if there was an error in scanning
        if((*scanManager).totalScannedCount < 0)
        {
            return RC_SCAN_COM_ERROR;
        }
        else
        {
            //Unpinning the page that was used during the scan
            unpinPage(&tableManager->buffPool, &scanManager->pageHndl);

            //Resetting scan counters and identifiers
            (*scanManager).totalScannedCount = 0;
            (*scanManager).rID.page = 1;
            (*scanManager).rID.slot = 0;
        }

        //Free the scan manager data and nullify the pointer
        free((*scan).mgmtData);
        (*scan).mgmtData = NULL;

        return RC_OK;
    }
}

/**
 * Function getRecordSize : Calculates the size of a record based on the schema.
 *
 * @param schema The schema of the record to calculate the size for.
 * 
 * This function calculates the total size required to store a record, based on the 
 * data types of its attributes, as defined in the schema.
 * The size is calculated by summing the sizes of individual attributes.
 * 
 * Supported data types:
 * - DT_BOOL: Boolean, size is the size of a `bool`
 * - DT_FLOAT: Floating point, size is the size of a `float`
 * - DT_INT: Integer, size is the size of an `int`
 * - Other types: The size is determined by the typeLength specified in the schema.
 *
 * @return The total size of the record in bytes, or an error code if the schema is invalid.
 */
extern int getRecordSize(Schema *schema)
{
    //RC is already defined in dberror.h file using it to store RC_CODES
    RC rc;

    //Performing global checks to validate the schema
    rc = global_checks(NULL, schema, NULL, NULL, 1);
    if (rc != RC_OK)
	{
		//If checks fail, return the error code
        return rc;  
	}

    else
    {
		//Variable to accumulate the total size of the record
        int size = 0;  

		//Loop counter
        int i = 0;     

        //Iterating through each attribute in the schema to calculate the total size
        while (i < (*schema).numAttr)
        {
            //Checking the data type of each attribute and add the corresponding size
            if ((*schema).dataTypes[i] == DT_BOOL)
			{
				//Size of bool
                size += sizeof(bool);  
			}
			else if ((*schema).dataTypes[i] == DT_FLOAT)
			{
				//Size of float
                size += sizeof(float);  
			}
			else if ((*schema).dataTypes[i] == DT_INT)
			{
				//Size of int
                size += sizeof(int);    
			}
			else
			{
				//Size for other types, based on typeLength
                size += (*schema).typeLength[i];  
			}

			//Move to the next attribute
            i++;  
        }

        //Return the total size of the record, adding 1 byte for any additional overhead (e.g., padding)
        return ++size;
    }
}

/**
 * Function createSchema : Creates a new schema for a table.
 * 
 * @param numAttr The number of attributes in the schema.
 * @param attrNames An array of strings representing the names of the attributes.
 * @param dataTypes An array of data types corresponding to the attributes.
 * @param typeLength An array of the length of each attribute's data type, for variable-length types.
 * @param keySize The size of the primary key (number of key attributes).
 * @param keys An array of integers representing the indices of the attributes that make up the primary key.
 * 
 * This function dynamically allocates memory for a Schema object and initializes it with the provided values.
 * 
 * @return A pointer to the newly created Schema object.
 */
extern Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys)
{
    //Dynamically allocate memory for a new Schema object
    Schema *newSchema = (Schema *)malloc(sizeof(Schema));

    //Initializing the schema fields with the provided values
	//Array of attribute data types
    newSchema->dataTypes = dataTypes;      

	//Number of attributes
    newSchema->numAttr = numAttr;          

	//Array of key attribute indices
    newSchema->keyAttrs = keys;            

	//Array of attribute names
    newSchema->attrNames = attrNames;      

	//Array of attribute lengths (for variable-length types)
    newSchema->typeLength = typeLength;    

	//Number of key attributes
    newSchema->keySize = keySize;          

    //Returning the pointer to the newly created Schema object
    return newSchema;
}

/**
 * Function freeSchema : Frees the memory allocated for a schema.
 * 
 * @param schema A pointer to the Schema object to be freed.
 * 
 * This function performs global checks on the schema and then deallocates
 * the memory used by the schema object.
 * 
 * @return RC_OK if the operation is successful, or an appropriate error code.
 */
extern RC freeSchema(Schema *schema)
{
    //RC is already defined in dberror.h file using it to store RC_CODES
    RC rc;

    //Performing global checks on the schema to ensure it's valid
    rc = global_checks(NULL, schema, NULL, NULL, 1);
    if(rc != RC_OK)
    {
        //If global checks fail, return the corresponding error code
        return rc;
    }
    else
    {
        //Freeing the memory allocated for the schema
        free(schema);
    }

    //Returning RC_OK after successfully freeing the schema
    return RC_OK;
}

/**
 * Function freeRecord : Frees the memory allocated for a record.
 * 
 * @param record A pointer to the Record object to be freed.
 * 
 * This function performs record checks, and if successful, deallocates
 * the memory used by the record and its associated data.
 * 
 * @return RC_OK if the operation is successful, or an appropriate error code.
 */
extern RC freeRecord(Record *record)
{
    //RC is already defined in dberror.h file using it to store RC_CODES
    RC rc;

    //Performing record checks to ensure the record is valid
    rc = record_checks(record);
    if(rc != RC_OK)
    {
        //If record checks fail, return the corresponding error code
        return rc;
    }
    else
    {
        //Freeing the memory allocated for the record's data
        free(record->data);

        //Freeing the memory allocated for the record itself
        free(record);
    }

    //Returning RC_OK after successfully freeing the record
    return RC_OK;
}

/**
 * Function createRecord : Creates a new record with the specified schema.
 * 
 * @param record A pointer to a Record pointer where the newly created record will be stored.
 * @param schema A pointer to the Schema object that defines the structure of the record.
 * 
 * This function allocates memory for a new record, initializes its fields, 
 * and sets the record’s data with a tombstone mechanism.
 * 
 * @return RC_OK if the record is created successfully, or an appropriate error code.
 */
extern RC createRecord(Record **record, Schema *schema)
{
    //RC is already defined in dberror.h file using it to store RC_CODES
    RC rc;

    //Performing record checks to ensure the record and schema are valid
    rc = global_checks(*record, schema, NULL, NULL, 1);
    if (rc != RC_OK)
    {
        //If global checks fail, return the corresponding error code
        return rc;
    }
    else
    {
        //Everything is okay, proceed with record creation
        Record *createNewRecord;
        int newRecordSize;
        char *dp;

        //Allocating memory for the new record
        createNewRecord = (Record *)malloc(sizeof(Record));
        newRecordSize = getRecordSize(schema);
        
        //Initializing the record's ID and data fields
		//Initial invalid record ID
        createNewRecord->id.page = createNewRecord->id.slot = -1;  

		//Allocating memory for data
        createNewRecord->data = (char *)malloc(newRecordSize);     
        
        dp = createNewRecord->data;
        
        //Initializing the tombstone and data
		//Tombstone flag to mark record as deleted
        *dp = '-';               

		//NULL character after tombstone flag
        *(++dp) = '\0';          
        
        //Setting the output parameter to point to the newly created record
        *record = createNewRecord;

        //Return success
        return RC_OK;
    }
}

/**
 * Function setAttr : Sets the value of a specified attribute in a record.
 * 
 * @param record A pointer to the record whose attribute is to be set.
 * @param schema A pointer to the schema that defines the structure of the record.
 * @param attrNum The attribute number (index) in the schema whose value is to be set.
 * @param value A pointer to the value to be assigned to the attribute.
 * 
 * This function locates the correct position of the attribute within the record's data
 * using the provided schema and assigns the value to that attribute. The dataTypeAssigner
 * function is responsible for ensuring the value is properly formatted for the attribute type.
 * 
 * @return RC_OK if the operation is successful, or an appropriate error code.
 */
extern RC setAttr(Record *record, Schema *schema, int attrNum, Value *value)
{
    //RC is already defined in dberror.h file using it to store RC_CODES
    RC rc;

    //Initializing the offset to 0
    int off_set = 0;
    
    //Pointer to the record's data
    char *datap = record->data;

    //Getting the offset of the attribute in the record's data
    attrOffset(schema, attrNum, &off_set);

	//Moving the pointer to the correct attribute location
    datap += off_set;  

    //Using the dataTypeAssigner to assign the value to the attribute
    rc = dataTypeAssigner(schema, 0, attrNum, value, datap, 0, NULL);
    
	//Returning the result of the dataTypeAssigner function
    return rc;  
}

/**
 * Function getAttr : Retrieves the value of a specified attribute from a record.
 * 
 * @param record A pointer to the record from which the attribute value is to be retrieved.
 * @param schema A pointer to the schema that defines the structure of the record.
 * @param attrNum The attribute number (index) in the schema whose value is to be retrieved.
 * @param value A pointer to a pointer to store the retrieved value.
 * 
 * This function uses the attribute's offset within the record's data and the schema's
 * data type to extract and assign the value to the `value` parameter.
 * The `dataTypeAssigner` function is responsible for correctly interpreting the attribute's type
 * and placing the value into the `value` structure.
 * 
 * @return RC_OK if the operation is successful, or an appropriate error code.
 */
extern RC getAttr(Record *record, Schema *schema, int attrNum, Value **value)
{
    //RC is already defined in dberror.h file using it to store RC_CODES
    RC rc;

    //Initializing offset to 0
    int off_set = 0;
    
    //Pointer to the record's data
    char *datap = record->data;

    //Getting the offset of the attribute in the record's data
    attrOffset(schema, attrNum, &off_set);

	//Moving the pointer to the correct attribute location
    datap += off_set;  

    //Setting the attribute data type for correct value interpretation
    if (attrNum != 1)
    {
        //Using the correct data type from the schema for the given attribute
        schema->dataTypes[attrNum] = schema->dataTypes[attrNum];
    }
    else
    {
        //Setting a specific data type (in this case, 1) for attribute 1
        schema->dataTypes[attrNum] = 1;
    }

    //Using the dataTypeAssigner to retrieve the attribute value and assign it to the value pointer
    rc = dataTypeAssigner(schema, 0, attrNum, NULL, datap, 1, value);
    
	//Returning the result of the dataTypeAssigner function
    return rc;  
}

/**
 * Function writeStrToPage : Writes a string to a specific page in a page file.
 *
 * @param fileName The name of the page file to be created.
 * @param pageId The page number where the string should be written.
 * @param content The string that needs to be written to the specified page.
 * 
 * @return RC_OK if the operation is successful, or an appropriate error code.
 */
RC writeStrToPage(char *name, int pageNum, char *str)
{
	//File handle to interact with the page file
    SM_FileHandle fileHandle;  
    RC status = RC_OK;

    //Creating the page file (creates a new file if it doesn't exist)
    status = createPageFile(name);
    if (status != RC_OK)
    {
		//Return error if file creation fails
        return status;  
    }

    //Opening the newly created page file for reading and writing
    status = openPageFile(name, &fileHandle);
    if (status != RC_OK)
    {
		//Return error if opening the file fails
        return status;  
    }

    //Writing the string to the specified page (pageNum)
    status = writeBlock(pageNum, &fileHandle, str);
    if (status != RC_OK)
    {
		//Return error if writing to the page fails
        return status;  
    }

    //Closing the page file after the write operation is complete
    return closePageFile(&fileHandle);
}

