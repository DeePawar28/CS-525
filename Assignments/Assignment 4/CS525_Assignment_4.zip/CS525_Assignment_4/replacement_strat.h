#ifndef REPLACEMENT_STRAT_H
#define REPLACEMENT_STRAT_H

#include "buffer_mgr.h"
#include "storage_mgr.h"

RC FIFO_replace(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum, SM_FileHandle *fHandle);
Frame* findReplaceableFrame(BM_BufferPool *const bm);
void moveFrameToTail(Queue *queue, Frame *frame);

RC LRU_replace(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum, SM_FileHandle *fHandle);

#endif