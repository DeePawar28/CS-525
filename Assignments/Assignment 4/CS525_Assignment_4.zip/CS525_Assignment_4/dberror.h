#ifndef DBERROR_H
#define DBERROR_H

#include "stdio.h"

/* Module-wide constants */
#define PAGE_SIZE 4096

/* Return Code Definitions */
typedef int RC;

/* General Operation Codes */
#define RC_OK 0
#define RC_FILE_NOT_FOUND 1
#define RC_FILE_HANDLE_NOT_INIT 2
#define RC_WRITE_FAILED 3
#define RC_READ_NON_EXISTING_PAGE 4
#define RC_PAGE_NOT_FOUND 5

/* Record Manager Error Codes */
#define RC_RM_COMPARE_VALUE_OF_DIFFERENT_DATATYPE 200
#define RC_RM_EXPR_RESULT_IS_NOT_BOOLEAN 201
#define RC_RM_BOOLEAN_EXPR_ARG_IS_NOT_BOOLEAN 202
#define RC_RM_NO_MORE_TUPLES 203
#define RC_RM_NO_PRINT_FOR_DATATYPE 204
#define RC_RM_UNKOWN_DATATYPE 205

/* Index Manager Error Codes */
#define RC_IM_KEY_NOT_FOUND 300
#define RC_IM_KEY_ALREADY_EXISTS 301
#define RC_IM_N_TOO_LARGE 302
#define RC_IM_NO_MORE_ENTRIES 303

/* Buffer Pool Manager Error Codes */
#define RC_PAGE_NOT_IN_BUFFER_POOL 400
#define RC_INVALID_NUMPAGES 401
#define RC_INVALID_STRATEGY 402
#define RC_INVALID_BM 403
#define RC_INVALID_PAGE_FILE_NAME 404
#define RC_INVALID_PAGE_HANDLE 405
#define RC_INVALID_PAGE_NUM 406
#define RC_BUFFER_POOL_INIT_FAILED 407
#define RC_FIX_COUNT_ALREADY_ZERO 408
#define RC_BUFFER_POOL_FULL 409
#define RC_NO_REPLACEMENT_FRAME 410
#define RC_MEMORY_ALLOCATION_FAIL 411
#define RC_RM_NO_SPACE_IN_PAGE 412
#define RC_PINNED_PAGES_STILL_IN_BUFFER 413 // Added error code for pinned pages still in buffer

/* NULL Value and Schema Error Codes */
#define RC_RECORD_NULL_ERROR 414
#define RC_SCHEMA_NULL_ERROR 415
#define RC_SCHEMA_ATTRIBUTE_NOT_FOUND 416
#define RC_VALUE_NULL_ERROR 417
#define RC_SCHEMA_DATA_TYPE_ERROR 418
#define RC_NULL_PARAM 419   // Generic null parameter error
#define RC_NULL_IP_PARAM 420 // Define RC_NULL_IP_PARAM for specific null pointer issues
#define RC_RELATION_NULL_ERROR 421

/* Page Operation Error Codes */
#define RC_PIN_PAGE_FAILED 422
#define RC_UNPIN_PAGE_FAILED 423
#define RC_FORCE_PAGE_FAILED 424
#define RC_FILE_DESTROY_FAILED 425
#define RC_RM_NO_TUPLE_WITH_GIVEN_RID 426
#define RC_SCAN_CONDITION_NOT_FOUND 427
#define RC_SCAN_NOT_FOUND 428
#define RC_CONDITION_NOT_MET 429
#define RC_SCAN_COM_ERROR 430
#define RC_TREE_NOT_FOUND 431

/* General Error Code */
#define RC_ERROR 500

/* Holder for error messages */
extern char *RC_message;

/* Function Prototypes */
extern void printError(RC error);
extern char *errorMessage(RC error);

/* THROW Macro for returning error with message */
#define THROW(rc, message) \
    do {                   \
        RC_message = message; \
        return rc;         \
    } while (0)

/* CHECK Macro for error handling and message display */
#define CHECK(code)                                          \
    do {                                                     \
        int rc_internal = (code);                            \
        if (rc_internal != RC_OK)                            \
        {                                                    \
            char *message = errorMessage(rc_internal);       \
            printf("[%s-L%i-%s] ERROR: %s\n", __FILE__, __LINE__, __TIME__, message); \
            if (message != RC_message) { free(message); }    \
            exit(1);                                         \
        }                                                    \
    } while(0)

#endif // DBERROR_H
