//Include the required libraries
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include "buffer_mgr.h"
#include "dberror.h"
#include "dt.h"
#include "storage_mgr.h"
#include "replacement_strat.h"


extern RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage);
extern RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage);

/**
 * Function FIFO_replace : Replaces a page in the buffer pool using FIFO replacement policy.
 *
 * @param bm Pointer to the buffer pool containing the pages to be managed.
 * @param page Pointer to the page handle that will be updated with the new page.
 * @param pageNum The page number of the page to be loaded into the buffer.
 * @param fHandle Pointer to the file handle that represents the file to be read/written.
 *
 * This function replaces a page in the buffer pool using a FIFO (First-In-First-Out) replacement strategy. 
 * It first identifies a frame that can be replaced. If a frame is found, the function checks whether the frame 
 * is dirty (i.e., it has been modified) and writes it back to the file if necessary. After that, it ensures the 
 * file has enough capacity to accommodate the requested page and loads the new page into the buffer. 
 * The metadata for the replaced frame is updated, and the page handle is adjusted to reflect the newly loaded page. 
 * Finally, the replaced frame is moved to the tail of the FIFO queue, maintaining the FIFO order.
 *
 * @return RC_OK if the page replacement is successful, or an appropriate error code if it fails.
 */
RC FIFO_replace(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum, SM_FileHandle *fHandle) 
{ 
    BufferPoolMgmt *bpMan = (BufferPoolMgmt *)bm->mgmtData;

    //Finding a frame that can be replaced in the buffer pool.
    Frame *replaceableFrame = findReplaceableFrame(bm);

    if(replaceableFrame == NULL) 
    {
        //No frame is available for replacement because all are pinned.
        return RC_NO_REPLACEMENT_FRAME;
    }

    //If the frame is dirty, write it back to the file.
    if(replaceableFrame->isDirty) 
    {
        writeBlock(replaceableFrame->pageNum, fHandle, replaceableFrame->data);
        bpMan->numWriteIO++;
    }

    //Ensuring that the file has enough capacity to accommodate the new page.
    ensureCapacity(pageNum + 1, fHandle);

    //Loading the requested page into the frame.
    readBlock(pageNum, fHandle, replaceableFrame->data);
    bpMan->numReadIO++;

    //Updating the metadata for the replaced frame.
    replaceableFrame->pageNum = pageNum;
    replaceableFrame->isDirty = false;
    replaceableFrame->fixCount = 1;

    //Updating the page handle to point to the newly loaded page.
    page->pageNum = pageNum;
    page->data = replaceableFrame->data;

    //Moving the replaced frame to the tail of the FIFO queue to maintain the replacement order.
    moveFrameToTail(bpMan->queue, replaceableFrame);

    return RC_OK;
}

/**
 * Function findReplaceableFrame : Identifies a frame in the buffer pool that is available for replacement.
 *
 * @param bm Pointer to the buffer pool that contains the frames to be managed.
 * 
 * This function scans the frames in the buffer pool, looking for a frame that is not currently pinned (i.e., 
 * its `fixCount` is zero). It starts from the head of the queue and traverses through the frames until it finds 
 * a frame with a `fixCount` of zero, which means the frame can be replaced. If no such frame is found, it returns NULL, 
 * indicating that all frames are pinned and cannot be replaced at this time.
 *
 * @return A pointer to the first frame that is available for replacement, or NULL if no replaceable frame is found.
 */
Frame* findReplaceableFrame(BM_BufferPool *const bm) 
{
    //Accessing buffer pool management data
    BufferPoolMgmt *bpMan = (BufferPoolMgmt *)bm->mgmtData; 

    //Getting the queue of frames in the buffer pool
    Queue *queue = bpMan->queue;  

    //Starting from the head of the queue
    Frame *currentFrame = queue->head; 

    //Iterating through the frames in the queue
    while(currentFrame != NULL) 
    {
        //Checking if the current frame is unpinned (i.e., its fixCount is zero)
        if (currentFrame->fixCount == 0) 
        {
            //Returning the frame that can be replaced
            return currentFrame; 
        }
        //Moving to the next frame in the queue
        currentFrame = currentFrame->next; 
    }

    //No replaceable frame found, all frames are pinned
    return NULL; 
}

/**
 * Function moveFrameToTail : Moves a frame to the tail of the queue, updating the queue's order.
 *
 * @param queue Pointer to the queue that contains the frames to be reordered.
 * @param frame Pointer to the frame that needs to be moved to the tail of the queue.
 *
 * This function moves a given frame from its current position in the queue to the end (tail) of the queue. 
 * It first adjusts the links between the surrounding frames to remove the frame from its current position, 
 * and then appends it to the tail of the queue. If the frame is already at the head of the queue or the middle, 
 * it ensures that the previous and next frames are correctly linked.
 */
void moveFrameToTail(Queue *queue, Frame *frame) 
{
    //Checking if the frame is at the head of the queue and has other frames after it
    if(queue->head == frame && frame->next) 
    {
        //Moving the head pointer to the next frame
        queue->head = frame->next; 

        //Setting the previous pointer of the next frame to NULL
        frame->next->prev = NULL;  
    } 
    else if(frame->prev) 
    {
        //Disconnecting the frame from its previous node
        frame->prev->next = frame->next;
    }
    if(frame->next) 
    {
        //Disconnecting the frame from its next node
        frame->next->prev = frame->prev;
    }

    //Reattaching the frame at the tail of the queue
    //Setting the previous pointer to the current tail
    frame->prev = queue->tail;  

    //Setting the next pointer to NULL (it will be the new tail)
    frame->next = NULL;         
    
    if(queue->tail) 
    {
        //If the queue is not empty, link the previous tail to the frame
        queue->tail->next = frame;
    }
    
    //Updating the tail pointer to the new frame at the end
    queue->tail = frame;  
}

/**
 * Function LRU_replace : Replaces a page in the buffer pool using the Least Recently Used (LRU) algorithm.
 *
 * @param bm Pointer to the buffer pool that manages the frames.
 * @param page Pointer to the page handle where the requested page data will be stored.
 * @param pageNum The page number of the requested page to be loaded.
 * @param fHandle Pointer to the file handle to interact with the storage file.
 *
 * This function attempts to load a requested page into the buffer pool using the LRU page replacement algorithm.
 * It first checks if the page is already loaded in the buffer. If the page is found, it increments its 
 * fix count, updates the page handle, and moves the frame to the tail of the queue to mark it as the most recently used.
 * If the page is not found, the function locates an available frame, writes back any dirty page, 
 * ensures sufficient file capacity, loads the requested page, updates the frame metadata, and moves the frame 
 * to the tail of the queue to maintain LRU ordering.
 *
 * @return RC_OK if the page is successfully loaded, otherwise an appropriate error code.
 */
RC LRU_replace(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum, SM_FileHandle *fHandle) 
{
    BufferPoolMgmt *bpMan = (BufferPoolMgmt *)bm->mgmtData;

    //Checking if the requested page is already loaded in the buffer pool
    for(int i = 0; i < bm->numPages; i++) 
    {
        if(bpMan->frames[i].pageNum == pageNum) 
        {
            //Incrementing the fix count for the page and mark it as most recently used
            bpMan->frames[i].fixCount++;
            page->data = bpMan->frames[i].data;

            //Moving the frame to the tail of the queue to indicate it was recently used
            moveFrameToTail(bpMan->queue, &bpMan->frames[i]);

            return RC_OK;
        }
    }

    //Locating a frame that can be replaced (i.e., unpinned)
    Frame *replaceableFrame = findReplaceableFrame(bm);

    if(replaceableFrame == NULL) 
    {
        //No available frame to replace (all pages are pinned)
        return RC_NO_REPLACEMENT_FRAME;
    }

    //If the frame is dirty, write it back to storage before replacement
    if (replaceableFrame->isDirty) 
    {
        writeBlock(replaceableFrame->pageNum, fHandle, replaceableFrame->data);
        bpMan->numWriteIO++;
    }

    //Ensuring the file has enough capacity for the requested page
    ensureCapacity(pageNum + 1, fHandle);

    //Reading the requested page into the frame
    readBlock(pageNum, fHandle, replaceableFrame->data);
    bpMan->numReadIO++;

    //Updating the frame's metadata to reflect the new page
    replaceableFrame->pageNum = pageNum;
    replaceableFrame->isDirty = false;
    replaceableFrame->fixCount = 1;

    //Updating the page handle to point to the new page data
    page->pageNum = pageNum;
    page->data = replaceableFrame->data;

    //Moving the frame to the tail of the queue to mark it as the most recently used
    moveFrameToTail(bpMan->queue, replaceableFrame);

    return RC_OK;
}

