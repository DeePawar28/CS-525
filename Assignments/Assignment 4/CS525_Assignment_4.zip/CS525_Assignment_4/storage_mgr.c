//Include the required libraries
#include "storage_mgr.h"
#include "dberror.h"
#include "test_helper.h"
#include <stdio.h>
#include <stdlib.h>

/*
1024 is reserved at start of the file for storing metadata
*/
#define META_DATA_SIZE 1024

/**
 * Function initStorageManager : Initializes the Storage Manager module.
 *
 * This function serves as the initialization point for the Storage Manager. 
 * It sets up any global state or resources needed before file operations 
 * (like creating, opening, or writing to page files) can be performed.
 * 
 * Currently, it only prints an initialization message, but it can be extended 
 * to include more complex startup logic if required.
 */
void initStorageManager()
{
    printf("Storage Manager has been initialized.\n");
}

/**
 * Function createPageFile : Creates a new page file with an initial page and metadata.
 *
 * @param fileName Name of the file to be created.
 *
 * This function creates a new file that can be used by the Storage Manager. 
 * It opens the file in write mode, allocates space for metadata and one page, 
 * initializes the metadata (e.g., sets the total number of pages to 1), 
 * writes the combined metadata and page to disk, and then cleans up resources.
 *
 * @return RC_OK on successful file creation, otherwise returns RC_FILE_NOT_FOUND
 *         if the file could not be opened.
 */
RC createPageFile(char *fileName)
{
    FILE *filePtr = NULL;
    char *memoryBlock;

    printf("Creating a new page file with name : %s\n", fileName);

    //Trying to open the file in write-plus mode
    filePtr = fopen(fileName, "w+");

    //Checking if the file was successfully created
    if(filePtr == NULL)
    {
        printError(RC_FILE_NOT_FOUND);
        return RC_FILE_NOT_FOUND;
    }

    //Allocating memory for metadata plus one page
    memoryBlock = (char *)calloc(META_DATA_SIZE + PAGE_SIZE, sizeof(char));

    //Initializing metadata: set total number of pages to 1
    int totalPages = 1;
    memcpy(memoryBlock, &totalPages, sizeof(int));

    //Writing metadata and initial page to file
    fwrite(memoryBlock, sizeof(char), META_DATA_SIZE + PAGE_SIZE, filePtr);

    //Releasing allocated memory and close the file
    free(memoryBlock);
    fclose(filePtr);
    filePtr = NULL;

    return RC_OK;
}

/**
 * Function openPageFile : Opens an existing page file and initializes the file handle.
 *
 * @param fileName Name of the file to be opened.
 * @param fHandle Pointer to the SM_FileHandle structure to be initialized.
 *
 * This function opens an existing page file in read-write mode, validates the input file handle,
 * reads the metadata (specifically, the total number of pages), and initializes the file handle 
 * with relevant details including the file name, total number of pages, and current page position.
 * It ensures proper error handling for file access issues, uninitialized file handles, and metadata
 * read failures.
 *
 * @return RC_OK if the file is successfully opened and initialized,
 *         RC_FILE_NOT_FOUND if the file does not exist,
 *         or RC_FILE_HANDLE_NOT_INIT / RC_READ_NON_EXISTING_PAGE for other initialization errors.
 */
RC openPageFile(char *fileName, SM_FileHandle *fHandle)
{
    FILE *filePtr;

    //Trying to open the file in read/write mode
    filePtr = fopen(fileName, "r+");

    //Checking if the file exists and is accessible
    if(filePtr == NULL)
    {
        RC_message = "Unable to open the file.\n";
        printError(RC_FILE_NOT_FOUND);
        return RC_FILE_NOT_FOUND;
    }

    //Validating the provided file handle pointer
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        fclose(filePtr);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Allocating memory for storing the file name
    fHandle->fileName = (char *)malloc((strlen(fileName) + 1) * sizeof(char));
    if(fHandle->fileName == NULL)
    {
        RC_message = "Memory allocation failed.\n";
        fclose(filePtr);
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Copying the file name to the file handle
    strcpy(fHandle->fileName, fileName);

    //Moving to the start of the file to read metadata
    fseek(filePtr, 0L, SEEK_SET);

    //Variable to hold the total number of pages
    int totalPages;

    //Attempting to read metadata (total number of pages)
    if(fread(&totalPages, sizeof(int), 1, filePtr) < 1)
    {
        free(fHandle->fileName);
        fclose(filePtr);
        RC_message = "Unable to read the meta-data from file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Populating file handle structure
    fHandle->totalNumPages = totalPages;
    fHandle->curPagePos = 0;
    fHandle->mgmtInfo = (void *)filePtr;

    return RC_OK;
}

/**
 * Function closePageFile : Closes an open page file and cleans up resources.
 *
 * @param fHandle Pointer to the SM_FileHandle structure representing the open file.
 *
 * This function safely closes an open page file by ensuring that the file handle is
 * valid and properly initialized. It then closes the underlying file stream, deallocates 
 * memory used for storing the file name, and resets internal file handle pointers to NULL 
 * to avoid dangling references.
 *
 * @return RC_OK if the file is successfully closed,
 *         or RC_FILE_HANDLE_NOT_INIT if the file handle is invalid or uninitialized.
 */
RC closePageFile(SM_FileHandle *fHandle)
{
    //Ensuring the file handle is valid
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring the internal file stream pointer is valid
    if (fHandle->mgmtInfo == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Closing the associated file stream
    fclose((FILE *)fHandle->mgmtInfo);

    //Freeing the memory used for the file name
    free(fHandle->fileName);

    //Reseting the file handle's internal fields
    fHandle->fileName = NULL;
    fHandle->mgmtInfo = NULL;

    return RC_OK;
}

/**
 * Function destroyPageFile : Deletes a page file from the file system.
 *
 * @param fileName Name of the file to be deleted.
 *
 * This function removes the specified page file from the disk. It attempts to delete
 * the file using the standard `remove` function. If the file is not found or deletion fails,
 * it returns an appropriate error code and sets an error message.
 *
 * @return RC_OK if the file was successfully deleted,
 *         RC_FILE_NOT_FOUND if the file does not exist or deletion fails.
 */
RC destroyPageFile(char *fileName)
{
    //Attempting to delete the specified file
    if(remove(fileName) != 0)
    {
        RC_message = "Unable to delete the file.\n";
        printError(RC_FILE_NOT_FOUND);
        return RC_FILE_NOT_FOUND;
    }

    //printing the message
    printf("Successfully destroyed the page file.\n");
    return RC_OK;
}

/**
 * Function readBlock : Reads a specific page from a page file into memory.
 *
 * @param pageNum   The page number to read from the file.
 * @param fHandle   Pointer to the file handle associated with the page file.
 * @param memPage   Memory buffer where the page content will be loaded.
 *
 * This function ensures that the requested page number is within valid range and
 * attempts to load the corresponding page content from the file into the given memory buffer.
 * It adjusts the file pointer to the correct offset (accounting for meta-data) and reads a full
 * page of data. If successful, the current page position in the file handle is updated.
 * It performs checks for file handle validity, buffer initialization, and file seeking errors.
 *
 * @return RC_OK on successful read,
 *         RC_FILE_HANDLE_NOT_INIT if the file handle is invalid,
 *         RC_READ_NON_EXISTING_PAGE if the page number is invalid or if reading fails.
 */
RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Ensuring the file handle is properly initialized
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring the memory buffer provided is not NULL
    if(memPage == NULL)
    {
        RC_message = "Memory page is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Validating that the page number is within the file's current total number of pages
    if(pageNum < 0 || pageNum > fHandle->totalNumPages)
    {
        RC_message = "Page number is out of range.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Calculating the byte offset in the file where the requested page starts
    //This considers the reserved space for metadata at the beginning of the file
    int startPosition = (pageNum * PAGE_SIZE) + META_DATA_SIZE;

    //Moving the file pointer to the desired position
    if(fseek((FILE *)fHandle->mgmtInfo, startPosition, SEEK_SET) != 0)
    {
        RC_message = "Unable to the read page.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Reading exactly PAGE_SIZE bytes from the file into the memory buffer
    if(fread(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Unable to read the page. (INTO BUFFER).\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Updating the current page position in the file handle for future reference
    fHandle->curPagePos = pageNum;

    //Successful read operation
    return RC_OK;
}

/**
 * Function getBlockPos : Retrieves the position of the currently accessed page.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 *
 * This function returns the page number that is currently being accessed or operated on.
 * It first validates that the file handle is properly initialized to avoid invalid memory access.
 *
 * @return The current page position (as an integer) on success,
 *         or RC_FILE_HANDLE_NOT_INIT if the file handle is not properly set.
 */
int getBlockPos(SM_FileHandle *fHandle)
{
    //Checking if the file handle is properly initialized
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Returning the index of the current page in use
    return fHandle->curPagePos;
}

/**
 * Function readFirstBlock : Reads the first page block from a file into memory.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 * @param memPage Buffer to store the contents of the first page read from disk.
 *
 * This function reads the very first data block (page 0) from the file, after skipping 
 * the metadata section. It performs necessary validations and updates the current 
 * page position upon a successful read.
 *
 * @return RC_OK on successful read,
 *         or an appropriate error code if the read fails or inputs are invalid.
 */
RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Validating file handle
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Validating memory buffer
    if(memPage == NULL)
    {
        RC_message = "Memory buffer for the page is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Moving the file pointer to the beginning of the first page (after metadata)
    if(fseek((FILE *)fHandle->mgmtInfo, META_DATA_SIZE, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the first page in the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Attempting to read PAGE_SIZE bytes into the memory buffer
    if(fread(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Failed to read the first page from file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Updating the current page position in the file handle
    fHandle->curPagePos = 0;

    return RC_OK;
}

/**
 * Function readPreviousBlock : Reads the previous page block from the file into memory.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 * @param memPage Buffer to store the contents of the previous page read from disk.
 *
 * This function reads the previous data block (the page before the current page) from the file.
 * It performs necessary checks, calculates the correct position, and updates the current page 
 * position after the read operation.
 *
 * @return RC_OK on successful read,
 *         or an appropriate error code if the read fails or inputs are invalid.
 */
RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Validating the file handle
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Validating the memory page buffer
    if(memPage == NULL)
    {
        RC_message = "Memory page buffer is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Calculating the position of the previous block (one page before the current page)
    int startPos = (fHandle->curPagePos - 1) * PAGE_SIZE + META_DATA_SIZE;

    //Seeking to the start position of the previous block in the file
    if(fseek((FILE *)fHandle->mgmtInfo, startPos, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the previous page in the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Reading the contents of the previous page into the memory buffer
    if (fread(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Failed to read the previous page from the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Updating the current page position to reflect the previous page
    fHandle->curPagePos--;

    return RC_OK;
}

/**
 * Function readCurrentBlock : Reads the current page block from the file into memory.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 * @param memPage Buffer to store the contents of the current page read from disk.
 *
 * This function reads the current data block (the page at the current position) from the file.
 * It performs necessary checks and updates the file pointer to the correct position before reading.
 *
 * @return RC_OK on successful read,
 *         or an appropriate error code if the read fails or inputs are invalid.
 */
RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Validating the file handle
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Validating the memory page buffer
    if(memPage == NULL)
    {
        RC_message = "Memory page buffer is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Calculating the position of the current block in the file
    int startPos = (fHandle->curPagePos) * PAGE_SIZE + META_DATA_SIZE;

    //Seeking to the current block's position
    if(fseek((FILE *)fHandle->mgmtInfo, startPos, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the current page in the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Reading the contents of the current page into the memory buffer
    if(fread(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Failed to read the current page from the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    return RC_OK;
}

/**
 * Function readNextBlock : Reads the next page block from the file into memory.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 * @param memPage Buffer to store the contents of the next page read from disk.
 *
 * This function reads the page block at the next position from the current one.
 * It checks for necessary conditions, moves the file pointer to the correct position, 
 * and reads the page into the provided memory buffer.
 *
 * @return RC_OK on successful read,
 *         or an appropriate error code if the read fails or inputs are invalid.
 */
RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Validating the file handle
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Validating the memory page buffer
    if(memPage == NULL)
    {
        RC_message = "Memory page buffer is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Calculating the position of the next block in the file
    int startPos = (fHandle->curPagePos + 1) * PAGE_SIZE + META_DATA_SIZE;

    //Seeking to the position of the next block
    if(fseek((FILE *)fHandle->mgmtInfo, startPos, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the next page in the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Reading the next page into the memory buffer
    if(fread(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Failed to read the next page from the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Updating the current page position
    fHandle->curPagePos++;

    return RC_OK;
}

/**
 * Function readLastBlock : Reads the last page block from the file into memory.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 * @param memPage Buffer to store the contents of the last page read from disk.
 *
 * This function reads the page block at the last position in the file.
 * It checks the validity of the inputs, moves the file pointer to the correct position,
 * and reads the last page into the provided memory buffer.
 *
 * @return RC_OK on successful read,
 *         or an appropriate error code if the read fails or inputs are invalid.
 */
RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Ensuring the file handle is valid
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring the memory page buffer is initialized
    if(memPage == NULL)
    {
        RC_message = "Memory page buffer is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Calculating the position of the last block in the file
    int startPos = (fHandle->totalNumPages - 1) * PAGE_SIZE + META_DATA_SIZE;

    //Seeking to the last block's position in the file
    if(fseek((FILE *)fHandle->mgmtInfo, startPos, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the last page in the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Reading the last page into the memory buffer
    if(fread(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Failed to read the last page from the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Updating the current page position to the last page
    fHandle->curPagePos = fHandle->totalNumPages - 1;

    return RC_OK;
}

/**
 * Function writeBlock : Writes the contents of the memory page into the file at the specified page number.
 *
 * @param pageNum The page number where the data should be written.
 * @param fHandle Pointer to the file handle representing the open page file.
 * @param memPage Buffer containing the data to write to the page in the file.
 *
 * This function writes the contents of the memory buffer to a specific page in the file.
 * It checks for input validity, seeks to the correct position, and writes the data.
 * If the specified page is the last one in the file, it updates the file's metadata to reflect the new total page count.
 *
 * @return RC_OK on successful write,
 *         or an appropriate error code if the write fails or inputs are invalid.
 */
RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Ensuring the file handle is valid
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring the memory page buffer is initialized
    if(memPage == NULL)
    {
        RC_message = "Memory page buffer is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Checking that the page number is within valid range
    if(pageNum < 0 || pageNum >= fHandle->totalNumPages)
    {
        RC_message = "Page number is out of range.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //If the page number is the last one, update the file's metadata (totalNumPages)
    if(pageNum == fHandle->totalNumPages)
    {
        //Incrementing totalNumPages and update meta-data (meta-data is stored at the beginning of the file)
        int totalNumPages = fHandle->totalNumPages + 1;

        //Seeking to the start of the file to update the total page count
        if(fseek((FILE *)fHandle->mgmtInfo, 0, SEEK_SET) != 0)
        {
            RC_message = "Failed to seek to start position while updating metadata.\n";
            printError(RC_WRITE_FAILED);
            return RC_WRITE_FAILED;
        }

        //Writing the updated totalNumPages back to the file
        if(fwrite(&totalNumPages, sizeof(char), sizeof(int), (FILE *)fHandle->mgmtInfo) < sizeof(int))
        {
            RC_message = "Failed to write updated totalNumPages to file.\n";
            printError(RC_WRITE_FAILED);
            return RC_WRITE_FAILED;
        }

        //Updating the totalNumPages field in the file handle
        fHandle->totalNumPages = totalNumPages;
    }

    //Calculating the start position for the target page in the file
    int startPos = (pageNum * PAGE_SIZE) + META_DATA_SIZE;

    //Seeking to the correct position in the file to write the page
    if(fseek((FILE *)fHandle->mgmtInfo, startPos, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the target position for writing the page.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //Writing the contents of the memory page buffer to the file
    if(fwrite(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Failed to write data to the file.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //Updating the current page position in the file handle
    fHandle->curPagePos = pageNum;

    return RC_OK;
}

/**
 * Function writeCurrentBlock : Writes the contents of the memory page to the current page position in the file.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 * @param memPage Buffer containing the data to write to the current page in the file.
 *
 * This function writes the contents of the memory buffer to the current page in the file.
 * It ensures that the file handle and memory buffer are valid, calculates the position of the current page, 
 * seeks to that position, and writes the page data. If any issues occur during these operations, 
 * an appropriate error message is set.
 *
 * @return RC_OK on successful write,
 *         or an appropriate error code if the write fails or inputs are invalid.
 */
RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    //Ensuring the file handle is valid
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Ensuring the memory page buffer is initialized
    if(memPage == NULL)
    {
        RC_message = "Memory page buffer is not initialized.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Calculating the start position of the current page in the file
    int startPos = (fHandle->curPagePos * PAGE_SIZE) + META_DATA_SIZE;

    //Seeking to the calculated position of the current page in the file
    if(fseek((FILE *)fHandle->mgmtInfo, startPos, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the current page position in the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    //Writing the contents of the memory page buffer to the file at the current position
    if(fwrite(memPage, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        RC_message = "Failed to write the page data to the file.\n";
        printError(RC_READ_NON_EXISTING_PAGE);
        return RC_READ_NON_EXISTING_PAGE;
    }

    return RC_OK;
}

/**
 * Function appendEmptyBlock : Appends a new empty block to the file and updates metadata.
 *
 * @param fHandle Pointer to the file handle representing the open page file.
 *
 * This function appends an empty block (a block filled with zeroes) to the file.
 * It updates the total number of pages in the file and ensures that the file handle is valid. 
 * The function also handles any errors that may occur during seeking, writing, or memory allocation.
 *
 * @return RC_OK on success,
 *         or an appropriate error code if the append fails or inputs are invalid.
 */
RC appendEmptyBlock(SM_FileHandle *fHandle)
{
    //Ensuring the file handle is valid
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Incrementing the total number of pages in the file (to reflect the new empty block)
    int totalNumP = fHandle->totalNumPages + 1;

    //Seeking to the beginning of the file to update the total number of pages
    if(fseek((FILE *)fHandle->mgmtInfo, 0, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the beginning of the file during append.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //Writing the updated total number of pages to the file's meta-data
    if(fwrite(&totalNumP, sizeof(int), 1, (FILE *)fHandle->mgmtInfo) != 1)
    {
        RC_message = "Failed to write the updated page count to the file.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //Updating the total number of pages in the file handle
    fHandle->totalNumPages = totalNumP;

    //Calculating the start position for the new block in the file
    int startPos = (fHandle->totalNumPages * PAGE_SIZE) + META_DATA_SIZE;

    //Seeking to the calculated position to write the new empty block
    if(fseek((FILE *)fHandle->mgmtInfo, startPos, SEEK_SET) != 0)
    {
        RC_message = "Failed to seek to the start position for appending the new block.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //Allocating memory for the empty block (a block filled with zeroes)
    char *emptyBlock = (char *)calloc(PAGE_SIZE, sizeof(char));
    if (emptyBlock == NULL)
    {
        RC_message = "Memory allocation failed for appending the empty block.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //Writing the empty block into the file
    if(fwrite(emptyBlock, sizeof(char), PAGE_SIZE, (FILE *)fHandle->mgmtInfo) < PAGE_SIZE)
    {
        free(emptyBlock);
        RC_message = "Failed to write the empty block to the file.\n";
        printError(RC_WRITE_FAILED);
        return RC_WRITE_FAILED;
    }

    //Freeing the allocated memory for the empty block
    free(emptyBlock);

    //Updating the current page position to the newly appended block
    fHandle->curPagePos = fHandle->totalNumPages - 1;

    return RC_OK;
}

/**
 * Function ensureCapacity : Ensures the file has enough pages to accommodate a specified number of pages.
 *
 * @param numberOfPages The required number of pages in the file.
 * @param fHandle Pointer to the file handle representing the open page file.
 *
 * This function checks if the file has enough pages to accommodate the requested number of pages.
 * If the file's current page count is less than the required number of pages, it appends empty blocks
 * to the file until the required capacity is met.
 *
 * @return RC_OK on success,
 *         or an appropriate error code if the file handle is not initialized or any error occurs while appending blocks.
 */
RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle)
{
    //Ensuring the file handle is valid
    if(fHandle == NULL)
    {
        RC_message = "File handle is not initialized.\n";
        printError(RC_FILE_HANDLE_NOT_INIT);
        return RC_FILE_HANDLE_NOT_INIT;
    }

    //Checking if the file has fewer pages than the required number
    if(numberOfPages > fHandle->totalNumPages)
    {
        //Appending empty blocks until the file reaches the required number of pages
        for(int i = 0; i < numberOfPages - fHandle->totalNumPages; i++)
        {
            //Appending an empty block to the file
            RC rc = appendEmptyBlock(fHandle);

            //Checking if appending failed
            if(rc != RC_OK)  
            {
                //Returning the error code if appending failed
                return rc;  
            }
        }
    }

    return RC_OK;
}
