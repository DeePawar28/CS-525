//Include the required libraries
#include "storage_mgr.h"
#include "buffer_mgr.h"
#include "btree_mgr.h"
#include "dberror.h"
#include "tables.h"
#include "record_mgr.h"
#include "string.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

/**
 * Function initIndexManager : Initializes the Index Manager by calling the storage manager initialization.
 *
 * @param mgmtData Pointer to management data (unused in this function).
 *
 * This function performs the following:
 * - It initializes the storage manager which is responsible for managing storage-related operations.
 *
 * @return RC_OK if initialization is successful, indicating that the index manager is ready.
 */
RC initIndexManager(void *mgmtData)
{
    //Initializing the storage manager to manage the underlying storage operations.
    initStorageManager();
    
    //Retuning success status after initialization.
    return RC_OK;
}

/**
 * Function shutdownIndexManager : Shuts down the Index Manager and performs any necessary cleanup.
 *
 * @return RC_OK if the shutdown process is successful, indicating that the index manager has been properly shut down.
 *
 * This function currently doesn't perform any specific cleanup operations, but it's designed to ensure that the 
 * index manager can be gracefully shut down when needed.
 */
RC shutdownIndexManager()
{
    //Returning success status, indicating that the shutdown process was successful.
    return RC_OK;
}

/**
 * Function serializeBtreeHeader : Serializes the B-tree metadata header into a byte array.
 * The header contains important information about the B-tree structure, such as the maximum order,
 * key type, number of nodes, and number of entries.
 *
 * @param mgmtData A pointer to the B-tree metadata structure (BTreeMtdt) to be serialized.
 *
 * @return A pointer to a dynamically allocated memory block (char array) containing the serialized header data.
 *         The caller is responsible for freeing this memory when done.
 */
char *serializeBtreeHeader(BTreeMtdt *mgmtData)
{
    //Allocating memory for the header, initialized to 0 (size of 1 page).
    char *headerBuffer = calloc(1, PAGE_SIZE);
    
    //Initializing an offset to keep track of the current position in the header during serialization.
    int currentOffset = 0;
    
    //Writing the maximum order of the B-tree ('n') into the header at the current offset.
    *(int *)(headerBuffer + currentOffset) = mgmtData->n;
    
    //Incrementing the offset by the size of an integer (int) to move to the next write location.
    currentOffset += sizeof(int);
    
    //Writing the data type of the B-tree keys into the header.
    *(int *)(headerBuffer + currentOffset) = mgmtData->keyType;
    
    //Incrementing the offset to move to the next field.
    currentOffset += sizeof(int);
    
    //Writing the number of nodes currently in the B-tree into the header.
    *(int *)(headerBuffer + currentOffset) = mgmtData->nodes;
    
    //Incrementing the offset to move to the next field.
    currentOffset += sizeof(int);
    
    //Writing the number of entries currently in the B-tree into the header.
    *(int *)(headerBuffer + currentOffset) = mgmtData->entries;
    
    //Incrementing the offset to ensure proper alignment for the next operation (if applicable).
    currentOffset += sizeof(int);
    
    //Returning a pointer to the serialized header data (as a byte array).
    return headerBuffer;
}

/**
 * Function deserializeBtreeHeader : Deserializes a byte array (header) into a B-tree metadata structure.
 * The header contains information such as the maximum order, key type, number of nodes, and number of entries.
 *
 * @param header A pointer to the byte array containing the serialized B-tree metadata header.
 *
 * @return A pointer to the deserialized B-tree metadata structure (BTreeMtdt).
 */
BTreeMtdt *deserializeBtreeHeader(const char *header)
{
    //Initializing the offset to 0, used to track the current position in the header.
    int currentOffset = 0;
    
    //Creating a new B-tree metadata object using a macro (or function) that allocates and initializes it.
    BTreeMtdt *deserializedBTreeMetadata = MAKE_TREE_MTDT();

    //Deserializing the maximum order ('n') from the header and increment the offset.
    deserializedBTreeMetadata->n = *(int *)(header + currentOffset);
    currentOffset += sizeof(int);

    //Deserializing the key type from the header and increment the offset.
    deserializedBTreeMetadata->keyType = *(int *)(header + currentOffset);
    currentOffset += sizeof(int);

    //Deserializing the number of nodes in the B-tree and increment the offset.
    deserializedBTreeMetadata->nodes = *(int *)(header + currentOffset);
    currentOffset += sizeof(int);

    //Deserializing the number of entries in the B-tree and increment the offset.
    deserializedBTreeMetadata->entries = *(int *)(header + currentOffset);
    currentOffset += sizeof(int);

    //Returning the deserialized B-tree metadata structure.
    return deserializedBTreeMetadata;
}

/**
 * Function createBtree : Creates a new B-tree index with the given parameters.
 * It initializes the B-tree metadata, serializes the metadata header, 
 * and writes the serialized data to the first page of the index file.
 *
 * @param idxId A pointer to the string representing the index identifier (file name).
 * @param keyType The data type of the B-tree keys (e.g., INTEGER, VARCHAR).
 * @param n The maximum order of the B-tree (i.e., the maximum number of children per node).
 *
 * @return RC_OK if the operation is successful, or an error code if it fails.
 */
RC createBtree(const char *idxId, DataType keyType, int n)
{
    //Declaring the result variable to hold the return code from operations
    RC operationResult;

    //Allocating memory for the B-tree metadata structure
    BTreeMtdt *treeMetadata = MAKE_TREE_MTDT();

    //Setting the B-tree's properties based on the input parameters
    treeMetadata->keyType = keyType;
    treeMetadata->n = n;
    treeMetadata->entries = 0;
    treeMetadata->nodes = 0;

    //Serializing the B-tree metadata header into a byte array
    char *serializedHeader = serializeBtreeHeader(treeMetadata);

    //Writing the serialized header to the index file (page 0)
    operationResult = writeStrToPage((char *)idxId, 0, serializedHeader);

    //Freeing dynamically allocated memory
    if (treeMetadata != NULL) free(treeMetadata);
    if (serializedHeader != NULL) free(serializedHeader);

    //Returning the result of the write operation
    return operationResult;
}

/**
 * Function openBtree : Opens an existing B-tree index and loads its metadata into memory.
 * It initializes a buffer pool, reads the B-tree metadata from the first page, 
 * and sets up necessary parameters for the B-tree handle.
 *
 * @param tree A pointer to a BTreeHandle pointer, which will be initialized with the opened B-tree handle.
 * @param idxId A pointer to the string representing the index identifier (file name).
 *
 * @return RC_OK if the operation is successful, or an error code if it fails.
 */
RC openBtree(BTreeHandle **tree, const char *idxId)
{
    //Allocating memory for the B-tree handle and buffer pool objects
    *tree = MAKE_TREE_HANDLE();
    BM_BufferPool *bufferPool = MAKE_POOL();
    BM_PageHandle *pageHandle = MAKE_PAGE_HANDLE();
    BM_PageHandle *headerPageHandle = MAKE_PAGE_HANDLE();

    //Initializing the buffer pool with 10 pages and an LRU replacement strategy
    initBufferPool(bufferPool, idxId, 10, RS_LRU, NULL);

    //Pinning the first page (header) to read B-tree metadata
    pinPage(bufferPool, headerPageHandle, 0);

    //Deserializing the B-tree metadata from the header page
    BTreeMtdt *btreeMetadata = deserializeBtreeHeader(headerPageHandle->data);

    //If there are no nodes in the B-tree, set the root to NULL
    if (btreeMetadata->nodes == 0)
    {
        btreeMetadata->root = NULL;
    }

    //Calculating the minimum number of entries for leaf and non-leaf nodes
    btreeMetadata->minLeaf = (btreeMetadata->n + 1) / 2;
    btreeMetadata->minNonLeaf = (btreeMetadata->n + 2) / 2 - 1;

    //Setting up the page handle and buffer pool in the metadata
    btreeMetadata->ph = pageHandle;
    btreeMetadata->bm = bufferPool;

    //Setting the B-tree handle's properties
    (*tree)->keyType = btreeMetadata->keyType;
    (*tree)->mgmtData = btreeMetadata;
    (*tree)->idxId = idxId;

    //Freeing the header page handle after use
    if (headerPageHandle != NULL) free(headerPageHandle);

    //Return success
    return RC_OK;
}

/**
 * Function closeBtree : Closes a B-tree index, releasing all associated resources,
 * including the buffer pool and memory allocated for the B-tree metadata and handle.
 *
 * @param tree A pointer to the BTreeHandle that needs to be closed.
 *
 * @return RC_OK if the operation is successful, or an error code if it fails.
 */
RC closeBtree(BTreeHandle *tree)
{
    //Checking if the provided tree pointer is NULL, return an error if it is
    if(tree == NULL) 
    {
        return RC_NULL_PARAM;
    }

    //Retrieving the B-tree metadata from the BTreeHandle
    BTreeMtdt *btreeMetadata = (BTreeMtdt *)tree->mgmtData;

    //Shutdown the buffer pool associated with the B-tree
    shutdownBufferPool(btreeMetadata->bm);

    //Freeing the page handle if it exists
    if (btreeMetadata->ph != NULL) free(btreeMetadata->ph);

    //Freeing the B-tree metadata structure
    if (btreeMetadata != NULL) free(btreeMetadata);

    //Freeing the B-tree handle itself
    free(tree);

    //Returning success
    return RC_OK;
}

/**
 * Function deleteBtree : Deletes a B-tree index by destroying its associated page file.
 * This function removes the B-tree file from storage.
 *
 * @param idxId A pointer to the B-tree index ID (file name) to be deleted.
 *
 * @return RC_OK if the operation is successful, or an error code if it fails.
 */
RC deleteBtree(const char *idxId)
{
    //Casting idxId to char* to match the destroyPageFile parameter type
    return destroyPageFile((char *)idxId);  
}

/**
 * Function getNumNodes : Retrieves the number of nodes in the B-tree index.
 * This function fetches the node count from the B-tree metadata structure.
 *
 * @param tree A pointer to the BTreeHandle representing the B-tree index.
 * @param result A pointer to an integer where the node count will be stored.
 *
 * @return RC_OK if the operation is successful, or an error code if it fails.
 */
RC getNumNodes(const BTreeHandle *tree, int *result)
{
    //Checking for NULL parameters
    if(tree == NULL || result == NULL)
    { 
        return RC_NULL_PARAM;
    }

    //Retrieving B-tree metadata from the tree handle
    BTreeMtdt *btreeMetadata = (BTreeMtdt *)tree->mgmtData;
    
    //Setting the result to the number of nodes in the B-tree
    *result = btreeMetadata->nodes;
    
    return RC_OK;
}

/**
 * Function getNumEntries : Retrieves the number of entries in the B-tree index.
 * This function fetches the entry count from the B-tree metadata structure.
 *
 * @param tree A pointer to the BTreeHandle representing the B-tree index.
 * @param result A pointer to an integer where the entry count will be stored.
 *
 * @return RC_OK if the operation is successful, or an error code if it fails.
 */
RC getNumEntries(const BTreeHandle *tree, int *result)
{
    //Checking for NULL parameters
    if(tree == NULL || result == NULL)
    { 
        return RC_NULL_PARAM;
    }

    //Retrieving B-tree metadata from the tree handle
    BTreeMtdt *btreeMetadata = (BTreeMtdt *)tree->mgmtData;
    
    //Setting the result to the number of entries in the B-tree
    *result = btreeMetadata->entries;
    
    return RC_OK;
}

/**
 * Function getKeyType : Retrieves the key type of the B-tree index.
 * This function fetches the key type from the B-tree metadata structure.
 *
 * @param tree A pointer to the BTreeHandle representing the B-tree index.
 * @param result A pointer to a DataType variable where the key type will be stored.
 *
 * @return RC_OK if the operation is successful, or an error code if it fails.
 */
RC getKeyType(const BTreeHandle *tree, DataType *result)
{
    //Checking for NULL parameters
    if (tree == NULL || result == NULL)
    { 
        return RC_NULL_PARAM;
    }

    //Retrieving B-tree metadata from the tree handle
    BTreeMtdt *btreeMetadata = (BTreeMtdt *)tree->mgmtData;
    
    //Setting the result to the key type of the B-tree
    *result = btreeMetadata->keyType;
    
    return RC_OK;
}

/**
 * Function compareValue : Compares two values of the same type.
 * This function compares the two provided values based on their data type and returns:
 *   - 0 if the values are equal,
 *   - 1 if the first value is greater,
 *   - -1 if the second value is greater.
 *
 * @param key A pointer to the first value to be compared.
 * @param sign A pointer to the second value to be compared.
 *
 * @return An integer: 0 if equal, 1 if key is greater, -1 if sign is greater.
 */
int compareValue(const Value *key, const Value *sign)
{
    //Initializing result to 0 (equal by default)
    int res = 0;  
    
    //Comparing based on the data type of the values
    switch(key->dt)
    {
        case DT_INT:
            //Comparing two integers
            res = (key->v.intV == sign->v.intV) ? 0 : (key->v.intV > sign->v.intV ? 1 : -1);
            break;
        case DT_FLOAT:
            //Comparing two floats
            res = (key->v.floatV == sign->v.floatV) ? 0 : (key->v.floatV > sign->v.floatV ? 1 : -1);
            break;
        case DT_STRING:
            //Comparing two strings lexicographically
            res = strcmp(key->v.stringV, sign->v.stringV);
            break;
        case DT_BOOL:
            //Comparing two booleans (false < true)
            res = (key->v.boolV == sign->v.boolV) ? 0 : -1;
            break;
        default:
            //In case of an unsupported data type
            break;
    }
    
    //Return the comparison result
    return res;  
}

/**
 * Function findLeafNode : Recursively searches for the leaf node that contains a given key.
 * The search traverses down the tree starting from the given node and continues until a leaf node is found.
 * The leaf node is returned as a pointer.
 *
 * @param node A pointer to the current B-tree node being inspected.
 * @param key A pointer to the key being searched for.
 *
 * @return A pointer to the leaf node that contains the given key.
 */
BTreeNode *findLeafNode(BTreeNode *node, Value *key)
{
    //Checking if the current node is a leaf node
    if (node->type == LEAF_NODE)
    {
        //If the node is a leaf, return it directly
        return node;
    }

    //Iterating over the keys in the node to find the appropriate child pointer
    for (int i = 0; i < node->keyNums; i++)
    {
        //Comparing the given key with the current key in the node
        if (compareValue(key, node->keys[i]) < 0)
        {
            //If the given key is less than the current key, recurse into the corresponding child node
            return findLeafNode((BTreeNode *)node->ptrs[i], key);
        }
    }

    //If the key is greater than all keys in the node, or if the node has no keys, recurse into the last child pointer
    return findLeafNode((BTreeNode *)node->ptrs[node->keyNums], key);
}

/**
 * Function findEntryInNode : Searches for a specific key in a B-tree node and returns the associated RID.
 * It iterates through all the keys in the node and compares them with the provided key.
 * If a match is found, the function returns the corresponding RID pointer.
 *
 * @param node A pointer to the B-tree node where the search for the key will be performed.
 * @param key A pointer to the key being searched for in the node.
 *
 * @return A pointer to the RID associated with the found key, or NULL if no matching key is found.
 */
RID *findEntryInNode(BTreeNode *node, Value *key)
{
    //Looping through all the keys currently stored in the node
    for (int i = 0; i < node->keyNums; i++)
    {
        //Comparing the provided key with each key in the node using compareValue
        if (compareValue(key, node->keys[i]) == 0)
        {
            //If a match is found, return the pointer to the RID associated with the key
            return (RID *)node->ptrs[i];
        }
    }

    //If no matching key is found in the node, return NULL
    return NULL;
}

/**
 * Function findKey : Searches for a key in a B-tree and returns the associated RID if found.
 * It navigates through the B-tree to find the correct leaf node and then searches for the key
 * within that leaf node. If the key is found, it copies the associated RID to the result.
 *
 * @param tree A pointer to the B-tree handle that contains metadata and root information.
 * @param key A pointer to the key being searched for in the B-tree.
 * @param result A pointer to the RID where the result will be stored if the key is found.
 *
 * @return RC_OK if the key is found and its associated RID is copied to result.
 *         RC_IM_KEY_NOT_FOUND if the key is not found in the B-tree.
 */
RC findKey(BTreeHandle *tree, Value *key, RID *result)
{
    //Accessing the B-tree's management data to reach the root node
    BTreeMtdt *treeMetadata = (BTreeMtdt *)tree->mgmtData;

    //Finding the correct leaf node L for the key
    BTreeNode *leafNode = findLeafNode(treeMetadata->root, key);

    //If the tree is empty or the key cannot be found in the tree, return error
    if(leafNode == NULL)
    {
        return RC_IM_KEY_NOT_FOUND;
    }

    //Finding the position of the entry in the node using binary search
    RID *entryRID = findEntryInNode(leafNode, key);

    //If no entry is found for the key, return error
    if (entryRID == NULL)
    {
        return RC_IM_KEY_NOT_FOUND;
    }

    //If the key is found, copy the RID from the node to 'result'
    (*result) = (*entryRID);

    //Returning success if key is found
    return RC_OK;
}

/**
 * Function createNode : Creates a new node in the B-tree and initializes it.
 * It increments the total node count, allocates memory for the keys, 
 * and sets the initial state of the node's pointers and key count.
 *
 * @param managementData A pointer to the B-tree's metadata, which includes the current number of nodes and the order of the tree.
 *
 * @return A pointer to the newly created and initialized B-tree node.
 */
BTreeNode *createNode(BTreeMtdt *managementData)
{
    //Incrementing the total node count in the B-tree by 1
    managementData->nodes += 1;
    
    //Allocating memory for a new B-tree node structure
    BTreeNode *newBTreeNode = MAKE_TREE_NODE();
    
    //Allocating memory for the keys in the node; it can hold n+1 keys before a split occurs
    newBTreeNode->keys = malloc((managementData->n + 1) * sizeof(Value *));
    
    //Initializing the number of keys in the node to 0
    newBTreeNode->keyNums = 0;
    
    //Setting the 'next' pointer and the 'parent' pointer to NULL initially
    newBTreeNode->next = NULL;
    newBTreeNode->parent = NULL;
    
    //Returning the newly created node
    return newBTreeNode;
}

/**
 * Function createLeafNode : Creates a new leaf node in the B-tree.
 * It utilizes the general node creation function, then modifies the type 
 * and allocates memory for the pointers in the leaf node.
 *
 * @param managementData A pointer to the B-tree's metadata, which includes the current number of nodes and the order of the tree.
 *
 * @return A pointer to the newly created and initialized leaf node.
 */
BTreeNode *createLeafNode(BTreeMtdt *managementData)
{
    //Creating a new node using the general node creation function
    BTreeNode *leafNode = createNode(managementData);
    leafNode->type = LEAF_NODE;
    
    //Allocating memory for pointers based on the maximum allowed entries for a leaf node
    leafNode->ptrs = (void *)malloc((managementData->n + 1) * sizeof(void *));
    
    return leafNode;
}

/**
 * Function createNonLeafNode : Creates a new non-leaf node in the B-tree.
 * It utilizes the general node creation function, then modifies the type 
 * and allocates memory for the pointers in the non-leaf node.
 *
 * @param managementData A pointer to the B-tree's metadata, which includes the current number of nodes and the order of the tree.
 *
 * @return A pointer to the newly created and initialized non-leaf node.
 */
BTreeNode *createNonLeafNode(BTreeMtdt *managementData)
{
    //Creating a new node using the general node creation function
    BTreeNode *innerNode = createNode(managementData);
    innerNode->type = INNER_NODE;
    
    //Allocating memory for pointers based on the maximum allowed entries for a non-leaf node
    innerNode->ptrs = (void *)malloc((managementData->n + 2) * sizeof(void *));
    
    return innerNode;
}

/**
 * Function getInsertPos : Determines the position where a new key should be inserted in a B-tree node.
 * The position is determined by comparing the new key with existing keys in the node.
 *
 * @param currentNode A pointer to the B-tree node where the new key should be inserted.
 * @param newKey A pointer to the new key that will be inserted into the node.
 *
 * @return The index position where the new key should be inserted.
 */
int getInsertPos(BTreeNode *currentNode, Value *newKey)
{
    //Initializing insertIndex to the current number of keys in the node
    int insertIndex = currentNode->keyNums;
    
    //Iterating over all existing keys in the node to find where the new key fits
    int index = 0;
    while(index < currentNode->keyNums)
    {
        //Using compareValue to compare the current key with the new key
        if(compareValue(currentNode->keys[index], newKey) >= 0)
        {
            //If current key is greater than or equal to new key, we have found the insert position
            insertIndex = index;
            break;
        }
        index++;
    }
    
    //Returning the computed position for inserting the new key
    return insertIndex;
}

/**
 * Function buildRID : Creates a new RID (Record ID) structure by copying the page and slot values from an existing RID.
 *
 * @param rid A pointer to the existing RID that will be copied.
 *
 * @return A pointer to the newly created RID structure with the same page and slot values as the input RID.
 */
RID *buildRID(RID *rid)
{
    //Allocating memory for a new RID structure
    RID *newRID = (RID *)malloc(sizeof(RID));
    
    //Copying the page and slot values from the input RID to the new RID
    newRID->page = rid->page;
    newRID->slot = rid->slot;
    
    //Returning the newly created RID
    return newRID;
}

/**
 * Function insertIntoLeafNode : Inserts a new key and its associated RID into a leaf node of a B-tree.
 * The function shifts existing keys and pointers to make space for the new key.
 *
 * @param leafNode The leaf node in which the new key and RID will be inserted.
 * @param newKey The new key to be inserted into the leaf node.
 * @param recordID The RID (Record ID) associated with the new key.
 * @param managementData B-tree management data, including metadata like the total entries.
 */
void insertIntoLeafNode(BTreeNode *leafNode, Value *newKey, RID *recordID, BTreeMtdt *managementData)
{
    //Finding the appropriate position to insert the new key
    int position = getInsertPos(leafNode, newKey);
    
    //Starting from the end of the node and move backwards to the calculated position
    int idx = leafNode->keyNums;
    while(idx >= position)
    {
        //Shifting key to the right
        leafNode->keys[idx] = leafNode->keys[idx - 1]; 

        //Shifting pointers to the right
        leafNode->ptrs[idx] = leafNode->ptrs[idx - 1]; 
        idx--;
    }
    
    //Inserting the new key and its corresponding RID at the calculated position
    leafNode->keys[position] = newKey;
    leafNode->ptrs[position] = buildRID(recordID);
    
    //Increasing the number of keys in the leaf node and the total entries in the B-tree
    leafNode->keyNums += 1;
    managementData->entries += 1;
}

/**
 * Function splitLeafNode : Splits a leaf node into two and returns a new leaf node containing half of the original node's entries.
 * The function moves half of the keys and pointers to a new node and updates the original node accordingly.
 *
 * @param sourceNode The leaf node to be split.
 * @param managementData B-tree management data, including metadata like the total entries.
 * 
 * @return A new leaf node containing half of the entries from the original node.
 */
BTreeNode *splitLeafNode(BTreeNode *sourceNode, BTreeMtdt *managementData)
{
    //Creating a new leaf node to accommodate half of the entries from the original node
    BTreeNode *newNode = createLeafNode(managementData);
    
    //Calculating the index where the node should be split
    int middleIndex = (sourceNode->keyNums + 1) / 2;
    
    //Begin moving half of the keys and pointers from the original node to the new leaf node
    int targetIdx = sourceNode->keyNums - middleIndex - 1;
    int currentIdx = middleIndex;
    while(currentIdx < sourceNode->keyNums)
    {
        newNode->keys[targetIdx] = sourceNode->keys[currentIdx];
        newNode->ptrs[targetIdx] = sourceNode->ptrs[currentIdx];
        sourceNode->keys[currentIdx] = NULL;
        sourceNode->ptrs[currentIdx] = NULL;
        
        newNode->keyNums += 1;
        sourceNode->keyNums -= 1;
        
        targetIdx += 1;
        currentIdx++;
    }

    //Linking the new leaf node to the next node in the list
    newNode->next = sourceNode->next;
    sourceNode->next = newNode;

    //Setting the parent of the new node to be the same as the original node's parent
    newNode->parent = sourceNode->parent;

    return newNode;
}

/**
 * Function splitNonLeafNode : Splits a non-leaf node into two and inserts the middle key into the parent node.
 * The function redistributes keys and pointers, adjusts the node structure, and handles splitting the parent node if needed.
 *
 * @param currentNode The non-leaf node to be split.
 * @param managementData B-tree management data, including metadata like the total entries.
 */
void splitNonLeafNode(BTreeNode *currentNode, BTreeMtdt *managementData)
{
    //Creating a new non-leaf sibling node
    BTreeNode *newNode = createNonLeafNode(managementData);
    
    //Calculating the middle index to split the node
    int middleIdx = currentNode->keyNums / 2;
    
    //Copy the middle key, which will be pushed up to the parent node
    Value *keyToMoveUp = copyKey(currentNode->keys[middleIdx]);

    int siblingIdx = 0;
    
    //Begin redistributing keys and pointers to the new sibling node, starting from the element after the middle
    int i = middleIdx + 1;
    while(i < currentNode->keyNums)
    {
        newNode->keys[siblingIdx] = currentNode->keys[i];
        newNode->ptrs[siblingIdx + 1] = currentNode->ptrs[i + 1];
        currentNode->keys[i] = NULL;
        currentNode->ptrs[i + 1] = NULL;
        
        newNode->keyNums += 1;
        currentNode->keyNums -= 1;
        
        siblingIdx += 1;
        i++;
    }

    //The first pointer of the new sibling node now points to the subtree after the middle key
    newNode->ptrs[0] = currentNode->ptrs[middleIdx + 1];
    currentNode->ptrs[middleIdx + 1] = NULL;
    
    //Adjust key count in current node and clear the middle key
    currentNode->keyNums -= 1; 
    currentNode->keys[middleIdx] = NULL;

    //Setting the parent of the new sibling node to be the same as the current node's parent
    newNode->parent = currentNode->parent;
    
    //Linking the sibling with the original node
    currentNode->next = newNode;

    //Inserting the middle key into the parent node, which could cause the parent to split if it becomes too full
    insertIntoParentNode(currentNode, keyToMoveUp, managementData);
}

/**
 * Function insertIntoParentNode: Handles the insertion of a new key into the parent node after a split.
 * If the parent node is full after the insertion, it triggers a split and pushes the middle key up.
 *
 * @param leftNode The left child node that was split.
 * @param key The new key to insert into the parent node.
 * @param managementData B-tree management data, including metadata like the root and max number of keys.
 */
void insertIntoParentNode(BTreeNode *leftNode, Value *key, BTreeMtdt *managementData)
{
    //Getting the sibling node created after splitting leftNode
    BTreeNode *rightChildNode = leftNode->next;
    
    //Getting the parent node of leftNode
    BTreeNode *parentNode = leftNode->parent;
    
    //If the parent doesn't exist, create a new root node as the original root was split
    if(parentNode == NULL)
    {
        //Creating a new non-leaf node to serve as the new root
        parentNode = createNonLeafNode(managementData);
        managementData->root = leftNode->parent = rightChildNode->parent = parentNode;
        
        //Setting the first child of the new root to be the leftNode
        parentNode->ptrs[0] = leftNode;
    }

    //Determining the correct position for the new key in the parent node
    int positionToInsert = getInsertPos(parentNode, key);

    //Shifting existing keys and pointers in the parent node to make space for the new key
    int index = parentNode->keyNums;
    while (index > positionToInsert)
    {
        //Shifting keys to the right
        parentNode->keys[index] = parentNode->keys[index - 1];  
        
        //Shifting pointers to the right
        parentNode->ptrs[index + 1] = parentNode->ptrs[index];  
        index--;
    }

    //Inserting the new key and pointer in the parent node
    parentNode->keys[positionToInsert] = key;
    parentNode->ptrs[positionToInsert + 1] = rightChildNode;
    
    //Incrementing the key count in the parent node
    parentNode->keyNums += 1;

    //If the parent node exceeds the maximum number of keys allowed, split it
    if (parentNode->keyNums > managementData->n)
    {
        splitNonLeafNode(parentNode, managementData);
    }
}

/**
 * Function copyKey : Copies the given key into a new memory location.
 *
 * @param key The key to copy.
 * @return A new Value object that is a copy of the original key.
 */
Value *copyKey(Value *originalKey)
{
    //Allocating memory for a new Value object
    Value *copiedKey = (Value *)malloc(sizeof(Value));
    
    //Copying the content of the original key into the newly allocated space
    memcpy(copiedKey, originalKey, sizeof(*copiedKey));
    
    //Returning the new copied key
    return copiedKey;
}

/**
 * Function insertKey : Inserts a new key into the B-Tree and handles node splits if necessary.
 *
 * @param treeHandle Pointer to the B-Tree handle containing the metadata and the tree.
 * @param newKey The key to be inserted into the B-Tree.
 * @param recordID The RID associated with the new key.
 *
 * This function inserts a new key into the appropriate leaf node of the B-Tree.
 * If the key already exists, the function returns an error. If the leaf node
 * does not have space for the new key, it splits into two nodes. The middle key
 * of the split node is pushed up to the parent, which may cause further splits 
 * if the parent node exceeds its maximum capacity.
 *
 * @return RC_OK if the insertion is successful, RC_IM_KEY_ALREADY_EXISTS if the key already exists,
 *         or another error code if an issue arises during insertion.
 */
RC insertKey(BTreeHandle *treeHandle, Value *newKey, RID recordID)
{
    BTreeMtdt *btreeMgmtData = (BTreeMtdt *)treeHandle->mgmtData;
    
    //If the root is NULL, create a new leaf node
    if(btreeMgmtData->root == NULL)
    {
        btreeMgmtData->root = createLeafNode(btreeMgmtData);
    }

    //Locating the appropriate leaf node for the new key
    BTreeNode *leaf = findLeafNode(btreeMgmtData->root, newKey);

    //Checking if the key already exists in the B-tree
    if(findEntryInNode(leaf, newKey))
    {
        return RC_IM_KEY_ALREADY_EXISTS;
    }

    //Inserting the new key into the leaf node in sorted order
    insertIntoLeafNode(leaf, newKey, &recordID, btreeMgmtData);

    //If the leaf node has sufficient space, the operation is complete
    if (leaf->keyNums <= btreeMgmtData->n)
    {
        return RC_OK;
    }

    //Otherwise, split the leaf node into two nodes
    BTreeNode *rightSibling = splitLeafNode(leaf, btreeMgmtData);

    //Redistributing the entries evenly and push the middle key up to the parent
    Value *middleKey = copyKey(rightSibling->keys[0]);

    //Inserting an index entry pointing to the new leaf node into the parent of the original leaf node
    insertIntoParentNode(leaf, middleKey, btreeMgmtData);

    return RC_OK;
}

/**
 * Function deleteFromLeafNode : Removes a key from a leaf node in the B-Tree.
 *
 * @param currentNode Pointer to the leaf node where the key is to be deleted.
 * @param keyToRemove The key to be removed from the leaf node.
 * @param managementData Pointer to the B-Tree metadata containing management information.
 *
 * This function removes a key from a leaf node and shifts the remaining keys and pointers
 * to the left to maintain the structure of the node. After removing the key, the total number
 * of entries in the B-tree is updated. If the node has fewer keys than the minimum allowed,
 * an underflow condition will be triggered, and additional operations like redistribution or
 * merging might be required (this function does not handle such cases).
 *
 * @return None. This function modifies the B-tree node in-place.
 */
void deleteFromLeafNode(BTreeNode *currentNode, Value *keyToRemove, BTreeMtdt *managementData)
{
    //Finding the position of the key to be removed
    int deletePos = getInsertPos(currentNode, keyToRemove);

    // Shifting all keys and pointers to the left to fill the gap created by the removed key
    int shiftIdx = deletePos;
    while(shiftIdx < currentNode->keyNums)
    {
        //Shifting keys to the left
        currentNode->keys[shiftIdx] = currentNode->keys[shiftIdx + 1]; 

        //Shifting pointers to the left
        currentNode->ptrs[shiftIdx] = currentNode->ptrs[shiftIdx + 1]; 
        shiftIdx++;
    }

    //Decreasing the key count in the current node
    currentNode->keyNums -= 1;

    //Decreasing the total entries in the B-tree
    managementData->entries -= 1;
}

/**
 * Function isEnoughSpace : Checks whether a B-tree node has sufficient space for key insertion.
 *
 * @param keyCount The current number of keys in the node.
 * @param currentNode Pointer to the node being checked for available space.
 * @param managementData Pointer to the B-tree's metadata containing tree-specific parameters.
 *
 * This function determines if a node, either leaf or non-leaf, has enough space to accommodate
 * an additional key. It compares the current number of keys in the node with the minimum and 
 * maximum allowed for the node type. The function returns true if there is enough space and 
 * false if the node is overfilled or has too few keys.
 *
 * @return True if the node has enough space, false otherwise.
 */
bool isEnoughSpace(int keyCount, BTreeNode *currentNode, BTreeMtdt *managementData)
{
    int minRequiredKeys = currentNode->type == LEAF_NODE ? managementData->minLeaf : managementData->minNonLeaf;

    //The node must have at least the minimum required keys and at most the maximum allowed keys
    if(currentNode->type == LEAF_NODE)
    {
        //Checking if the current number of keys is within the acceptable range for a leaf node
        if(keyCount >= minRequiredKeys && keyCount <= managementData->n)
        {
            //Leaf node has sufficient space
            return true;
        }
    }
    else
    {
        //Checking if the current number of keys is within the acceptable range for a non-leaf node
        if(keyCount >= minRequiredKeys && keyCount <= managementData->n)
        {
            //Non-leaf node has sufficient space
            return true;
        }
    }
    
    //The node does not have enough space or is overfilled
    return false;
}

/**
 * Function deleteParentEntry : Removes the entry (key and pointer) associated with a target node
 * from its parent node in a B-tree.
 *
 * @param targetNode Pointer to the B-tree node whose entry will be deleted from its parent.
 *
 * This function locates the entry corresponding to the target node in its parent, removes
 * the key and pointer, and shifts the remaining entries in the parent node to close the gap.
 * It ensures that the parent node’s structure remains consistent after the removal.
 *
 * @return Void, the parent node is modified directly.
 */
void deleteParentEntry(BTreeNode *targetNode)
{
    //Getting the parent node of the target node from which the entry will be deleted
    BTreeNode *parentNode = targetNode->parent;

    //Looping through the parent's pointers to locate the pointer referring to 'targetNode'
    int indexInParent = 0;
    while(indexInParent <= parentNode->keyNums)
    {
        if(parentNode->ptrs[indexInParent] == targetNode)
        {
            //Calculating the index of the key associated with 'targetNode'
            int keyIndex = (indexInParent - 1 < 0) ? 0 : indexInParent - 1;

            //Setting the key at keyIndex to NULL
            parentNode->keys[keyIndex] = NULL;

            //Setting the pointer at indexInParent to NULL
            parentNode->ptrs[indexInParent] = NULL;

            //Shifting subsequent keys and pointers to the left to close the gap
            int keyShift = keyIndex;
            while(keyShift < parentNode->keyNums - 1)
            {
                parentNode->keys[keyShift] = parentNode->keys[keyShift + 1];
                keyShift++;
            }

            int ptrShift = indexInParent;
            while(ptrShift < parentNode->keyNums)
            {
                parentNode->ptrs[ptrShift] = parentNode->ptrs[ptrShift + 1];
                ptrShift++;
            }

            //Decreasing the key count in the parent node
            parentNode->keyNums -= 1;
            break;
        }
        indexInParent++;
    }
}

/**
 * Function updateParentEntry : Updates a key in the parent node of a B-tree.
 *
 * @param currentNode Pointer to the current node where the key update originates.
 * @param oldKey The original key to be replaced in the parent node.
 * @param updatedKey The new key that will replace the old key in the parent node.
 *
 * This function attempts to update a key in the parent node by first removing the old key, 
 * and then inserting the updated key in the correct position. If the old key is not found 
 * in the parent node, the update is not performed. It ensures the parent's structure remains 
 * valid by shifting keys as needed.
 *
 * @return Void, the parent node is modified directly.
 */
void updateParentEntry(BTreeNode *currentNode, Value *oldKey, Value *updatedKey)
{
    //If the old key is the same as the new key, no update is required
    if(compareValue(oldKey, updatedKey) == 0)
    {
        return;
    }

    //Flag to indicate if the original key was found and removed
    bool wasKeyDeleted = false; 

    //Accessing the parent node of the current node
    BTreeNode *parentNode = currentNode->parent; 

    //Attempting to locate and remove the old key from the parent node
    int indexInParent = 0;
    while(indexInParent < parentNode->keyNums)
    {
        //Checking if the current key matches the old key
        if (compareValue(oldKey, parentNode->keys[indexInParent]) == 0) 
        {
            //Shifting all subsequent keys to the left to fill the gap created by the deleted key
            int keyShiftIndex = indexInParent;
            while(keyShiftIndex < parentNode->keyNums - 1)
            {
                parentNode->keys[keyShiftIndex] = parentNode->keys[keyShiftIndex + 1];
                keyShiftIndex++;
            }

            //Setting the last key position to NULL after the shift
            parentNode->keys[parentNode->keyNums - 1] = NULL; 

            //Decrementing the key count in the parent node
            parentNode->keyNums -= 1; 

            //Setting the flag to indicate the key was deleted
            wasKeyDeleted = true; 
            break;
        }
        indexInParent++;
    }

    //If the old key was not found, exit the function without adding the new key
    if(!wasKeyDeleted)
    {
        return;
    }

    //Determining the correct position to insert the new key
    int insertPosition = getInsertPos(parentNode, updatedKey); // Find the position where the new key should be inserted

    //Shifting all subsequent keys to the right to make space for the new key
    int shiftIndex = parentNode->keyNums;
    while (shiftIndex >= insertPosition)
    {
        parentNode->keys[shiftIndex] = parentNode->keys[shiftIndex - 1];
        shiftIndex--;
    }

    //Inserting the new key at the determined position
    parentNode->keys[insertPosition] = updatedKey;

    //Incrementing the parent node's key count
    parentNode->keyNums += 1; 
}

/**
 * Function redistributeFromSibling : Attempts to redistribute entries from a sibling node to
 * an underfilled target node in a B-tree.
 *
 * @param targetNode Pointer to the node that is underfilled and needs redistribution.
 * @param key The key currently in the parent node, used to update the parent after redistribution.
 * @param treeData Pointer to the tree's management data structure that contains tree parameters.
 *
 * This function checks both the left and right siblings of the target node. If any sibling has
 * enough space, a key is moved from the sibling to the target node, and the parent node is updated
 * accordingly. If redistribution is not possible, the function returns false.
 *
 * @return true if redistribution was successful, false otherwise.
 */
bool redistributeFromSibling(BTreeNode *targetNode, Value *key, BTreeMtdt *treeData)
{
    //Accessing the parent node of the current underfilled node
    BTreeNode *parentNode = targetNode->parent;
    BTreeNode *neighborSibling = NULL;
    int keyIndexInSibling = 0;

    //Traversing the parent's pointers to locate the current node and identify potential siblings
    int indexInParent = 0;
    while(indexInParent <= parentNode->keyNums)
    {
        if(parentNode->ptrs[indexInParent] != targetNode)
        {
            indexInParent++;
            continue;
        }
        
        //Attempting redistribution from the left sibling if possible
        //Ensuring left sibling exists
        if(indexInParent - 1 >= 0)  
        {
            neighborSibling = (BTreeNode *)parentNode->ptrs[indexInParent - 1];
            if(neighborSibling && isEnoughSpace(neighborSibling->keyNums - 1, neighborSibling, treeData))
            {
                //Indexing of the last key in the left sibling
                keyIndexInSibling = neighborSibling->keyNums - 1;  
                break;
            }
        }

        //If no redistribution from the left sibling, check the right sibling
        //Ensuring right sibling exists
        if(indexInParent + 1 <= parentNode->keyNums + 1)  
        {
            neighborSibling = (BTreeNode *)parentNode->ptrs[indexInParent + 1];
            if(neighborSibling && isEnoughSpace(neighborSibling->keyNums - 1, neighborSibling, treeData))
            {
                //Indexing of the first key in the right sibling
                keyIndexInSibling = 0;  
                break;
            }
        }
        
        //Reseting neighborSibling if no suitable sibling is found
        neighborSibling = NULL;  
        break;
    }

    if(neighborSibling)
    {
        //Inserting the key from the sibling into the target node
        insertIntoLeafNode(targetNode, copyKey(neighborSibling->keys[keyIndexInSibling]), neighborSibling->ptrs[keyIndexInSibling], treeData);
        
        //Updating the parent node's key pointing to the target node after redistribution
        updateParentEntry(targetNode, key, copyKey(neighborSibling->keys[keyIndexInSibling]));
        
        //Adjusting the sibling node by removing the redistributed key
        neighborSibling->keyNums -= 1;

        //Freeing the key that was moved
        free(neighborSibling->keys[keyIndexInSibling]);  

        //Freeing the pointer associated with the key
        free(neighborSibling->ptrs[keyIndexInSibling + 1]);  
        
        neighborSibling->keys[keyIndexInSibling] = NULL;
        neighborSibling->ptrs[keyIndexInSibling + 1] = NULL;
        
        return true;
    }
    
    //Redistribution was unsuccessful
    return false;
}

/**
 * Function checkSiblingCapacity : Checks if a sibling of the current node can accommodate 
 * additional keys in the B-tree, and determines if merging is possible.
 *
 * @param currentNode Pointer to the current node for which sibling capacity is being checked.
 * @param treeData Pointer to the B-tree management data containing tree parameters.
 *
 * This function checks both left and right siblings of the current node. It determines if either
 * sibling has enough capacity to merge with the current node, considering the total number of keys
 * and the allowed limits of the nodes. If a suitable sibling is found, it is returned; otherwise, NULL is returned.
 *
 * @return A pointer to the sibling node if merging is possible, NULL otherwise.
 */
BTreeNode *checkSiblingCapacity(BTreeNode *currentNode, BTreeMtdt *treeData)
{
    //Initializing the sibling pointer to NULL
    BTreeNode *neighborSibling = NULL;
    
    //Obtaining the parent of the current node
    BTreeNode *parentNode = currentNode->parent;
    int parentIndex = 0;

    //Traversing the parent's pointers to locate the current node and identify potential siblings
    while(parentIndex <= parentNode->keyNums)
    {
        //Skip if the pointer does not point to the current node
        if(parentNode->ptrs[parentIndex] != currentNode) 
        {
            parentIndex++;
            continue;
        }

        //Checking if a left sibling exists by verifying if index-1 is a valid position
        if(parentIndex - 1 >= 0)
        {
            //Preferring the left sibling
            neighborSibling = (BTreeNode *)parentNode->ptrs[parentIndex - 1];
            
            //Determining if merging the current node and left sibling fits within node capacity
            if(isEnoughSpace(neighborSibling->keyNums + currentNode->keyNums, neighborSibling, treeData))
            {
                break;
            }
        }

        //Checking if a right sibling exists by verifying if index+1 is within bounds
        if(parentIndex + 1 <= parentNode->keyNums + 1)
        {
            //Assigning right sibling
            neighborSibling = (BTreeNode *)parentNode->ptrs[parentIndex + 1]; 
            
            //Determining if merging the current node and right sibling fits within node capacity
            if(isEnoughSpace(neighborSibling->keyNums + currentNode->keyNums, neighborSibling, treeData))
            {
                break;
            }
        }

        //Resetting neighborSibling to NULL if no suitable sibling was found
        neighborSibling = NULL;
        break;
    }

    //Returning the identified sibling, if any
    return neighborSibling;
}

/**
 * Function mergeSibling : Merges a primary node with its adjacent sibling, maintaining sorted order.
 * Updates the parent node and B-tree structure after the merge.
 *
 * @param primaryNode Pointer to the primary node that will be merged with the adjacent sibling.
 * @param adjacentNode Pointer to the adjacent sibling node.
 * @param treeData Pointer to the B-tree management data containing tree parameters.
 *
 * This function merges the primary node with its adjacent sibling. It integrates the keys and pointers
 * from both nodes while maintaining sorted order. After the merge, it updates the parent node, reduces
 * the total node count, and frees the resources held by the primary node. If the adjacent node does not
 * meet the minimum key requirements, additional recursive merging may occur.
 *
 * @return void
 */
void mergeSibling(BTreeNode *primaryNode, BTreeNode *adjacentNode, BTreeMtdt *treeData)
{
    //Calculating the total number of keys after merging the primary node with the sibling
    int combinedKeys = adjacentNode->keyNums + primaryNode->keyNums;
    
    if(combinedKeys > adjacentNode->keyNums)
    {
        int leftIndex = 0, rightIndex = 0, mergeIndex = 0;

        //Allocating memory for new arrays to store keys and pointers for both nodes after merging
        Value **mergedKeys = malloc(combinedKeys * sizeof(Value *));
        void **mergedPtrs = malloc((combinedKeys + 1) * sizeof(void *));

        //Integrating keys and pointers from both nodes into the new arrays while maintaining sorted order
        while(mergeIndex < combinedKeys)
        {
            if(rightIndex >= primaryNode->keyNums || compareValue(adjacentNode->keys[leftIndex], primaryNode->keys[rightIndex]) <= 0)
            {
                mergedKeys[mergeIndex] = adjacentNode->keys[leftIndex];
                mergedPtrs[mergeIndex] = adjacentNode->ptrs[leftIndex];
                leftIndex++;
            }
            else
            {
                mergedKeys[mergeIndex] = primaryNode->keys[rightIndex];
                mergedPtrs[mergeIndex] = primaryNode->ptrs[rightIndex];
                rightIndex++;
            }
            mergeIndex++;
        }

        //Updating the adjacent node with the merged keys and pointers
        free(adjacentNode->keys);
        free(adjacentNode->ptrs);
        adjacentNode->keys = mergedKeys;
        adjacentNode->ptrs = mergedPtrs;
    }

    //Updating the parent node to reflect the removal of the merged node
    deleteParentEntry(primaryNode);

    //Reducing the total node count in the B-tree
    treeData->nodes--;

    //Releasing resources held by the primary node, as it is now merged with the adjacent node
    free(primaryNode->ptrs);
    free(primaryNode->keys);
    free(primaryNode);

    //Checking if the adjacent node needs further merging based on minimum key requirements
    if (adjacentNode->keyNums < treeData->minNonLeaf)
    {
        //Additional recursive merging logic 
    }
}

/**
 * Function deleteKey : Deletes a key from the B-tree and handles the necessary adjustments to maintain tree balance.
 *
 * @param btreeHandle Pointer to the B-tree handle that provides access to the tree data.
 * @param targetKey Pointer to the key to be deleted from the B-tree.
 *
 * This function locates the appropriate leaf node containing the target key. If the key is found, it removes
 * the key from the leaf node. After the removal, it checks if the leaf node has enough keys to remain valid.
 * If necessary, the function attempts to redistribute keys with a sibling or merges the leaf node with a sibling.
 * The parent node is updated accordingly after the operation to maintain the integrity of the tree.
 *
 * @return RC_OK if the key was successfully deleted, RC_IM_KEY_NOT_FOUND if the key was not found.
 */
RC deleteKey(BTreeHandle *btreeHandle, Value *targetKey)
{
    //Retrieving the B-tree metadata from the handle
    BTreeMtdt *btreeData = (BTreeMtdt *)btreeHandle->mgmtData;

    //Locating the leaf node that contains the target key
    BTreeNode *leafNodeContainingKey = findLeafNode(btreeData->root, targetKey);

    //If the key is not found in the node, return an error
    if(findEntryInNode(leafNodeContainingKey, targetKey) == NULL)
    {
        return RC_IM_KEY_NOT_FOUND;
    }

    //Removing the target key from the leaf node
    deleteFromLeafNode(leafNodeContainingKey, targetKey, btreeData);

    //Checking if the leaf node has enough keys to remain valid
    if(leafNodeContainingKey->keyNums >= btreeData->minLeaf)
    {
        //If the leaf node has enough keys, update the parent node and return success
        Value *replacementKey = copyKey(leafNodeContainingKey->keys[0]);
        updateParentEntry(leafNodeContainingKey, targetKey, replacementKey);
        return RC_OK;
    }

    //If the leaf node is underfull, attempt redistribution or merging with a sibling
    BTreeNode *adjacentSibling = checkSiblingCapacity(leafNodeContainingKey, btreeData);

    //If redistribution is not possible, merge with a sibling
    if(adjacentSibling)
    {
        mergeSibling(leafNodeContainingKey, adjacentSibling, btreeData);
    }
    else
    {
        //Otherwise, redistribute keys from the sibling node
        redistributeFromSibling(leafNodeContainingKey, targetKey, btreeData);
    }

    //Returning success after deletion and balancing
    return RC_OK;
}

/**
 * Function openTreeScan : Initiates a scan operation on the B-tree to allow traversal over the tree's keys.
 *
 * @param btreeHandle Pointer to the B-tree handle that contains the tree data and management metadata.
 * @param scanHandle Pointer to a variable that will hold the scan handle for managing the scan process.
 *
 * This function opens a scan on the B-tree, starting from the leftmost leaf node (node with the smallest key).
 * The scan will begin at the leftmost position in the tree, and the scan handle will track the current position.
 * If the B-tree is empty, an error is returned.
 *
 * @return RC_OK if the scan was successfully initiated, RC_IM_KEY_NOT_FOUND if the tree is empty.
 */
RC openTreeScan(BTreeHandle *btreeHandle, BT_ScanHandle **scanHandle)
{
    //Accessing the management data for the B-tree
    BTreeMtdt *btreeData = (BTreeMtdt *)btreeHandle->mgmtData;
    
    //Starting at the root node of the B-tree
    BTreeNode *currentNode = (BTreeNode *)btreeData->root;

    //If the tree is empty, return an error
    if(currentNode == NULL)
    {
        return RC_IM_KEY_NOT_FOUND;
    }

    //Traversing down to the leftmost leaf node (node with the smallest key)
    while(currentNode->type == INNER_NODE)
    {
        //Moving to the first child node in the inner node
        currentNode = currentNode->ptrs[0];
    }

    //Allocating memory for the scan metadata, which will store information about the current scan position
    BT_ScanMtdt *scanData = (BT_ScanMtdt *)malloc(sizeof(BT_ScanMtdt));
    
    //Allocating memory for the scan handle, which is used externally to manage the scan
    (*scanHandle) = malloc(sizeof(BT_ScanHandle));
    
    //Initializing the scan metadata, setting the leftmost leaf node as the starting point and key index to 0
    scanData->keyIndex = 0;
    scanData->node = currentNode;

    //Assigning the scan metadata to the scan handle
    (*scanHandle)->mgmtData = scanData;

    //Returning success indicating the scan was successfully opened
    return RC_OK;
}

/**
 * Function nextEntry : Retrieves the next entry (key-value pair) in the B-tree scan.
 *
 * @param scanHandle The handle for the current scan operation.
 * @param output Pointer to an RID structure to store the record ID of the found entry.
 *
 * This function advances the scan to the next key in the current node. If the current node is exhausted,
 * it moves to the next node in the B-tree. If there are no more nodes or entries, it returns an appropriate status.
 *
 * @return RC_OK if a key is found and returned, RC_IM_NO_MORE_ENTRIES if there are no more entries to scan.
 */
RC nextEntry(BT_ScanHandle *scanHandle, RID *output)
{
    //Retrieving the scan metadata, which contains the current position and state of the scan
    BT_ScanMtdt *scanData = (BT_ScanMtdt *)scanHandle->mgmtData;
    
    //Retrieving the current node and key index being processed in the scan
    BTreeNode *currentNode = scanData->node;
    int currentKeyIndex = scanData->keyIndex;

    //Checking if there are more keys in the current node
    if(currentKeyIndex < currentNode->keyNums)
    {
        //If there are more keys, get the current key's RID (record ID)
        RID *recordID = buildRID((RID *)currentNode->ptrs[currentKeyIndex]);
        
        //Moving to the next key in the current node
        scanData->keyIndex += 1;

        //Assigning the found RID to the output parameter
        (*output) = (*recordID);
        return RC_OK;
    }
    else
    {
        //If the current node is exhausted, check if there is a next node
        if(currentNode->next == NULL)
        {
            //If there are no more nodes, indicate that the scan has finished
            return RC_IM_NO_MORE_ENTRIES;
        }

        //Resetting the key index and move to the next node
        scanData->keyIndex = 0;
        scanData->node = currentNode->next;

        //Recursively call nextEntry to continue scanning from the next node
        return nextEntry(scanHandle, output);
    }
}

/**
 * Function closeTreeScan : Closes a B-tree scan and frees all associated memory.
 *
 * @param scanHandle The handle for the scan operation to be closed.
 *
 * This function releases the memory allocated for the scan metadata and the scan handle itself.
 * After this function is called, the scan handle is no longer valid.
 *
 * @return RC_OK on successful closure and memory release.
 */
RC closeTreeScan(BT_ScanHandle *scanHandle)
{
    //Checking if the scan handle is not NULL before proceeding to avoid dereferencing invalid pointers
    if(scanHandle != NULL)
    {
        //Freeing the memory allocated for the scan metadata (management data associated with the scan)
        free(scanHandle->mgmtData);

        //Freeing the memory allocated for the scan handle itself
        free(scanHandle);
    }

    //Returning RC_OK to indicate successful closure of the scan
    return RC_OK;
}

/**
 * Function displayBTree : Displays the structure of a B-Tree by traversing its nodes.
 *
 * @param btreeHandle Pointer to the B-Tree handle containing metadata for the tree.
 *
 * This function performs a breadth-first traversal of the B-Tree, displaying each node's
 * keys and corresponding child nodes. The B-Tree is traversed level by level, starting from
 * the root node and moving downwards. For leaf nodes, the Record IDs (RIDs) are displayed,
 * while for internal nodes, pointers to child nodes are shown. The tree structure is printed
 * in a format that highlights the hierarchy of the nodes.
 *
 * The function allocates memory for a queue to manage nodes as they are processed, and
 * it ensures that the output string representation of the tree is returned for external use.
 *
 * @return A string containing the hierarchical structure of the B-Tree. If the B-Tree is empty,
 *         NULL is returned. The returned string is dynamically allocated and should be freed
 *         by the caller when no longer needed.
 */
char *displayBTree(BTreeHandle *btreeHandle)
{
    //Getting the B-tree management structure
    BTreeMtdt *treeMetadata = (BTreeMtdt *)btreeHandle->mgmtData;
    
    //Retrieving the root node of the B-tree
    BTreeNode *rootNode = treeMetadata->root;
    
    //Checking if the B-tree is empty
    if(rootNode == NULL)
    {
        return NULL;
    }
    
    //Allocating memory for the queue to handle nodes for display
    BTreeNode **nodeQueue = malloc((treeMetadata->nodes) * sizeof(BTreeNode *));
    
    //Allocating a buffer to store the output string
    //Initial size, it can be increased if needed
    size_t bufferSize = 1024;  
    char *outputString = malloc(bufferSize * sizeof(char));
    size_t currentLength = 0;

    //Current level of the tree
    int level = 0;   

    //Track processed nodes count
    int processedNodeCount = 1; 

    //Index of the current node in the queue
    int nodeIndex = 0;    

    //Initializing the queue with the root node
    nodeQueue[0] = rootNode;

    //Processing each node in the queue until all nodes are handled
    while(nodeIndex < processedNodeCount)
    {
        BTreeNode *currentNode = nodeQueue[nodeIndex];
        
        //Ensuring there's enough space in the output buffer
        currentLength += snprintf(outputString + currentLength, bufferSize - currentLength, "(%i)[", level);

        //Initializing key index for while loop
        int keyIndex = 0; 

        //Looping over keys within the current node
        while(keyIndex < currentNode->keyNums)
        {
            //If it's a leaf node, display the Record IDs (RIDs)
            if(currentNode->type == LEAF_NODE)
            {
                RID *recordID = (RID *)currentNode->ptrs[keyIndex];
                currentLength += snprintf(outputString + currentLength, bufferSize - currentLength, "%i.%i,", recordID->page, recordID->slot);
            }
            else
            {
                //For non-leaf nodes, print child node indices and enqueue the children
                currentLength += snprintf(outputString + currentLength, bufferSize - currentLength, "%i,", processedNodeCount);
                nodeQueue[processedNodeCount] = (BTreeNode *)currentNode->ptrs[keyIndex];
                processedNodeCount += 1;
            }

            //Serializing key value based on node type and key index
            if(currentNode->type == LEAF_NODE && keyIndex == currentNode->keyNums - 1)
            {
                currentLength += snprintf(outputString + currentLength, bufferSize - currentLength, "%s", serializeValue(currentNode->keys[keyIndex]));
            }
            else
            {
                currentLength += snprintf(outputString + currentLength, bufferSize - currentLength, "%s,", serializeValue(currentNode->keys[keyIndex]));
            }
            keyIndex++;
        }

        //For inner nodes, also enqueue the pointer following the last key
        if(currentNode->type == INNER_NODE)
        {
            currentLength += snprintf(outputString + currentLength, bufferSize - currentLength, "%i", processedNodeCount);
            nodeQueue[processedNodeCount] = (BTreeNode *)currentNode->ptrs[currentNode->keyNums];
            processedNodeCount += 1;
        }

        //Moving to the next level of nodes in the tree
        level += 1;

        //Moving to the next node in the queue
        nodeIndex += 1; 
        
        //Closing bracket for the current node's level
        currentLength += snprintf(outputString + currentLength, bufferSize - currentLength, "]\n"); 
    }

    //Null-terminate the output string
    outputString[currentLength] = '\0';

    //Releasing memory used for the node queue
    free(nodeQueue);
    
    return outputString;
}

