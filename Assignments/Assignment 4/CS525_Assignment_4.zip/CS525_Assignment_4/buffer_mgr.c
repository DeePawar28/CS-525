//Include the required libraries
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "buffer_mgr.h"
#include "buffer_mgr_stat.h"
#include "dberror.h"
#include "storage_mgr.h"
#include "dt.h"
#include "replacement_strat.h"

/**
 * Function initBufferPool: Initializes the buffer pool structure for managing pages in memory.
 *
 * @param bm Pointer to the Buffer Pool to be initialized.
 * @param pageFileName Name of the page file associated with the buffer pool.
 * @param numPages Number of page frames to be maintained in memory.
 * @param strategy Page replacement strategy to use (FIFO, LRU, etc.).
 * @param stratData Optional parameter for strategy-specific data (not used in this function).
 *
 * This function prepares the buffer pool to manage a given number of pages using the specified
 * replacement strategy. It allocates memory for internal structures, sets up metadata for tracking
 * frames, and handles errors during allocation gracefully to ensure proper cleanup.
 *
 * @return RC_OK on successful initialization, otherwise an error code describing the failure.
 */
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, const int numPages, ReplacementStrategy strategy, void *stratData) 
{
	//Validating that the number of pages is a positive number
	if(numPages <= 0) 
	{
		return RC_INVALID_NUMPAGES;
	}

	//Ensuring the replacement strategy is within the defined bounds
	if(strategy < 0 || strategy > 4) 
	{
		return RC_INVALID_STRATEGY;
	}

	//Ensuring the buffer pool pointer is not NULL
	if(bm == NULL) 
	{
		return RC_INVALID_BM;
	}

	//Ensuring the page file name is valid
	if(pageFileName == NULL) 
	{
		return RC_INVALID_PAGE_FILE_NAME;
	}

	//Allocating memory for the management structure that tracks internal buffer pool state
	BufferPoolMgmt *bpMgr = (BufferPoolMgmt *)malloc(sizeof(BufferPoolMgmt));
	
	if(bpMgr == NULL) 
	{
		return RC_BUFFER_POOL_INIT_FAILED;
	}

	//Allocating memory to store all frames (pages in memory)
	bpMgr->frames = (Frame *)malloc(sizeof(Frame) * numPages);
	
	if(bpMgr->frames == NULL) 
	{
		//Freeing previously allocated structure and return error
		free(bpMgr);
		return RC_BUFFER_POOL_INIT_FAILED;
	}

	//Initializing each frame in the buffer pool
	for(int i = 0; i < numPages; i++) 
	{
		//Allocating a block of PAGE_SIZE bytes for each frame's data
		bpMgr->frames[i].data = (char *)malloc(PAGE_SIZE);

		//If data allocation fails for any frame, clean up and return error
		if(bpMgr->frames[i].data == NULL) 
		{
			while (--i >= 0) 
			{
				//Freeing previously allocated frame data
  				free(bpMgr->frames[i].data);  
			}

			//Freeing frame array
			free(bpMgr->frames);  

			//Freeing buffer manager
			free(bpMgr);          

			printf("Error Occurred : Frame data NULL & Memory allocation failed\n");
			return RC_BUFFER_POOL_INIT_FAILED;
		}

		//Initializing the data block with zeros
		memset(bpMgr->frames[i].data, 0, PAGE_SIZE);

		//Initializing frame metadata
		//No page loaded initially
		bpMgr->frames[i].pageNum = NO_PAGE;   

		//Frame not dirty initially
		bpMgr->frames[i].isDirty = false;     

		//No pins on the frame yet
		bpMgr->frames[i].fixCount = 0;        
	}

	//Setting up a circular doubly-linked list for the frames
	for(int i = 0; i < numPages; i++) 
	{
		//Linking to next
		bpMgr->frames[i].next = &bpMgr->frames[(i + 1) % numPages];    
		
		//Linking to previous
		bpMgr->frames[i].prev = &bpMgr->frames[(i - 1 + numPages) % numPages]; 
	}

	//Initializing counters that track I/O operations
	//No read operations yet
	bpMgr->numReadIO = 0;   

	//No write operations yet
	bpMgr->numWriteIO = 0;  

	//If FIFO or LRU strategy is selected, initialize a queue for managing frame order
	if(strategy == RS_FIFO || strategy == RS_LRU) 
	{
		Queue *queue = (Queue *)malloc(sizeof(Queue));
		if (queue == NULL) 
		{
			//On failure, clean up all previously allocated memory
			for (int i = 0; i < numPages; i++) 
			{
  				free(bpMgr->frames[i].data);
			}
			free(bpMgr->frames);
			free(bpMgr);
			printf("Error Occurred : Memory allocation is failed.\n");
			return RC_BUFFER_POOL_INIT_FAILED;
		}	

		//Setting up queue to track head and tail of the frame list
		bpMgr->queue = queue;

		//First frame as head
		bpMgr->queue->head = &bpMgr->frames[0];
		
		//Last frame as tail
		bpMgr->queue->tail = &bpMgr->frames[numPages - 1];     

		//Total number of frames
		bpMgr->queue->count = numPages;                        
	} 

	else 
	{
		//If strategy does not require a queue, set it to NULL
		bpMgr->queue = NULL;
	}

	//Storing a copy of the page file name in the buffer pool structure
	bm->pageFile = strdup(pageFileName);
	if (bm->pageFile == NULL) 
	{
		//On failure, clean up everything including the queue if it was created
		if (bpMgr->queue != NULL) 
		{
			free(bpMgr->queue);
		}
		for (int i = 0; i < numPages; i++) 
		{
			free(bpMgr->frames[i].data);
		}
		free(bpMgr->frames);
		free(bpMgr);
		printf("Error Occurred : Memory allocation failed & Page file NULL.\n");
		return RC_BUFFER_POOL_INIT_FAILED;
	}

	//Storing total number of pages and chosen replacement strategy
	bm->numPages = numPages;
	bm->strategy = strategy;

	//Linking the buffer manager metadata to the buffer pool
	bm->mgmtData = bpMgr;

	//Initialization successful
	return RC_OK;
}

/**
 * Function checkPinnedPages: Checks if any pages in the buffer pool are still pinned.
 *
 * @param bm Pointer to the buffer pool whose frames are to be checked.
 *
 * This function scans all the frames in the buffer pool to verify whether any of them
 * have a non-zero fix count, indicating they are still pinned (i.e., in use).
 * This is useful before shutting down the buffer pool to ensure no pages are being accessed.
 *
 * @return RC_OK if all pages are unpinned; RC_PINNED_PAGES_STILL_IN_BUFFER if any page is pinned.
 */
RC checkPinnedPages(BM_BufferPool *const bm)
{
    //Accessing the buffer pool's management data (internal frame tracking structure)
    BufferPoolMgmt *bpMan = (BufferPoolMgmt *)bm->mgmtData;

    //Looping through each frame in the buffer pool
    for(int i = 0; i < bm->numPages; i++)
	{
        //If any frame has a fixCount greater than 0, it means it is still pinned
        if(bpMan->frames[i].fixCount > 0)
		{
            //Returning error code indicating pinned pages are still present
            return RC_PINNED_PAGES_STILL_IN_BUFFER;
        }
    }

    //All pages are unpinned and safe to proceed with shutdown or cleanup
    return RC_OK;
}

/**
 * Function shutdownBufferPool: Shuts down a buffer pool by flushing dirty pages,
 * checking for pinned pages, and freeing all allocated memory.
 *
 * @param bm Pointer to the buffer pool to be shut down.
 *
 * This function performs the proper sequence of shutdown operations:
 * 1. Flushes all dirty pages to disk.
 * 2. Ensures no pages are still pinned.
 * 3. Frees memory for all buffer pool frames and internal structures.
 * 4. Resets buffer pool metadata for safety.
 *
 * @return RC_OK if shutdown completes successfully, or an appropriate error code.
 */
extern RC shutdownBufferPool(BM_BufferPool *const bm) 
{
    //Validating the input to check if the buffer pool is null
    if (bm == NULL) 
	{
        return RC_INVALID_BM;
    }

    //Flushing any dirty pages to disk before proceeding
    RC flushResult = forceFlushPool(bm);
    if(flushResult != RC_OK) 
	{
        return flushResult;
    }

    //Ensuring there are no pinned pages still in memory
    RC pinnedPageCheck = checkPinnedPages(bm);
    if(pinnedPageCheck != RC_OK) 
	{
        return pinnedPageCheck;
    }

    //Retrieving the internal buffer pool management structure
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Beginning the cleanup of buffer pool memory
    if(manager != NULL) 
	{
        //Freeing all allocated page frame memory
        if(manager->frames != NULL) 
		{
            for(int i = 0; i < bm->numPages; i++) 
			{
				//Freeing memory for each frame's data block
                free(manager->frames[i].data);  
            }

			//Freeing the frame array itself
            free(manager->frames);  
        }

        //Freeing the replacement strategy queue if applicable
        if (bm->strategy == RS_FIFO || bm->strategy == RS_LRU) 
		{
            free(manager->queue);
        }

        //Freeing the buffer pool management structure
        free(manager);

		//Clearing the management pointer to avoid dangling references
        bm->mgmtData = NULL;  
    }

    //Freeing the memory allocated for the page file name
    free(bm->pageFile);

	//Nullifying pointer for safety
    bm->pageFile = NULL;  

    //Successfully shut down the buffer pool
    return RC_OK;
}

/**
 * Function forceFlushPool: Writes all unpinned and dirty pages from the buffer pool to disk.
 *
 * @param bm Pointer to the buffer pool whose dirty pages are to be flushed.
 *
 * This function scans all pages in the buffer pool. If a page is marked as dirty
 * and is not currently pinned (fixCount == 0), it is written to disk. After writing,
 * the dirty flag is reset, and the write I/O counter is incremented.
 *
 * @return RC_OK if flush is successful, or an appropriate error code if any failure occurs.
 */
RC forceFlushPool(BM_BufferPool *const bm) 
{
    //Validating the buffer pool pointer
    if(bm == NULL) 
	{
        return RC_INVALID_BM;
    }

    //Retrieving internal management structure of the buffer pool
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //File handle for accessing the page file on disk
    SM_FileHandle fileHandle;

    //Attempting to open the page file associated with the buffer pool
    if(openPageFile(bm->pageFile, &fileHandle) != RC_OK) 
	{
		//Return if file cannot be opened
        return RC_FILE_NOT_FOUND; 
    }

    //Iterating through each page in the buffer pool
    for(int i = 0; i < bm->numPages; i++) 
	{
        Frame *currentFrame = &manager->frames[i];

        //Checking if the page is dirty and not pinned
        if (currentFrame->isDirty && currentFrame->fixCount == 0) 
		{
            SM_PageHandle pageData = currentFrame->data;

            //Attempting to write the page back to disk
            if (writeBlock(currentFrame->pageNum, &fileHandle, pageData) == RC_OK) 
			{
                //Marking page as clean and update I/O count
                currentFrame->isDirty = false;
                manager->numWriteIO++;
            } 
			else 
			{
                //Writing failed, close file and return error
                closePageFile(&fileHandle);
                return RC_WRITE_FAILED;
            }
        }
    }

    //Closing the file after flushing all eligible pages
    closePageFile(&fileHandle);

    //All dirty, unpinned pages were successfully flushed
    return RC_OK;
}

/**
 * Function markDirty: Marks a page in the buffer pool as dirty.
 *
 * @param bm Pointer to the buffer pool containing the page.
 * @param page Pointer to the page handle of the page to be marked dirty.
 *
 * This function searches for the given page in the buffer pool by its page number.
 * If the page is found, it is marked as dirty. If the page is not found in the buffer
 * pool, the function returns an error indicating that the page is not in the pool.
 *
 * @return RC_OK if the page was successfully marked dirty, or an appropriate error code
 *         if the page is not found in the buffer pool or there is an invalid input.
 */
RC markDirty(BM_BufferPool *const bm, BM_PageHandle *const page) 
{
    //Validating the buffer pool pointer
    if (bm == NULL) 
	{
        return RC_INVALID_BM; 
    }

    //Validating the page handle pointer
    if (page == NULL) 
	{
		//Returning error if page handle is invalid
        return RC_INVALID_PAGE_HANDLE; 
    }

    //Retrieving internal management structure of the buffer pool
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Searching for the page within the buffer pool's frames
    for (int i = 0; i < bm->numPages; i++) 
	{
        //If the page is found in the buffer pool
        if (manager->frames[i].pageNum == page->pageNum) 
		{
            //Marking the page as dirty
            manager->frames[i].isDirty = true;

			//Successfully marked as dirty
            return RC_OK; 
        }
    }

    //Returning error if the page is not found in the buffer pool
    return RC_PAGE_NOT_IN_BUFFER_POOL;
}

/**
 * Function pinPage: Pins a page into the buffer pool, loading it if necessary.
 *
 * @param bm Pointer to the buffer pool.
 * @param page Pointer to the page handle where the page will be stored.
 * @param pageNum The page number of the page to be pinned.
 *
 * This function attempts to find the given page in the buffer pool. If it is not already
 * in the pool, the function will replace a page (according to the replacement strategy),
 * load the requested page from the disk, and store it in the buffer pool. If the page
 * is found, it increments the fix count for that page. It also ensures the page is 
 * available by checking if the file has sufficient capacity.
 *
 * @return RC_OK if the page is successfully pinned, or an appropriate error code if
 *         there is a failure (e.g., invalid inputs, page replacement fails).
 */
RC pinPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum) 
{
    //Validating the buffer pool pointer
    if(bm == NULL) 
	{
		//Returning error if the buffer pool is invalid
        return RC_INVALID_BM;  
    }

    //Validating the page handle pointer
    if(page == NULL) 
	{
		//Returning error if the page handle is invalid
        return RC_INVALID_PAGE_HANDLE;  
    }

    //Ensuring the page number is valid
    if(pageNum < 0) 
	{
		//Returning error if the page number is invalid
        return RC_INVALID_PAGE_NUM;  
    }

    //Retrieving the buffer pool's internal management structure
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;
    
    //Handling for interacting with the file system
    SM_FileHandle fileHandle;

	//Opening the page file for reading
    openPageFile(bm->pageFile, &fileHandle);  

    //Ensuring the page file can accommodate the requested page
    if(fileHandle.totalNumPages - 1 < pageNum) 
	{
        //Extending the file if it does not have enough pages
        ensureCapacity(pageNum + 1, &fileHandle);
    }

    //Setting the page number in the page handle
    page->pageNum = pageNum;

    //Handling the page replacement strategy based on the buffer pool's strategy
    switch(bm->strategy) 
	{
        case RS_FIFO:
            //FIFO strategy : Check if the page is already in the buffer pool
            for(int i = 0; i < bm->numPages; i++) 
			{
                if(manager->frames[i].pageNum == pageNum) 
				{
                    //Page found, increment its fix count
                    manager->frames[i].fixCount++;

					//Setting the page data
                    page->data = manager->frames[i].data;  

					//Closing the page file
                    closePageFile(&fileHandle);  

					//Successfully pinned the page
                    return RC_OK;  
                }
            }

            //If page not found, use FIFO replacement strategy to replace a frame
            if (FIFO_replace(bm, page, pageNum, &fileHandle) != RC_OK) 
			{
				//Closing the file if replacement fails
                closePageFile(&fileHandle);  

				//All frames might be pinned and no replacement possible
                return RC_ERROR;  
            }
            break;

        case RS_LRU:
            //LRU strategy : Use LRU replacement to replace a frame
            LRU_replace(bm, page, pageNum, &fileHandle);
            break;

        default:
            //Invalid replacement strategy
            printf("Error Occurred : Invalid replacement strategy\n");
            break;
    }

    //Closing the page file after handling the replacement
    closePageFile(&fileHandle);

	//Successfully pinned the page
    return RC_OK;  
}

/**
 * Function unpinPage: Unpins a page from the buffer pool, decrementing its fix count.
 *
 * @param bm Pointer to the buffer pool.
 * @param page Pointer to the page handle of the page to be unpinned.
 *
 * This function searches for the page in the buffer pool by its page number. If the page 
 * is found, it decrements the fix count, which indicates how many times the page is in use.
 * If the fix count is already zero or negative, an error is returned. If the page is not 
 * found in the buffer pool, it returns an error indicating that the page is not in the pool.
 *
 * @return RC_OK if the page is successfully unpinned, or an appropriate error code if
 *         there is a failure (e.g., invalid inputs or page not found in the buffer pool).
 */
RC unpinPage(BM_BufferPool *const bm, BM_PageHandle *const page) 
{
    //Validating the buffer pool pointer
    if (bm == NULL) 
	{
		//Returning error if the buffer pool is invalid
        return RC_INVALID_BM;  
    }

    //Validating the page handle pointer
    if (page == NULL) 
	{
		//Returning error if the page handle is invalid
        return RC_INVALID_PAGE_HANDLE;  
    }

    //Retrieving the buffer pool's internal management structure
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Searching for the page within the buffer pool
    for (int i = 0; i < bm->numPages; i++) 
	{
        //If the page is found in the buffer pool
        if (manager->frames[i].pageNum == page->pageNum) 
		{
            //Ensuring fixCount is positive before decrementing
            if (manager->frames[i].fixCount > 0) 
			{
				//Decrementing the fix count
                manager->frames[i].fixCount--;  

				//Successfully unpinned the page
                return RC_OK;  
            } 
			else 
			{
                //fixCount was already zero or negative, which is unexpected
				//Returning error if fixCount is invalid
                return RC_FIX_COUNT_ALREADY_ZERO;  
            }
        }
    }

    //Returning error if the page is not found in the buffer pool
    return RC_PAGE_NOT_IN_BUFFER_POOL;
}

/**
 * Function forcePage: Forces a page to be written to disk if it is dirty, ensuring data 
 * consistency for the page.
 *
 * @param bm Pointer to the buffer pool containing the page to be written.
 * @param page Pointer to the page handle that should be written to disk.
 *
 * This function searches for the specified page in the buffer pool. If the page is dirty, 
 * it writes the page's data to the corresponding page in the file. After writing the page, 
 * the page is marked as clean (i.e., not dirty), and the write IO counter is updated.
 * If the page is not found in the buffer pool, an error is returned.
 *
 * @return RC_OK if the page is successfully written to disk, or an appropriate error code
 *         if there are any failures (e.g., file open/write/close issues or page not found).
 */
RC forcePage(BM_BufferPool *const bm, BM_PageHandle *const page) 
{
    //Validating the buffer pool pointer
    if (bm == NULL)
	{
		//Returning error if the buffer pool is invalid
        return RC_INVALID_BM;  
    }

    //Retrieving the buffer pool's internal management structure
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;
    SM_FileHandle fileHandle;

    //Attempting to open the page file associated with the buffer pool
    RC openStatus = openPageFile(bm->pageFile, &fileHandle);
    if (openStatus != RC_OK) 
	{
		//Returning the error if the file can't be opened
        return openStatus;  
    }

    //Iterating through all pages in the buffer pool to find the target page
    for (int i = 0; i < bm->numPages; i++) 
	{
        //Checking if the current page in the buffer pool matches the page to be written
        if (manager->frames[i].pageNum == page->pageNum) 
		{
            //Writing the dirty page to the file
            RC writeStatus = writeBlock(manager->frames[i].pageNum, &fileHandle, page->data);
            if (writeStatus != RC_OK) 
			{
				//Attempting to close the file before returning
                closePageFile(&fileHandle);  

				//Returning the error from writing the block
                return writeStatus;  
            }

            //Marking the page as clean (not dirty anymore)
            manager->frames[i].isDirty = false;
            
			//Incrementing the write IO counter
            manager->numWriteIO++;

            //Closing the page file after the write operation
            RC closeStatus = closePageFile(&fileHandle);
            if (closeStatus != RC_OK) 
			{
				//Returning the error from closing the file
                return closeStatus;  
            }

            //Returning success after the page is successfully written
            return RC_OK;
        }
    }

    //Attempting to close the file before returning
    closePageFile(&fileHandle);  

	//Returning error if the page was not found in the buffer pool
    return RC_PAGE_NOT_FOUND;  
}

/**
 * Function getFrameContents: Retrieves the page numbers of all frames currently
 * stored in the buffer pool.
 *
 * @param bm Pointer to the buffer pool whose frame contents need to be fetched.
 *
 * This function allocates memory for an array of page numbers, then iterates through
 * all frames in the buffer pool to copy the page numbers into this array. The function
 * returns the array containing the page numbers of the frames.
 *
 * @return A pointer to an array containing the page numbers of all frames in the buffer pool.
 *         The caller is responsible for freeing the allocated memory for the returned array.
 */
PageNumber *getFrameContents(BM_BufferPool *const bm) 
{
    //Retrieving the buffer pool management data
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Allocating memory to store the page numbers of all frames
    PageNumber *frameCon = (PageNumber *)malloc(sizeof(PageNumber) * bm->numPages);
    if (frameCon == NULL) 
	{
		//Returning NULL if memory allocation fails
        return NULL;  
    }

    //Copying the page numbers from each frame into the allocated array
    for (int i = 0; i < bm->numPages; i++) 
	{
        frameCon[i] = manager->frames[i].pageNum;
    }

    //Returning the array of page numbers
    return frameCon;
}

/**
 * Function getDirtyFlags: Retrieves the dirty flags of all frames in the buffer pool.
 * A frame is considered dirty if the page it contains has been modified and needs 
 * to be written back to the disk.
 *
 * @param bm Pointer to the buffer pool whose dirty flags need to be fetched.
 *
 * This function allocates memory for an array of booleans. It then iterates through all
 * the frames in the buffer pool, checking the `isDirty` flag for each frame. The array
 * of booleans is returned, indicating whether each frame is dirty or not.
 *
 * @return A pointer to an array of booleans, where each element corresponds to a frame
 *         in the buffer pool, indicating whether the frame is dirty (true) or clean (false).
 *         The caller is responsible for freeing the allocated memory for the returned array.
 */
bool *getDirtyFlags(BM_BufferPool *const bm) 
{
    //Retrieving the buffer pool management data
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Allocating memory for an array to store the dirty flags of all frames
    bool *dirtyFl = (bool *)malloc(sizeof(bool) * bm->numPages);
    if (dirtyFl == NULL) 
	{
		//Returning NULL if memory allocation fails
        return NULL;  
    }

    //Iterating through each frame and copy its dirty flag to the array
    for (int i = 0; i < bm->numPages; i++) 
	{
        dirtyFl[i] = manager->frames[i].isDirty;
    }

    //Returning the array of dirty flags
    return dirtyFl;
}

/**
 * Function getFixCounts: Retrieves the fix count of all frames in the buffer pool.
 * The fix count indicates how many clients are currently using the page. A page can 
 * be replaced only when its fix count is 0.
 *
 * @param bm Pointer to the buffer pool whose fix counts need to be fetched.
 *
 * This function allocates memory for an array of integers. It then iterates through all
 * the frames in the buffer pool, checking the `fixCount` for each frame. The array
 * of integers is returned, representing the number of clients currently using each frame.
 *
 * @return A pointer to an array of integers, where each element corresponds to a frame
 *         in the buffer pool, representing the number of clients (fix count) using the frame.
 *         The caller is responsible for freeing the allocated memory for the returned array.
 */
int *getFixCounts(BM_BufferPool *const bm) 
{
    //Retrieving the buffer pool management data
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Allocating memory for an array to store the fix counts of all frames
    int *fixCt = (int *)malloc(sizeof(int) * bm->numPages);
    if (fixCt == NULL) 
	{
		//Returning NULL if memory allocation fails
        return NULL;  
    }

    //Iterating through each frame and copy its fix count to the array
    for (int i = 0; i < bm->numPages; i++) 
	{
        fixCt[i] = manager->frames[i].fixCount;
    }

    //Returning the array of fix counts
    return fixCt;
}

/**
 * Function getNumReadIO: Retrieves the number of pages that have been read from the disk 
 * into the buffer pool. This function helps in evaluating the buffer pool's input-output (IO) efficiency.
 *
 * @param bm Pointer to the buffer pool whose read IO count needs to be fetched.
 *
 * This function simply accesses the `numReadIO` field from the buffer pool management 
 * structure and returns it. This metric is useful to determine how many pages have 
 * been read from disk into the buffer pool.
 *
 * @return The number of pages read from disk into the buffer pool.
 */
int getNumReadIO(BM_BufferPool *const bm) 
{
    //Retrieving the buffer pool management data
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Returning the number of read IOs
    return manager->numReadIO;
}

/**
 * Function getNumWriteIO: Retrieves the number of pages that have been written back 
 * to the disk from the buffer pool. This function helps in assessing the buffer pool's 
 * output IO performance.
 *
 * @param bm Pointer to the buffer pool whose write IO count needs to be fetched.
 *
 * This function simply accesses the `numWriteIO` field from the buffer pool management 
 * structure and returns it. This metric is useful to determine how many pages have 
 * been written from the buffer pool to disk.
 *
 * @return The number of pages written back to disk from the buffer pool.
 */
int getNumWriteIO(BM_BufferPool *const bm) 
{
    //Retrieving the buffer pool management data
    BufferPoolMgmt *manager = (BufferPoolMgmt *)bm->mgmtData;

    //Returning the number of write IOs
    return manager->numWriteIO;
}

