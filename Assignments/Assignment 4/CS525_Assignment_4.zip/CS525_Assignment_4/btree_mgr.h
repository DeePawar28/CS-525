#ifndef BTREE_MGR_H
#define BTREE_MGR_H

#include "storage_mgr.h"
#include "buffer_mgr.h"
#include "dberror.h"
#include "tables.h"

typedef enum NodeType {
    INNER_NODE = 1,
    LEAF_NODE = 0
} NodeType;

typedef struct BTreeNode {
    NodeType type;
    Value **keys;
    void **ptrs;
    int keyNums;
    RID *records;
    struct BTreeNode *next;
    struct BTreeNode *parent;
} BTreeNode;

// Structure for accessing B+ trees
typedef struct BTreeHandle {
    DataType keyType;
    const char *idxId;   // idxId is now const to ensure immutability
    void *mgmtData;
} BTreeHandle;

typedef struct BTreeMtdt {
    int n;
    int minLeaf;
    int minNonLeaf;
    int nodes;
    int entries;
    DataType keyType;
    BTreeNode *root;
    BM_PageHandle *ph;
    BM_BufferPool *bm;
} BTreeMtdt;

typedef struct BT_ScanHandle {
    BTreeHandle *tree;
    void *mgmtData;
} BT_ScanHandle;

typedef struct BT_ScanMtdt {
    int keyIndex;
    BTreeNode *node;
} BT_ScanMtdt;

#define MAKE_TREE_HANDLE()            \
        ((BTreeHandle *) malloc (sizeof(BTreeHandle)))

#define MAKE_TREE_MTDT()              \
        ((BTreeMtdt *) malloc (sizeof(BTreeMtdt)))

#define MAKE_TREE_NODE()              \
        ((BTreeNode *) malloc (sizeof(BTreeNode)))

#define MAKE_TREE_SCAN()              \
        ((BT_ScanHandle *) malloc (sizeof(BT_ScanHandle)))

// Initialization and shutdown of index manager
extern RC initIndexManager (void *mgmtData);
extern RC shutdownIndexManager ();

// Create, destroy, open, and close a B+ tree index
extern RC createBtree (const char *idxId, DataType keyType, int n);
extern RC openBtree (BTreeHandle **tree, const char *idxId);
extern RC closeBtree (BTreeHandle *tree);
extern RC deleteBtree (const char *idxId);

// Access information about a B+ tree
extern RC getNumNodes (const BTreeHandle *tree, int *result);
extern RC getNumEntries (const BTreeHandle *tree, int *result);
extern RC getKeyType (const BTreeHandle *tree, DataType *result);

// Index access
extern RC findKey (BTreeHandle *tree, Value *key, RID *result);
extern RC insertKey (BTreeHandle *tree, Value *key, RID rid);
extern RC deleteKey (BTreeHandle *tree, Value *key);
extern RC openTreeScan (BTreeHandle *tree, BT_ScanHandle **handle);
extern RC nextEntry (BT_ScanHandle *handle, RID *result);
extern RC closeTreeScan (BT_ScanHandle *handle);

// B+ tree functions
extern void insertIntoParentNode(BTreeNode*, Value *, BTreeMtdt *);
extern RID* buildRID(RID *);
extern Value *copyKey(Value *);

// Debug and test functions
extern char *printTree (BTreeHandle *tree);

#endif // BTREE_MGR_H
